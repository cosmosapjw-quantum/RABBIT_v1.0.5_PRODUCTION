import numpy as np

from f10_solver_research.models import LinearNonnormalModel
from f10_solver_research.solvers.jfnk import solve_implicit_euler_jfnk


def _implicit_euler_reference(matrix: np.ndarray, y0: np.ndarray, h: float, steps: int) -> np.ndarray:
    update = np.linalg.inv(np.eye(matrix.shape[0]) - h * matrix)
    state = np.asarray(y0, dtype=np.float64)
    for _ in range(steps):
        state = update @ state
    return state


def test_jfnk_matches_dense_implicit_euler_on_linear_system():
    model = LinearNonnormalModel(size=7, nonnormal_strength=8.0)
    y0 = np.linspace(-0.2, 0.3, model.size)
    h = 0.025
    steps = 8
    result = solve_implicit_euler_jfnk(
        model.rhs,
        (0.0, h * steps),
        y0,
        step_size=h,
        newton_rtol=2e-11,
        gmres_rtol=2e-11,
        jvp_relative_step=2e-7,
    )
    assert result.success, result.reason
    expected = _implicit_euler_reference(model.matrix, y0, h, steps)
    np.testing.assert_allclose(result.endpoint, expected, rtol=2e-7, atol=2e-9)
    assert result.stats.steps == steps
    assert result.stats.jacobian_vector_products > 0
    assert result.stats.rhs_calls >= result.stats.steps


def test_jfnk_implicit_euler_has_first_order_global_convergence():
    model = LinearNonnormalModel(size=6, nonnormal_strength=4.0)
    y0 = np.cos(np.arange(model.size))
    t_end = 0.4
    coarse = solve_implicit_euler_jfnk(
        model.rhs, (0.0, t_end), y0, step_size=0.05,
        newton_rtol=1e-11, gmres_rtol=1e-11, jvp_relative_step=1e-7,
    )
    fine = solve_implicit_euler_jfnk(
        model.rhs, (0.0, t_end), y0, step_size=0.025,
        newton_rtol=1e-11, gmres_rtol=1e-11, jvp_relative_step=1e-7,
    )
    assert coarse.success and fine.success
    exact = model.exact(t_end, y0)
    err_coarse = np.linalg.norm(coarse.endpoint - exact)
    err_fine = np.linalg.norm(fine.endpoint - exact)
    assert err_coarse / err_fine > 1.75
    assert err_coarse / err_fine < 2.35


def test_jfnk_uses_preconditioner_and_reduces_linear_iterations():
    model = LinearNonnormalModel(size=18, nonnormal_strength=30.0)
    y0 = np.linspace(-1.0, 1.0, model.size)
    h = 0.08

    def exact_factory(t, state, step):
        del t, state
        inverse = np.linalg.inv(np.eye(model.size) - step * model.matrix)
        return lambda vector: inverse @ vector

    raw = solve_implicit_euler_jfnk(
        model.rhs, (0.0, h), y0, step_size=h,
        newton_rtol=1e-11, gmres_rtol=1e-11, jvp_relative_step=1e-7,
    )
    preconditioned = solve_implicit_euler_jfnk(
        model.rhs, (0.0, h), y0, step_size=h,
        newton_rtol=1e-11, gmres_rtol=1e-11, jvp_relative_step=1e-7,
        preconditioner_factory=exact_factory,
    )
    assert raw.success and preconditioned.success
    assert preconditioned.stats.extra["preconditioner_applications"] > 0
    assert preconditioned.stats.linear_iterations < raw.stats.linear_iterations


def test_jfnk_surfaces_gmres_failure_without_silent_fallback():
    model = LinearNonnormalModel(size=24, nonnormal_strength=80.0)
    y0 = np.linspace(-1.0, 1.0, model.size)
    result = solve_implicit_euler_jfnk(
        model.rhs,
        (0.0, 0.2),
        y0,
        step_size=0.2,
        newton_rtol=1e-13,
        gmres_rtol=1e-14,
        max_linear_iterations=1,
        max_newton_iterations=2,
        jvp_relative_step=1e-7,
    )
    assert not result.success
    assert result.reason.startswith("GMRES_FAILED")
    assert result.stats.steps == 0


def test_jfnk_optional_state_projection_is_applied_after_each_step():
    from f10_solver_research.grids import Grid
    from f10_solver_research.models import ManufacturedKineticModel

    model = ManufacturedKineticModel(Grid.gauss_legendre(8, 6.0))
    result = solve_implicit_euler_jfnk(
        model.rhs_true,
        (0.0, 0.2),
        model.exact_state(0.0),
        step_size=0.04,
        newton_rtol=2e-9,
        gmres_rtol=1e-8,
        jvp_relative_step=2e-6,
        state_projector=model.project_energy_identity,
    )
    assert result.success
    assert abs(model.energy_identity_residual(0.2, result.endpoint)) <= 1e-14
    assert result.stats.extra["projection_applications"] == result.stats.steps
