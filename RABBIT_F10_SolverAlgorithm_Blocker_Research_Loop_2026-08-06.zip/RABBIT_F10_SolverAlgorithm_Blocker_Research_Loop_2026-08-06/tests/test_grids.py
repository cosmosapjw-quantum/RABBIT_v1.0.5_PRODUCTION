import numpy as np

from f10_solver_research.grids import Grid, build_transfer_pair


def test_identity_transfer_is_exact_for_same_grid():
    grid = Grid.gauss_legendre(order=12, y_max=8.0)
    transfer = build_transfer_pair(grid, grid, species=3, scalar_count=2)
    state = np.linspace(-0.2, 0.3, 3 * grid.order + 2)
    np.testing.assert_array_equal(transfer.prolong_state(state), state)
    np.testing.assert_array_equal(transfer.restrict_state(state), state)


def test_prolongation_reproduces_constant_on_coarse_support_and_zeros_tail():
    coarse = Grid.gauss_legendre(order=12, y_max=8.0)
    fine = Grid.gauss_legendre(order=16, y_max=10.0)
    transfer = build_transfer_pair(coarse, fine, species=1, scalar_count=0)
    prolonged = transfer.prolong_spectral(np.ones(coarse.order))
    inside = fine.nodes <= coarse.y_max
    np.testing.assert_allclose(prolonged[inside], 1.0, rtol=0.0, atol=2e-12)
    np.testing.assert_array_equal(prolonged[~inside], np.zeros(np.count_nonzero(~inside)))


def test_restriction_reproduces_low_degree_polynomial():
    coarse = Grid.gauss_legendre(order=10, y_max=6.0)
    fine = Grid.gauss_legendre(order=18, y_max=9.0)
    transfer = build_transfer_pair(coarse, fine, species=1, scalar_count=0)
    values_fine = 1.0 - 0.2 * fine.nodes + 0.03 * fine.nodes**2
    restricted = transfer.restrict_spectral(values_fine)
    expected = 1.0 - 0.2 * coarse.nodes + 0.03 * coarse.nodes**2
    np.testing.assert_allclose(restricted, expected, rtol=0.0, atol=3e-11)
