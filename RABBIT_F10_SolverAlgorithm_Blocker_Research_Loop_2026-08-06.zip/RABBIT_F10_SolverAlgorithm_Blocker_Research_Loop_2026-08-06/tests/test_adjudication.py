from dataclasses import replace

from f10_solver_research.adjudication import (
    CandidateMetrics,
    GateThresholds,
    adjudicate_candidate,
    projected_wall_seconds,
)


def passing_metrics(name: str = "D-JFNK") -> CandidateMetrics:
    return CandidateMetrics(
        name=name,
        success=True,
        finite=True,
        occupations_valid=True,
        matrix_free=True,
        control_only=False,
        endpoint_wrms=1e-6,
        cancellation_endpoint_wrms=1e-5,
        energy_residual=1e-12,
        cancellation_energy_residual=1e-9,
        rhs_calls=1000,
        scaling_exponent=1.1,
        deterministic=True,
        peak_rss_bytes=100_000_000,
    )


def test_projected_wall_arithmetic_uses_frozen_call_cost_and_safety_factor():
    thresholds = GateThresholds()
    assert projected_wall_seconds(5500, thresholds) == 5500 * 4.5 * 2.5
    assert projected_wall_seconds(5500, thresholds) < thresholds.wall_budget_seconds


def test_passing_matrix_free_candidate_survives_with_deterministic_gate_order():
    decision = adjudicate_candidate(passing_metrics())
    assert decision.status == "SURVIVE"
    assert list(decision.gates) == [
        "scope",
        "completion",
        "finite",
        "occupations",
        "noiseless_accuracy",
        "cancellation_accuracy",
        "noiseless_energy",
        "cancellation_energy",
        "call_budget",
        "scaling",
        "projected_wall",
        "determinism",
        "memory",
    ]
    assert decision.reasons == []


def test_supplied_jacobian_bdf_control_cannot_be_reopening_survivor():
    control = replace(
        passing_metrics("SUPPLIED-JAC-BDF"),
        matrix_free=False,
        control_only=True,
    )
    decision = adjudicate_candidate(control)
    assert decision.status == "KILL"
    assert decision.gates["scope"] is False
    assert decision.reasons[0].startswith("scope:")


def test_moderate_budget_miss_is_rework_but_large_scientific_miss_is_kill():
    moderate = replace(passing_metrics(), rhs_calls=5800)
    moderate_decision = adjudicate_candidate(moderate)
    assert moderate_decision.status == "REWORK"
    assert moderate_decision.gates["call_budget"] is False

    large = replace(passing_metrics(), endpoint_wrms=3e-4)
    large_decision = adjudicate_candidate(large)
    assert large_decision.status == "KILL"
    assert large_decision.gates["noiseless_accuracy"] is False
