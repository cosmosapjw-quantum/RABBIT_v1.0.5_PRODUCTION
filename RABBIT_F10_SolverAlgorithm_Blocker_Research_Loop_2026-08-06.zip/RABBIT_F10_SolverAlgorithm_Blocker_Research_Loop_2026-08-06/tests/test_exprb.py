import numpy as np

from f10_solver_research.grids import Grid
from f10_solver_research.models import LinearNonnormalModel, ManufacturedKineticModel
from f10_solver_research.solvers.exprb import solve_exprb_krylov


def test_exprb_full_krylov_dimension_is_exact_for_linear_autonomous_step():
    model = LinearNonnormalModel(size=7, nonnormal_strength=9.0)
    y0 = np.linspace(-0.4, 0.2, model.size)
    h = 0.12
    result = solve_exprb_krylov(
        model.rhs,
        (0.0, h),
        y0,
        step_size=h,
        krylov_dim=model.size + 1,
        jvp_relative_step=2e-6,
        arnoldi_tolerance=1e-13,
    )
    assert result.success, result.reason
    np.testing.assert_allclose(
        result.endpoint,
        model.exact(h, y0),
        rtol=2e-7,
        atol=3e-9,
    )
    assert result.stats.steps == 1


def test_exprb_manufactured_nonlinear_error_decreases_under_step_halving():
    model = ManufacturedKineticModel(Grid.gauss_legendre(10, 8.0), cancellation_scale=0.0)
    y0 = model.exact_state(0.0)
    t_end = 0.5
    coarse = solve_exprb_krylov(
        model.rhs_true, (0.0, t_end), y0,
        step_size=0.05, krylov_dim=18, jvp_relative_step=2e-6,
    )
    fine = solve_exprb_krylov(
        model.rhs_true, (0.0, t_end), y0,
        step_size=0.025, krylov_dim=18, jvp_relative_step=2e-6,
    )
    assert coarse.success and fine.success
    exact = model.exact_state(t_end)
    coarse_error = np.linalg.norm(coarse.endpoint - exact) / np.sqrt(model.state_size)
    fine_error = np.linalg.norm(fine.endpoint - exact) / np.sqrt(model.state_size)
    assert fine_error < 0.65 * coarse_error


def test_exprb_handles_zero_rhs_as_clean_arnoldi_breakdown():
    y0 = np.linspace(-1.0, 1.0, 9)
    result = solve_exprb_krylov(
        lambda t, y: np.zeros_like(y),
        (0.0, 0.3),
        y0,
        step_size=0.1,
        krylov_dim=6,
    )
    assert result.success
    np.testing.assert_array_equal(result.endpoint, y0)
    assert result.stats.extra["arnoldi_breakdowns"] == result.stats.steps
    # One augmented directional probe is required to establish that the
    # [f, 1] Krylov subspace is invariant; no persistent derivative state is reused.
    assert result.stats.jacobian_vector_products == result.stats.steps
    assert result.stats.rhs_calls == 2 * result.stats.steps


def test_exprb_rhs_call_accounting_includes_each_krylov_matvec():
    model = LinearNonnormalModel(size=8, nonnormal_strength=11.0)
    result = solve_exprb_krylov(
        model.rhs,
        (0.0, 0.15),
        np.linspace(-0.1, 0.2, model.size),
        step_size=0.05,
        krylov_dim=5,
        jvp_relative_step=1e-6,
    )
    assert result.success
    assert result.stats.steps == 3
    assert result.stats.jacobian_vector_products == 15
    assert result.stats.rhs_calls == result.stats.steps + result.stats.jacobian_vector_products
    assert len(result.stats.extra["projected_ie_defects"]) == result.stats.steps


def test_exprb_optional_state_projection_closes_energy_identity():
    model = ManufacturedKineticModel(Grid.gauss_legendre(8, 6.0))
    result = solve_exprb_krylov(
        model.rhs_true,
        (0.0, 0.2),
        model.exact_state(0.0),
        step_size=0.05,
        krylov_dim=10,
        jvp_relative_step=1e-4,
        state_projector=model.project_energy_identity,
    )
    assert result.success
    assert abs(model.energy_identity_residual(0.2, result.endpoint)) <= 1e-14
    assert result.stats.extra["projection_applications"] == result.stats.steps
