import numpy as np

from f10_solver_research.solvers.common import fixed_step_schedule


def test_fixed_step_schedule_has_no_terminal_microstep_for_integer_ratio():
    steps = fixed_step_schedule(0.0, 0.8, 5e-4)
    assert len(steps) == 1600
    assert min(steps) > 0.99 * 5e-4
    assert max(steps) < 1.01 * 5e-4
    assert float(np.sum(steps, dtype=np.float64)) == 0.8


def test_fixed_step_schedule_keeps_one_declared_short_final_step():
    steps = fixed_step_schedule(0.0, 0.23, 0.05)
    assert len(steps) == 5
    np.testing.assert_allclose(steps[:4], 0.05, rtol=0.0, atol=0.0)
    assert abs(steps[-1] - 0.03) <= 2e-16
    assert float(np.sum(steps, dtype=np.float64)) == 0.23
