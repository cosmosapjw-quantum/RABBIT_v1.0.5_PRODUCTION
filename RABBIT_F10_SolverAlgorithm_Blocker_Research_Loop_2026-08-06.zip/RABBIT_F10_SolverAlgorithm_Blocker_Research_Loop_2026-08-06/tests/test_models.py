import numpy as np
from scipy.linalg import expm

from f10_solver_research.contracts import CallCounter
from f10_solver_research.grids import Grid
from f10_solver_research.models import LinearNonnormalModel, ManufacturedKineticModel


def weighted_rms(v: np.ndarray) -> float:
    return float(np.linalg.norm(v) / np.sqrt(v.size))


def test_call_counter_counts_vectorized_columns_as_full_rhs_calls():
    counter = CallCounter()

    def fun(t, y):
        return 2.0 * y

    wrapped = counter.wrap(fun)
    wrapped(0.0, np.ones(5))
    wrapped(0.0, np.ones((5, 7)))
    assert counter.calls == 8
    assert len(counter.wall_seconds) == 2


def test_linear_nonnormal_model_matches_matrix_exponential():
    model = LinearNonnormalModel(size=8, decay=5.75, nonnormal_strength=12.0)
    y0 = np.linspace(-0.3, 0.2, model.size)
    t = 0.37
    expected = expm(t * model.matrix) @ y0
    np.testing.assert_allclose(model.exact(t, y0), expected, rtol=0.0, atol=2e-13)
    np.testing.assert_allclose(model.rhs(t, y0), model.matrix @ y0, rtol=0.0, atol=0.0)


def test_manufactured_path_satisfies_rhs_and_energy_identity():
    grid = Grid.gauss_legendre(order=18, y_max=12.0)
    model = ManufacturedKineticModel(grid=grid, cancellation_scale=0.0)
    for t in (0.0, 0.17, 0.8):
        y = model.exact_state(t)
        defect = model.rhs_true(t, y) - model.exact_derivative(t)
        assert weighted_rms(defect) <= 2e-11
        assert abs(model.energy_identity_residual(t, y)) <= 2e-12


def test_occupation_reconstruction_is_strict_open():
    grid = Grid.gauss_legendre(order=20, y_max=15.0)
    model = ManufacturedKineticModel(grid=grid, cancellation_scale=0.0)
    occupation = model.occupations(model.exact_state(0.6))
    assert occupation.shape == (3, grid.order)
    assert np.all(np.isfinite(occupation))
    assert np.all(occupation > 0.0)
    assert np.all(occupation < 1.0)


def test_analytic_jacobian_matches_central_difference():
    grid = Grid.gauss_legendre(order=8, y_max=6.0)
    model = ManufacturedKineticModel(grid=grid, cancellation_scale=0.0)
    t = 0.31
    y = model.exact_state(t) + np.linspace(-1e-3, 1e-3, model.state_size)
    jac = model.jacobian(t, y)
    direction = np.cos(np.arange(model.state_size))
    h = 2e-6 / np.linalg.norm(direction)
    fd = (model.rhs_true(t, y + h * direction) - model.rhs_true(t, y - h * direction)) / (2 * h)
    np.testing.assert_allclose(jac @ direction, fd, rtol=3e-7, atol=2e-9)


def test_energy_projector_closes_identity_without_changing_other_components():
    grid = Grid.gauss_legendre(order=12, y_max=9.0)
    model = ManufacturedKineticModel(grid=grid)
    t = 0.43
    state = model.exact_state(t).copy()
    state[model.spectral_size] += 3.7e-4
    spectral_before = state[: model.spectral_size].copy()
    clock_before = state[-1]
    projected = model.project_energy_identity(t, state)
    assert abs(model.energy_identity_residual(t, projected)) <= 5e-16
    np.testing.assert_array_equal(projected[: model.spectral_size], spectral_before)
    assert projected[-1] == clock_before
