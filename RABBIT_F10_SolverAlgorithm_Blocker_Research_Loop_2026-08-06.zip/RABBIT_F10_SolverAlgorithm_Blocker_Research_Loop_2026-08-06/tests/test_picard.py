import numpy as np

from f10_solver_research.grids import Grid
from f10_solver_research.models import LinearNonnormalModel, ManufacturedKineticModel
from f10_solver_research.solvers.picard import solve_implicit_euler_picard


def _implicit_euler_reference(matrix, y0, h, steps):
    update = np.linalg.inv(np.eye(matrix.shape[0]) - h * matrix)
    y = np.asarray(y0, dtype=np.float64)
    for _ in range(steps):
        y = update @ y
    return y


def test_picard_matches_dense_implicit_euler_on_contractive_linear_system():
    model = LinearNonnormalModel(size=7, nonnormal_strength=5.0)
    y0 = np.linspace(-0.2, 0.3, model.size)
    h = 0.01
    result = solve_implicit_euler_picard(
        model.rhs,
        (0.0, 0.08),
        y0,
        step_size=h,
        fixed_point_tolerance=1e-11,
        max_iterations=8,
    )
    assert result.success, result.reason
    expected = _implicit_euler_reference(model.matrix, y0, h, 8)
    np.testing.assert_allclose(result.endpoint, expected, rtol=2e-10, atol=2e-11)
    assert result.stats.jacobian_vector_products == 0
    assert result.stats.linear_iterations == 0


def test_picard_reuses_rhs_of_last_evaluated_iterate():
    calls = 0

    def rhs(t, y):
        nonlocal calls
        calls += 1
        return -2.0 * y

    result = solve_implicit_euler_picard(
        rhs,
        (0.0, 0.1),
        np.ones(4),
        step_size=0.02,
        fixed_point_tolerance=1e-8,
        max_iterations=6,
    )
    assert result.success
    assert result.stats.rhs_calls == calls
    assert result.stats.rhs_calls == 1 + result.stats.extra["fixed_point_iterations"]


def test_picard_conservative_lane_handles_cancellation_oracle():
    model = ManufacturedKineticModel(
        Grid.gauss_legendre(10, 8.0), cancellation_scale=1e10
    )
    result = solve_implicit_euler_picard(
        model.rhs,
        (0.0, 0.08),
        model.exact_state(0.0),
        step_size=4e-4,
        fixed_point_tolerance=1e-8,
        max_iterations=4,
        state_projector=model.project_energy_identity,
    )
    assert result.success, result.reason
    assert abs(model.energy_identity_residual(0.08, result.endpoint)) <= 1e-14
    assert result.stats.extra["projection_applications"] > 0


def test_picard_surfaces_noncontractive_iteration_failure():
    result = solve_implicit_euler_picard(
        lambda t, y: 10.0 * y,
        (0.0, 0.2),
        np.ones(3),
        step_size=0.2,
        fixed_point_tolerance=1e-12,
        max_iterations=3,
    )
    assert not result.success
    assert result.reason == "PICARD_FAILED:iteration_limit"
    assert result.stats.steps == 0
