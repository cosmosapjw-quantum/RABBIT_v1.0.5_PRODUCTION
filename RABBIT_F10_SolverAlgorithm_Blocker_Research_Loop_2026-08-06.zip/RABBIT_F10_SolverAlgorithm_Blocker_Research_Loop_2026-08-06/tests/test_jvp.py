import numpy as np

from f10_solver_research.contracts import CallCounter
from f10_solver_research.grids import Grid
from f10_solver_research.jvp import arnoldi, finite_difference_jvp
from f10_solver_research.models import ManufacturedKineticModel


def test_fixed_rule_jvp_matches_analytic_directional_derivative():
    model = ManufacturedKineticModel(Grid.gauss_legendre(10, 8.0), cancellation_scale=0.0)
    t = 0.27
    y = model.exact_state(t) + np.linspace(-3e-4, 2e-4, model.state_size)
    direction = np.sin(0.3 + np.arange(model.state_size))
    counter = CallCounter()
    fun = counter.wrap(model.rhs_true)
    fy = fun(t, y)
    calls_before = counter.calls
    jv, step = finite_difference_jvp(
        fun, t, y, fy, direction, relative_step=2e-7, scheme="forward"
    )
    expected = model.jacobian(t, y) @ direction
    np.testing.assert_allclose(jv, expected, rtol=5e-7, atol=4e-8)
    assert step > 0.0
    assert counter.calls - calls_before == 1


def test_arnoldi_full_dimension_reproduces_matrix_action():
    rng = np.random.default_rng(1234)
    matrix = rng.normal(size=(7, 7))
    start = rng.normal(size=7)
    result = arnoldi(lambda v: matrix @ v, start, max_dim=7, tolerance=1e-14)
    m = result.dimension
    assert m == 7
    projected = result.basis @ result.hessenberg[:m, :m]
    np.testing.assert_allclose(
        matrix @ result.basis,
        projected,
        rtol=0.0,
        atol=2e-12,
    )
    assert result.beta == np.linalg.norm(start)


def test_arnoldi_reports_invariant_subspace_breakdown():
    matrix = -3.0 * np.identity(5)
    start = np.arange(1.0, 6.0)
    result = arnoldi(lambda v: matrix @ v, start, max_dim=5, tolerance=1e-13)
    assert result.dimension == 1
    assert result.breakdown
