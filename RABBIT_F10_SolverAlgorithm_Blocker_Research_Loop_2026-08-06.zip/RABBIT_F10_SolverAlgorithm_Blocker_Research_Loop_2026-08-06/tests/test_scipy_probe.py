import numpy as np

from f10_solver_research.contracts import CallCounter
from f10_solver_research.scipy_probe import run_num_jac_refresh_probe


class CancellationDerivativeOracle:
    def __init__(self, size: int = 12):
        self.size = size
        self.base = 1.0e8
        self.slope = np.geomspace(3e-4, 3e-2, size)
        self.curvature = np.geomspace(0.5, 20.0, size)

    def rhs(self, t, y):
        del t
        values = np.asarray(y, dtype=np.float64)
        if values.ndim == 1:
            return self.base + self.slope * values + self.curvature * values**2
        return self.base + self.slope[:, None] * values + self.curvature[:, None] * values**2

    def jacobian(self, t, y):
        del t
        return np.diag(self.slope + 2.0 * self.curvature * np.asarray(y))


def test_num_jac_probe_preserves_factor_across_refreshes_and_counts_columns():
    oracle = CancellationDerivativeOracle()
    y = np.linspace(1e-4, 3e-3, oracle.size)
    counter = CallCounter()
    result = run_num_jac_refresh_probe(
        fun=counter.wrap(oracle.rhs),
        analytic_jacobian=oracle.jacobian,
        t=0.0,
        y=y,
        threshold=np.full(oracle.size, 1e-9),
        refreshes=9,
    )
    assert len(result.records) == 9
    factors = np.array([row.max_factor_over_sqrt_eps for row in result.records])
    assert factors[-1] >= factors[0]
    assert np.max(factors) >= 100.0
    assert counter.calls >= oracle.size * 9
    assert result.records[-1].max_column_relative_error > 1e-4


def test_num_jac_probe_can_restart_factor_each_refresh_as_control():
    oracle = CancellationDerivativeOracle()
    y = np.linspace(1e-4, 3e-3, oracle.size)
    persistent = run_num_jac_refresh_probe(
        fun=oracle.rhs,
        analytic_jacobian=oracle.jacobian,
        t=0.0,
        y=y,
        threshold=np.full(oracle.size, 1e-9),
        refreshes=6,
        persistent_factor=True,
    )
    restarted = run_num_jac_refresh_probe(
        fun=oracle.rhs,
        analytic_jacobian=oracle.jacobian,
        t=0.0,
        y=y,
        threshold=np.full(oracle.size, 1e-9),
        refreshes=6,
        persistent_factor=False,
    )
    assert persistent.records[-1].max_factor_over_sqrt_eps > restarted.records[-1].max_factor_over_sqrt_eps
