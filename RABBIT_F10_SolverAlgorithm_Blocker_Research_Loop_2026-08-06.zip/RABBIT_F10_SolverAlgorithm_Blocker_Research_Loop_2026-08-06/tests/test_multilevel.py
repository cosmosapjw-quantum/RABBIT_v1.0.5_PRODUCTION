import numpy as np

from f10_solver_research.grids import Grid, build_transfer_pair
from f10_solver_research.models import ManufacturedKineticModel
from f10_solver_research.solvers.jfnk import solve_implicit_euler_jfnk
from f10_solver_research.solvers.multilevel import (
    CoarseTrajectoryPredictor,
    TwoLevelPreconditioner,
    solve_mlpc_jfnk,
)


def _wrms(vector: np.ndarray) -> float:
    return float(np.linalg.norm(vector) / np.sqrt(vector.size))


def test_coarse_trajectory_predictor_maps_to_fine_manufactured_path():
    coarse_grid = Grid.gauss_legendre(8, 8.0)
    fine_grid = Grid.gauss_legendre(12, 8.0)
    transfer = build_transfer_pair(coarse_grid, fine_grid)
    coarse_model = ManufacturedKineticModel(coarse_grid)
    fine_model = ManufacturedKineticModel(fine_grid)
    predictor = CoarseTrajectoryPredictor.build(
        coarse_model=coarse_model,
        transfer=transfer,
        t_span=(0.0, 0.5),
        fine_initial=fine_model.exact_state(0.0),
        rtol=1e-10,
        atol=1e-12,
    )
    predicted = predictor.predict(0.37)
    assert predicted.shape == (fine_model.state_size,)
    assert _wrms(predicted - fine_model.exact_state(0.37)) < 2e-4
    assert predictor.nfev > 0


def test_two_level_preconditioner_smooths_restriction_nullspace_component():
    coarse_grid = Grid.gauss_legendre(6, 6.0)
    fine_grid = Grid.gauss_legendre(10, 6.0)
    transfer = build_transfer_pair(coarse_grid, fine_grid)
    coarse_matrix = np.eye(transfer.coarse_state_size)
    fine_diagonal = np.linspace(1.5, 3.0, transfer.fine_state_size)
    preconditioner = TwoLevelPreconditioner(
        transfer=transfer,
        coarse_residual_matrix=coarse_matrix,
        fine_residual_diagonal=fine_diagonal,
    )
    raw = np.sin(np.arange(transfer.fine_state_size, dtype=np.float64))
    high = raw - transfer.prolong_state(transfer.restrict_state(raw))
    applied = preconditioner.apply(high)
    expected = high / fine_diagonal
    np.testing.assert_allclose(applied, expected, rtol=1e-10, atol=1e-11)
    assert preconditioner.applications == 1


def test_mlpc_jfnk_enforces_exact_fine_implicit_residual():
    coarse_grid = Grid.gauss_legendre(8, 8.0)
    fine_grid = Grid.gauss_legendre(12, 8.0)
    transfer = build_transfer_pair(coarse_grid, fine_grid)
    coarse_model = ManufacturedKineticModel(coarse_grid)
    fine_model = ManufacturedKineticModel(fine_grid)
    h = 0.04

    def fine_diagonal(t, state, step):
        return np.diag(np.eye(fine_model.state_size) - step * fine_model.jacobian(t, state))

    result = solve_mlpc_jfnk(
        fine_fun=fine_model.rhs_true,
        coarse_model=coarse_model,
        transfer=transfer,
        t_span=(0.0, 0.16),
        fine_initial=fine_model.exact_state(0.0),
        step_size=h,
        fine_residual_diagonal=fine_diagonal,
        newton_rtol=2e-9,
        gmres_rtol=1e-8,
    )
    assert result.success, result.reason
    for index in range(result.stats.steps):
        t_new = result.t[index + 1]
        step = t_new - result.t[index]
        residual = (
            result.y[:, index + 1]
            - result.y[:, index]
            - step * fine_model.rhs_true(t_new, result.y[:, index + 1])
        )
        assert _wrms(residual) < 2e-8


def test_mlpc_reduces_fine_gmres_iterations_against_direct_jfnk():
    coarse_grid = Grid.gauss_legendre(10, 10.0)
    fine_grid = Grid.gauss_legendre(16, 10.0)
    transfer = build_transfer_pair(coarse_grid, fine_grid)
    coarse_model = ManufacturedKineticModel(
        coarse_grid, nonnormal_strength=18.0, nonlinear_strength=0.05
    )
    fine_model = ManufacturedKineticModel(
        fine_grid, nonnormal_strength=18.0, nonlinear_strength=0.05
    )
    y0 = fine_model.exact_state(0.0)
    h = 0.08

    direct = solve_implicit_euler_jfnk(
        fine_model.rhs_true,
        (0.0, 0.24),
        y0,
        step_size=h,
        newton_rtol=2e-9,
        gmres_rtol=1e-8,
        jvp_relative_step=2e-6,
    )

    def fine_diagonal(t, state, step):
        return np.diag(np.eye(fine_model.state_size) - step * fine_model.jacobian(t, state))

    multilevel = solve_mlpc_jfnk(
        fine_fun=fine_model.rhs_true,
        coarse_model=coarse_model,
        transfer=transfer,
        t_span=(0.0, 0.24),
        fine_initial=y0,
        step_size=h,
        fine_residual_diagonal=fine_diagonal,
        newton_rtol=2e-9,
        gmres_rtol=1e-8,
        jvp_relative_step=2e-6,
    )
    assert direct.success and multilevel.success
    assert multilevel.stats.linear_iterations < direct.stats.linear_iterations
    assert multilevel.stats.extra["two_level_applications"] > 0
