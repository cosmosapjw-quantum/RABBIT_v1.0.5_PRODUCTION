# Formal Sweep Adjudication 01 — mechanical corrections only

The first formal output is preserved under `results/formal_v1`. Review found three
non-parameter defects:

1. `EC-D-JFNK` accumulated `0.0005` in binary and executed one terminal step of
   `2.8e-17`; this changes six-ish calls but cannot change any gate.
2. The algorithmic screen reported the full-state spectral abscissa, so the exact
   energy/clock zero modes obscured the intended spectral-block abscissa near `-5.75`.
3. Failed lanes marked occupations false without inspecting their retained partial states,
   and SciPy controls reported zero stored steps because `t_eval=[t_end]` discarded the
   internal mesh.

Authorized correction:
- use a precomputed fixed-step schedule with an exact terminal endpoint;
- compute both full-state and spectral-block spectra, with `1e-12` instability tolerance;
- inspect retained occupations even on failed lanes;
- retain the SciPy control mesh.

No candidate parameter, threshold, cancellation scale, holdout interval, or adjudication
rule changes. The v1 and v2 results must both remain durable, and any status difference
would be a blocking finding.
