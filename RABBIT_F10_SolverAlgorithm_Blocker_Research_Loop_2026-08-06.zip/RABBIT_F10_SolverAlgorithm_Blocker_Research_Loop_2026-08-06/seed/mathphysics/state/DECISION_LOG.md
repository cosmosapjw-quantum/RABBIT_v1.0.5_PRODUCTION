# DECISION_LOG

## D-001
DATE: 2026-08-06
DECISION: `reject`
OBJECT: Jacobian pin/cap, direct Jacobian, AP preconditioner or solver swap as the complete D-071 reopening route.
EVIDENCE_REVIEWED: D-071, V3, existing AP/JAX prototypes, external direct-Jacobian literature.
RATIONALE: diagnostically useful but explicitly excluded as a faster implementation; measured local variants do not close the operating gap.
ALTERNATIVES_CONSIDERED: exact-structure and reduced-model routes.
UNRESOLVED_RISKS: these tools may still be needed inside a new method.
NEXT_GATE: none as stand-alone route.

## D-002
DATE: 2026-08-06
DECISION: `hold`
OBJECT: three-parameter entropic manifold.
EVIDENCE_REVIEWED: Birrell, Bond, frozen endpoint compression probe.
RATIONALE: plausible representation/conditioning knee, but one endpoint cannot establish trajectory invariance.
ALTERNATIVES_CONSIDERED: 2p, 4–6p, polynomial logistic fit, full spectral state.
UNRESOLVED_RISKS: creep-state defect, inverse-map conditioning, collision-moment error.
NEXT_GATE: retained trajectory coverage.

## D-003
DATE: 2026-08-06
DECISION: `reject`
OBJECT: equilibrium energy-tail fraction as the T13 domain certificate.
EVIDENCE_REVIEWED: incomplete-gamma tail table k=2..10.
RATIONALE: high-order collision moments are much larger; direct/source/feedback channels must be separated.
ALTERNATIVES_CONSIDERED: reaction-aware three-channel bound.
UNRESOLVED_RISKS: reaction envelope constants.
NEXT_GATE: Gate D.

## D-004
DATE: 2026-08-06
DECISION: `reopen`
OBJECT: ECEM-3C for further validation only.
EVIDENCE_REVIEWED: full research loop reports and probes.
RATIONALE: only candidate addressing structure, state dimension, domain error, nonnormality and fold outputs together.
ALTERNATIVES_CONSIDERED: all H-001..H-015.
UNRESOLVED_RISKS: listed in Gate A–F.
NEXT_GATE: external review of static Gates A–D; no gate movement.


## D-005
DATE: 2026-08-06
DECISION: `hold`
OBJECT: ECEM-3C material-novelty claim relative to D-029.
EVIDENCE_REVIEWED: retained external audit, D-029 chronology and reconstructed operation graph, ECEM-3C formalization.
RATIONALE: D-029 is a target-dependent local three-node deposition; ECEM-3C is a fixed global state manifold. The distinction is credible, but the four original D-029 envelopes are missing.
ALTERNATIVES_CONSIDERED: declare novelty closed from the summary; reject ECEM-3C by name similarity alone.
UNRESOLVED_RISKS: hidden operation-level overlap in the unavailable raw artifacts; future adaptive support could silently recreate D-029.
NEXT_GATE: Gate A0 raw-envelope comparison before external promotion.
