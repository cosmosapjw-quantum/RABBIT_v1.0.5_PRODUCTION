# HYPOTHESIS_GRAPH

See `research_artifacts/reports/03_DIVERGENT_HYPOTHESIS_TREE.md` for the full tree.

## H-016 — ECEM-3C

CORE_CLAIM: A seven-state energy-constrained entropic moment system with conservative collision accounting and three-channel/goal-oriented certification can become a materially new independent-FLRW validation instrument.
MINIMAL_ASSUMPTIONS: massless no-QKE regime; exact mu–tau degeneracy; monotone EM EOS; realizable three-moment map; projected entropy dissipation; reaction-wise exponential tail envelope.
MECHANISM: eliminate exchange cancellation through W, compress spectra through realizable moments, control micro/tail error in an entropy/adjoint framework.
KNOWN_LIMITS: no D-029 raw-envelope novelty closure, no creep-state collision-manifold coverage, and no end-to-end bound yet.
DISTINCTIVE_PREDICTIONS: no BDF order-1 creep; <=5,500 full-cost collision calls; certified fold-level error below gate slack.
COMPETING_HYPOTHESES: direct Jacobian/AP repair; published averaged model; higher-dimensional spectral solver.
DECISIVE_TEST: Gate A0 historical novelty closure followed by prospectively sealed Gates A-F in report 06.
SUPPORTING_EVIDENCE: E-004, E-006–E-014.
THREATENING_EVIDENCE: E-005, E-009–E-011, E-015.
STATUS: hold / reopen-validation.

## Supporting hypotheses
H-001 energy coordinate; H-003 conservation projection; H-005 entropic manifold; H-006 invariant correction; H-008 tail certificate; H-009 entropy tube; H-010 adjoint output; H-011 certified hyper-reduction.

## Rejected primary routes
H-007 DLR; H-012 direct averaged-model replacement; H-013 late freeze-out stop; H-014 Jacobian/AP only; H-015 generic hardware/solver.
