# EVIDENCE_LEDGER

| Evidence ID | Claim ID | Source | Exact support | Status | Reliability | Assumptions | Conflicts | Notes |
|---|---|---|---|---|---|---|---|---|
| E-001 | C-001 | D-071 | Order-60/ymax30 exhausted 64,800 s near N=0.163 without scientific checks | supports | high | frozen retained bytes |  | Instrument, not physics |
| E-002 | C-002 | V3 | Ratchet, corrupted columns, Newton failures and order-1 loop measured; true operator Hurwitz | supports/limits | high | diagnostic claim ceiling | causality not controlled | Local repair excluded |
| E-003 | C-003 | _trajectory_core.py | Current Tgamma ODE contains exchange term; diagnostic states exact W identity | supports | high | massless neutrinos |  | Direct source |
| E-004 | C-004 | Wolfram symbolic check | Wprime=exp(4N)(rhoEM-3PEM); implicit T derivatives | supports | high | continuous conservation |  | Saved WL script |
| E-005 | C-004 | energy_coordinate_probe.json | Eigenvalues invariant; log norm can improve or worsen with scaling | limits | medium | toy linear model |  | Rejects overclaim |
| E-006 | C-005 | Birrell et al. 1403.2019 | Dynamic T/fugacity basis captures number and energy at lowest order | supports | high | model setting differs |  | Primary literature |
| E-007 | C-005 | Bond et al. 2403.19038 | Three parameters/species accurately represent SM spectra | supports | high | representation not certificate |  | Primary literature |
| E-008 | C-006 | compression_probe.json | 3p endpoint moment match and error/conditioning measurements | supports/limits | medium | single endpoint |  | Exploratory |
| E-009 | C-006 | compression_probe.json | 4-6p condition grows by orders of magnitude without monotone error gain | limits | medium | unscaled coordinates |  | Condition is coordinate-dependent |
| E-010 | C-007 | tail_bounds.json | Y30 k3 tail 4.92e-10; k8-k10 up to 2.24e-5 | supports/contradicts | high | equilibrium FD envelope |  | Three-channel proof required |
| E-011 | C-008 | nonnormal_probe.json | Hurwitz matrices with transient amplification up to 19.2 | contradicts | high | explicit 2x2 counterexample |  | Eigenvalues insufficient |
| E-012 | C-009 | compression_probe.json | 182 to 121 states; dimension-only dense-FD speedup about 1.5 | supports/limits | high | exact mutau symmetry |  | Supporting only |
| E-013 | C-010 | Gamba-Jin-Liu 1809.00028 | Micro-macro AP with exact moment conservation exists in general kinetic systems | contextual/supports | high | different equation |  | Structural precedent |
| E-014 | C-010 | Certified RB/DWR literature | Nonlinear reduced models can carry a posteriori output bounds | contextual/supports | high | assumptions not transferred |  | Framework precedent |
| E-015 | C-011 | No candidate Gate-E run | Completion within 18 h is unmeasured | missing | high |  |  | Blocks promotion |
| E-016 | C-012 | D-071 reopen conditions | New method + prospective contract + bounded stalled-phase discriminator required | supports | high |  |  | Controlling contract |

| E-017 | C-010 | retained `BD622_F10_external_audit_report.md` | D-029 fixed-triple theorem sound; target-dependent selector/one-hot branch lacked a global continuous covariant semidiscrete proof | supports/limits | medium-high | original D-029 envelopes absent | superficial MaxEnt similarity | Operation-level distinction, not final novelty proof |
| E-018 | C-010 | execution record in `VALIDATION_LOG.txt` | Complete local source snapshot unavailable; clone failed; collision invariance defect not executed | missing | high | prospective execution boundary |  | Missing evidence, not scientific failure |

Status vocabulary used: supports / contradicts / limits / contextual / missing.
