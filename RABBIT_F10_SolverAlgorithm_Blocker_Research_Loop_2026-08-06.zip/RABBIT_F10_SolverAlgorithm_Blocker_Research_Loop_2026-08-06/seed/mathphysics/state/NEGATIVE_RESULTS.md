# NEGATIVE_RESULTS

## N-001 — Exact symmetry reduction alone
ATTEMPT: remove mu–tau duplication and cosmic-time state.
WHY_IT_WAS_TRIED: exact, cheap and physics-preserving.
RESULT: 182 states become 121; dense-FD dimension-only gain is about 1.5×.
WHY_IT_FAILED: far below the evaluation-count miss.
WHAT_IT_RULES_OUT: symmetry reduction as a stand-alone reopening method.
WHETHER_TO_REVISIT: yes, as a supporting component.

## N-002 — Energy coordinate deletes stiffness
ATTEMPT: replace plasma temperature by total comoving energy.
RESULT: exact eigenvalues are unchanged; logarithmic norm improves only for favorable scaling.
WHY_IT_FAILED: coordinate transformations do not remove physical fast eigenvalues.
WHAT_IT_RULES_OUT: an unmeasured claim of automatic speedup.
WHETHER_TO_REVISIT: yes, with creep-state metric tests.

## N-003 — Energy tail closes T13
ATTEMPT: use the tiny equilibrium k=3 tail beyond y=30.
RESULT: k=8..10 tails reach 2e-6..2e-5.
WHY_IT_FAILED: collision kernels and feedback can weight higher moments.
WHAT_IT_RULES_OUT: scalar thermodynamic-tail certification.
WHETHER_TO_REVISIT: only as one channel of a reaction-aware proof.

## N-004 — Stable eigenvalues imply safe reduction
ATTEMPT: interpret V3's abscissa near -5.75 as contraction.
RESULT: explicit nonnormal matrices with the same eigenvalues amplify perturbations by up to 19.2.
WHY_IT_FAILED: spectral abscissa does not bound transient growth.
WHAT_IT_RULES_OUT: eigenvalue-only defect propagation.
WHETHER_TO_REVISIT: use a weighted entropy/Lyapunov metric.

## N-005 — More entropic moments are automatically better
ATTEMPT: match 2 through 6 moments at the endpoint.
RESULT: fit error does not improve monotonically and inverse-map condition grows to 1e6–1e7.
WHY_IT_FAILED: high-order moment inversion is ill-conditioned and overfits a single state.
WHAT_IT_RULES_OUT: dimension escalation without a conditioning/holdout gate.
WHETHER_TO_REVISIT: one predeclared 4p comparator only.

## N-006 — Published fast averaged model as qualifying substitute
RESULT: literature reports strong integrated-observable accuracy, but no project-specific fold-level certificate.
WHAT_IT_RULES_OUT: importing the external percent figure as a G-F10 pass.
WHETHER_TO_REVISIT: baseline/control only.

## N-007 — Late free-streaming patch
RESULT: primary stall occurs near N=0.163, before late free streaming.
WHAT_IT_RULES_OUT: late termination as the main blocker solution.
WHETHER_TO_REVISIT: downstream optimization after reopening.

## N-008 — DSMC
RESULT: not explored as a candidate under the user's standing exclusion, motivated by convergence concerns for later Bianchi/shear extensions.
WHETHER_TO_REVISIT: no in this project lane.


## N-009 — Name-level MaxEnt novelty inference
ATTEMPT: infer that ECEM-3C is either novel or already rejected merely because both it and D-029 use entropy/three low-dimensional quantities.
RESULT: operation-level audit separates them: D-029 was a target-dependent local three-node deposition; ECEM-3C is a fixed global state manifold.
WHY_IT_FAILED: method identity is determined by the operation graph, not naming.
WHAT_IT_RULES_OUT: both automatic rejection by superficial similarity and automatic novelty by relabelling.
WHETHER_TO_REVISIT: yes, using the four original D-029 envelopes at Gate A0.
