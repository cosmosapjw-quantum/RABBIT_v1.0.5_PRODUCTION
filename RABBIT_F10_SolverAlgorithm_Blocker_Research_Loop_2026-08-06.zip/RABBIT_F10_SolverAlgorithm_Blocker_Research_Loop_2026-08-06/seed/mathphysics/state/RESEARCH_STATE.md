# RESEARCH_STATE

PROJECT: RABBIT F10 Independent-FLRW Mathematical-Physics Blocker Resolution
VERSION: 1.0-research-loop
CURRENT_PHASE: closed-after-provisional-external-gate
LAST_UPDATED: 2026-08-06

## Primary question

PRIMARY_RQ: Can a materially new mathematical-physics formulation replace the stalled independent-FLRW trajectory instrument and prospectively fit within the frozen 18 h wall budget while carrying a gate-level error certificate?

## Subquestions

- Can total comoving energy replace the fragile plasma-temperature exchange ODE?
- Does a two-species three-moment entropic manifold cover the creep trajectory?
- Can the omitted momentum domain be bounded in direct, source and feedback channels?
- Is there a usable entropy/Lyapunov metric despite nonnormality?
- Can a sealed stalled-phase discriminator prove a <=5,500-call full-trajectory bound?

## Scope

IN_SCOPE: mathematical reformulation, entropic/moment reduction, prospectively defined method-internal conservative correction, reaction-aware tail bounds, output certification, short retained-data/toy probes.
OUT_OF_SCOPE: harness repair, generic solver/hardware reopening, source edits, full implementation, QKE, public-production claims, DSMC.

## Hypothesis status

ACTIVE_HYPOTHESES: H-001, H-003, H-005, H-006, H-008, H-009, H-010, H-011, H-016.
PROMOTED: none.
ON_HOLD: H-016 ECEM-3C (`REOPEN_VALIDATION`).
REJECTED: H-007 primary DLR, H-012 direct averaged-model substitution, H-013 late-stop primary route, H-014 stand-alone Jacobian/AP, H-015 hardware/solver.

## Blockers

KEY_BLOCKERS: D-029 raw novelty comparison; creep-state manifold coverage; real collision invariance defect; discrete conservation equivalence; weighted stability/tube constants; reaction-tail feedback; fold-level adjoint error; prospective runtime discriminator.
MISSING_EVIDENCE: listed in reports 02, 05 and 06.

## Gate

CURRENT_COMPLETION_BAR: research loop complete; D-071 reopen not earned.
NEXT_GATE: Gate A0 historical novelty closure, then static Gates A-D on retained full states, independently reviewed.
NEXT_MINIMAL_ACTION: recover/compare the D-029 envelopes, then compute the predeclared energy/manifold/metric/tail package from retained checkpoints; do not launch a full candidate trajectory.
