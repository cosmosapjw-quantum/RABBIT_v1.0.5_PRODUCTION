from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)


def load(name: str):
    return json.loads((RESULTS / name).read_text(encoding="utf-8"))


def compression_error() -> None:
    data = load("compression_probe.json")["species"]
    plt.figure(figsize=(7.2, 4.8))
    for name, species in data.items():
        x = list(range(2, 7))
        y = [species[f"moment_matched_tail_compatible_entropic_{n}p"]["energy_weighted_L1"] for n in x]
        plt.semilogy(x, y, marker="o", label=name)
    plt.xlabel("Entropic manifold parameters per species")
    plt.ylabel("Energy-weighted relative L1 error")
    plt.title("Frozen endpoint compression: accuracy versus dimension")
    plt.grid(True, which="both", alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / "compression_error.png", dpi=180)
    plt.close()


def conditioning() -> None:
    data = load("compression_probe.json")["species"]
    plt.figure(figsize=(7.2, 4.8))
    for name, species in data.items():
        x = list(range(2, 7))
        y = [species[f"moment_matched_tail_compatible_entropic_{n}p"]["jacobian_condition"] for n in x]
        plt.semilogy(x, y, marker="o", label=name)
    plt.xlabel("Entropic manifold parameters per species")
    plt.ylabel("Moment-map Jacobian condition number")
    plt.title("Inverse moment map becomes rapidly ill-conditioned")
    plt.grid(True, which="both", alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / "moment_map_conditioning.png", dpi=180)
    plt.close()


def tails() -> None:
    data = load("tail_bounds.json")
    plt.figure(figsize=(7.2, 4.8))
    for cutoff, rows in data.items():
        plt.semilogy(
            [r["k"] for r in rows],
            [r["exact_relative_to_full_moment"] for r in rows],
            marker="o",
            label=f"Y={cutoff}",
        )
    plt.xlabel("Moment power k")
    plt.ylabel("Fermi-Dirac tail fraction")
    plt.title("High-order moments amplify the omitted momentum tail")
    plt.grid(True, which="both", alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / "tail_fraction_by_moment.png", dpi=180)
    plt.close()


def nonnormal() -> None:
    rows = load("nonnormal_probe.json")["rows"]
    plt.figure(figsize=(7.2, 4.8))
    plt.semilogy([r["M"] for r in rows], [r["max_transient_norm_0_3"] for r in rows], marker="o")
    plt.xlabel("Off-diagonal coupling M")
    plt.ylabel("max ||exp(A t)||_2 on 0<=t<=3")
    plt.title("Identical stable eigenvalues can hide large transient growth")
    plt.grid(True, which="both", alpha=0.25)
    plt.tight_layout()
    plt.savefig(FIG / "nonnormal_transient_growth.png", dpi=180)
    plt.close()


def energy_coordinates() -> None:
    rows = load("energy_coordinate_probe.json")["rows"]
    plt.figure(figsize=(7.2, 4.8))
    x = [r["heat_capacity_C"] for r in rows]
    plt.semilogx(x, [r["mu2_original"] for r in rows], marker="o", label="(x,T) coordinate")
    plt.semilogx(x, [r["mu2_energy"] for r in rows], marker="o", label="(x,W) coordinate")
    plt.axhline(0.0, linewidth=1.0)
    plt.xlabel("Heat capacity ratio C")
    plt.ylabel("Euclidean logarithmic norm mu_2")
    plt.title("Energy-coordinate benefit is scaling-dependent, not automatic")
    plt.grid(True, which="both", alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIG / "energy_coordinate_log_norm.png", dpi=180)
    plt.close()


if __name__ == "__main__":
    compression_error()
    conditioning()
    tails()
    nonnormal()
    energy_coordinates()
    print(FIG)
