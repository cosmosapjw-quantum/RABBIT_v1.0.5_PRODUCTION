from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def load(name: str):
    return json.loads((RESULTS / name).read_text(encoding="utf-8"))


def test_tail_bracketing_and_monotonicity() -> None:
    data = load("tail_bounds.json")
    for cutoff, rows in data.items():
        previous = 0.0
        for row in rows:
            tol = 5e-15 * max(1.0, abs(row["exact"]))
            assert row["two_term_lower"] <= row["exact"] + tol
            assert row["exact"] <= row["upper_gamma"] + tol
            assert row["exact_relative_to_full_moment"] > previous
            previous = row["exact_relative_to_full_moment"]
        assert float(cutoff) > 0.0


def test_energy_coordinate_is_exact_change_of_variables() -> None:
    data = load("energy_coordinate_probe.json")
    for row in data["rows"]:
        scale = max(abs(z[0]) for z in row["eigenvalues_original"])
        assert row["eigenvalue_invariance_max_abs"] / max(scale, 1.0) < 5e-13


def test_hurwitz_does_not_imply_euclidean_contraction() -> None:
    data = load("nonnormal_probe.json")
    severe = [row for row in data["rows"] if row["M"] >= 100]
    assert severe
    for row in severe:
        assert row["spectral_abscissa"] < 0.0
        assert row["mu2"] > 0.0
        assert row["max_transient_norm_0_3"] > 1.0
        assert row["mu_P"] < 0.0


def test_entropic_family_is_realizable_and_moment_matched() -> None:
    data = load("compression_probe.json")
    for species in data["species"].values():
        for n in range(2, 7):
            row = species[f"moment_matched_tail_compatible_entropic_{n}p"]
            assert row["optimizer_success"]
            assert row["min_pred"] > 0.0
            assert row["max_pred"] < 1.0
            assert row["inverse_temperature_slope_b"] > 0.0
            assert row["moment_residual_inf"] < 1e-10


def test_exact_symmetry_reduction_cannot_close_runtime_gap_alone() -> None:
    row = load("compression_probe.json")["mu_tau_exact_state_reduction"]
    assert row["maximum_dense_fd_speedup_from_dimension_alone"] < 2.0
    assert row["order_60_mu_tau_without_time_state"] == 121
