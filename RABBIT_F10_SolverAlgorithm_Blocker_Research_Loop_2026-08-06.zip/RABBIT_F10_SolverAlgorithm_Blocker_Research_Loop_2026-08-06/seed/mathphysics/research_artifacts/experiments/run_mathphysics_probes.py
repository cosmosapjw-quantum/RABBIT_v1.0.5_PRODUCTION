#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.linalg import expm, solve_continuous_lyapunov, eigvalsh
from scipy.optimize import least_squares
from scipy.special import gamma, gammaincc, zeta

from endpoint_anchor import RUST_SPECTRUM

OUT = Path(__file__).resolve().parents[1] / "results"
OUT.mkdir(parents=True, exist_ok=True)


def logit(f: np.ndarray) -> np.ndarray:
    return np.log(f) - np.log1p(-f)


def expit_stable(x: np.ndarray) -> np.ndarray:
    out = np.empty_like(x)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out


def fit_logistic_poly(y: np.ndarray, w: np.ndarray, f: np.ndarray, degree: int) -> tuple[np.ndarray, np.ndarray]:
    scale = 10.0
    x = y / scale
    V = np.vander(x, N=degree + 1, increasing=True)
    target_u = logit(f)
    # Initial fit in logit space, weighted toward number/energy-carrying bins.
    base_weight = np.maximum(w * y**3 * f * (1.0 - f), 1e-30)
    a0, *_ = np.linalg.lstsq(V * np.sqrt(base_weight)[:, None], target_u * np.sqrt(base_weight), rcond=None)
    norm = max(float(np.sum(w * y**3 * f)), np.finfo(float).tiny)

    def resid(a: np.ndarray) -> np.ndarray:
        pred = expit_stable(V @ a)
        return np.sqrt(w * y**3 / norm) * (pred - f)

    result = least_squares(resid, a0, method="trf", xtol=1e-14, ftol=1e-14, gtol=1e-14, max_nfev=20000)
    return result.x, expit_stable(V @ result.x)


def fit_raw_legendre(y: np.ndarray, w: np.ndarray, f: np.ndarray, degree: int) -> tuple[np.ndarray, np.ndarray]:
    x = 2.0 * y / y.max() - 1.0
    V = np.polynomial.legendre.legvander(x, degree)
    wt = np.maximum(w * y**3, 1e-30)
    coeff, *_ = np.linalg.lstsq(V * np.sqrt(wt)[:, None], f * np.sqrt(wt), rcond=None)
    return coeff, V @ coeff


def metrics(y: np.ndarray, w: np.ndarray, f: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    result: dict[str, float] = {}
    for k in (2, 3, 4, 5):
        truth = float(np.sum(w * y**k * f))
        approx = float(np.sum(w * y**k * pred))
        result[f"moment{k}_rel"] = abs(approx - truth) / max(abs(truth), np.finfo(float).tiny)
    result["energy_weighted_L1"] = float(np.sum(w * y**3 * np.abs(pred - f)) / np.sum(w * y**3 * f))
    result["max_abs"] = float(np.max(np.abs(pred - f)))
    result["min_pred"] = float(np.min(pred))
    result["max_pred"] = float(np.max(pred))
    result["tail_last3_energy_rel"] = float(
        np.sum(w[-3:] * y[-3:]**3 * np.abs(pred[-3:] - f[-3:])) / np.sum(w * y**3 * f)
    )
    return result



def fit_moment_matched_bounded_family(
    y: np.ndarray,
    w: np.ndarray,
    f: np.ndarray,
    n_params: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, object]]:
    """Moment-match a positive exponential family with an FD-compatible tail.

    The logit is

        u(y) = a0 - exp(beta) y + sum_{j=1}^{n_params-2} a_{j+1} phi(y)^j,
        phi(y)=y/(1+y).

    The bounded shape functions leave the asymptotic slope negative, unlike a
    polynomial in y.  With n_params parameters the family matches moments
    k=2,...,n_params+1.  This is an endpoint feasibility probe, not a
    trajectory closure or a rigorous surrogate certificate.
    """
    if n_params < 2:
        raise ValueError("n_params must be at least two")
    ks = tuple(range(2, n_params + 2))
    truth = np.array([np.sum(w * y**k * f) for k in ks], dtype=float)
    phi = y / (1.0 + y)

    def pred_from(z: np.ndarray) -> np.ndarray:
        u = z[0] - np.exp(z[1]) * y
        for j, coeff in enumerate(z[2:], start=1):
            u = u + coeff * phi**j
        return expit_stable(u)

    def residual(z: np.ndarray) -> np.ndarray:
        pred = pred_from(z)
        vals = np.array([np.sum(w * y**k * pred) for k in ks])
        return np.log(vals / truth)

    z0 = np.zeros(n_params, dtype=float)
    sol = least_squares(
        residual, z0, method="trf", xtol=1e-14, ftol=1e-14, gtol=1e-14,
        max_nfev=50000, x_scale="jac",
    )
    pred = pred_from(sol.x)
    physical: dict[str, object] = {
        "n_parameters": n_params,
        "matched_moments": list(ks),
        "log_fugacity_a0": float(sol.x[0]),
        "inverse_temperature_slope_b": float(np.exp(sol.x[1])),
        "bounded_shape_coefficients": [float(x) for x in sol.x[2:]],
        "parameter_l2_norm": float(np.linalg.norm(sol.x)),
        "jacobian_condition": float(np.linalg.cond(sol.jac)) if sol.jac.size else float("inf"),
        "moment_residual_inf": float(np.max(np.abs(residual(sol.x)))),
        "optimizer_success": bool(sol.success),
        "optimizer_message": str(sol.message),
    }
    return sol.x, pred, physical



def compression_probe() -> dict:
    y, w, fe, fx = RUST_SPECTRUM.T
    out: dict[str, object] = {
        "source_shape": list(RUST_SPECTRUM.shape),
        "y_max": float(y.max()),
        "species": {},
        "mu_tau_exact_state_reduction": {
            "order_60_original_states": 3 * 60 + 2,
            "order_60_mu_tau_states": 2 * 60 + 2,
            "order_60_mu_tau_without_time_state": 2 * 60 + 1,
        },
    }
    for name, f in (("nu_e", fe), ("nu_x", fx)):
        species: dict[str, object] = {}
        f0 = 1.0 / (np.exp(y) + 1.0)
        species["equilibrium_baseline"] = metrics(y, w, f, f0)
        for n_params in range(2, 7):
            _, mpred, physical = fit_moment_matched_bounded_family(y, w, f, n_params)
            label = f"moment_matched_tail_compatible_entropic_{n_params}p"
            species[label] = {**physical, **metrics(y, w, f, mpred)}
        for degree in range(1, 6):
            coeff, pred = fit_logistic_poly(y, w, f, degree)
            species[f"logistic_poly_degree_{degree}"] = {
                "parameters": [float(x) for x in coeff],
                **metrics(y, w, f, pred),
            }
            rcoeff, rpred = fit_raw_legendre(y, w, f, degree)
            species[f"raw_legendre_degree_{degree}"] = {
                "parameters": [float(x) for x in rcoeff],
                **metrics(y, w, f, rpred),
            }
        ratio = f / f0
        species["tail_envelope_endpoint"] = {
            "ratio_at_last_5_nodes": [float(x) for x in ratio[-5:]],
            "max_ratio_y_ge_10": float(np.max(ratio[y >= 10.0])),
            "min_ratio_y_ge_10": float(np.min(ratio[y >= 10.0])),
            "energy_share_y_ge_10": float(np.sum(w[y >= 10] * y[y >= 10] ** 3 * f[y >= 10]) / np.sum(w * y**3 * f)),
        }
        out["species"][name] = species
    # Exact state/Jacobian-column arithmetic only; not a runtime prediction.
    n0 = 3 * 60 + 2
    n1 = 2 * 60 + 1
    out["mu_tau_exact_state_reduction"].update({
        "state_fraction": n1 / n0,
        "dense_fd_columns_fraction_approx": (n1 + 1) / (n0 + 1),
        "maximum_dense_fd_speedup_from_dimension_alone": (n0 + 1) / (n1 + 1),
    })
    return out


def fd_full_moment(k: int) -> float:
    # integral_0^inf y^k/(e^y+1) dy = (1-2^-k) Gamma(k+1) zeta(k+1), k>0.
    return float((1.0 - 2.0 ** (-k)) * gamma(k + 1) * zeta(k + 1))


def upper_gamma_integer(k: int, Y: float) -> float:
    return float(gamma(k + 1) * gammaincc(k + 1, Y))


def tail_probe() -> dict:
    result: dict[str, object] = {}
    for Y in (24.0, 30.0):
        rows = []
        for k in range(2, 11):
            exact, _ = quad(
                lambda x: x**k * np.exp(-x) / (1.0 + np.exp(-x)),
                Y, np.inf, epsabs=1e-300, epsrel=1e-12, limit=500,
            )
            upper = upper_gamma_integer(k, Y)
            lower = upper - (2.0 ** (-(k + 1))) * upper_gamma_integer(k, 2.0 * Y)
            full = fd_full_moment(k)
            rows.append({
                "k": k,
                "exact": float(exact),
                "upper_gamma": upper,
                "two_term_lower": lower,
                "upper_over_exact": upper / exact,
                "exact_relative_to_full_moment": exact / full,
                "upper_relative_to_full_moment": upper / full,
            })
        result[str(int(Y))] = rows
    return result


def generalized_log_norm(A: np.ndarray, P: np.ndarray) -> float:
    L = np.linalg.cholesky(P)
    Linv = np.linalg.inv(L)
    sym = 0.5 * (A.T @ P + P @ A)
    transformed = Linv @ sym @ Linv.T
    return float(np.max(eigvalsh(transformed)))


def nonnormal_probe() -> dict:
    alpha = 5.75
    rows = []
    times = np.linspace(0.0, 3.0, 6001)
    for M in (0.0, 10.0, 20.0, 100.0, 300.0):
        A = np.array([[-alpha, M], [0.0, -alpha]], dtype=float)
        norms = np.array([np.linalg.norm(expm(A * t), 2) for t in times])
        idx = int(np.argmax(norms))
        P = solve_continuous_lyapunov(A.T, -np.eye(2))
        rows.append({
            "M": M,
            "spectral_abscissa": float(np.max(np.real(np.linalg.eigvals(A)))),
            "mu2": float(np.max(eigvalsh(0.5 * (A + A.T)))),
            "max_transient_norm_0_3": float(norms[idx]),
            "time_of_max": float(times[idx]),
            "lyapunov_P_condition": float(np.linalg.cond(P)),
            "mu_P": generalized_log_norm(A, P),
        })
    return {"alpha": alpha, "rows": rows}


def energy_coordinate_probe() -> dict:
    # Linear exchange model preserving W=x+C*T when eps=0.
    # x'=-K(x-aT), T'=K/C(x-aT)-eps*T.
    rows = []
    K = 1.0e4
    a = 1.0
    eps = 1.0
    for C in (1e-3, 1e-1, 1.0, 10.0, 1e3):
        A = np.array([[-K, K * a], [K / C, -K * a / C - eps]], dtype=float)
        S = np.array([[1.0, 0.0], [1.0, C]], dtype=float)  # z=(x,W=x+C*T)
        Az = S @ A @ np.linalg.inv(S)
        eigA = np.sort_complex(np.linalg.eigvals(A))
        eigZ = np.sort_complex(np.linalg.eigvals(Az))
        rows.append({
            "heat_capacity_C": C,
            "original_matrix": A.tolist(),
            "energy_coordinate_matrix": Az.tolist(),
            "eigenvalues_original": [[float(z.real), float(z.imag)] for z in eigA],
            "eigenvalues_energy": [[float(z.real), float(z.imag)] for z in eigZ],
            "eigenvalue_invariance_max_abs": float(np.max(np.abs(eigA - eigZ))),
            "mu2_original": float(np.max(eigvalsh(0.5 * (A + A.T)))),
            "mu2_energy": float(np.max(eigvalsh(0.5 * (Az + Az.T)))),
            "eigenvector_condition_original": float(np.linalg.cond(np.linalg.eig(A)[1])),
            "eigenvector_condition_energy": float(np.linalg.cond(np.linalg.eig(Az)[1])),
        })
    return {
        "model": "x'=-K(x-aT), T'=K/C(x-aT)-eps*T, W=x+C*T",
        "K": K,
        "a": a,
        "eps": eps,
        "rows": rows,
        "interpretation": "The exact energy coordinate preserves eigenvalues (a coordinate change cannot delete physical stiffness) but can change nonnormality/scaling and makes W'=-eps*(W-x)/C explicit; at eps=0, W'=0 exactly.",
    }


def main() -> None:
    payloads = {
        "compression_probe.json": compression_probe(),
        "tail_bounds.json": tail_probe(),
        "nonnormal_probe.json": nonnormal_probe(),
        "energy_coordinate_probe.json": energy_coordinate_probe(),
    }
    for name, payload in payloads.items():
        (OUT / name).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(OUT / name)


if __name__ == "__main__":
    main()
