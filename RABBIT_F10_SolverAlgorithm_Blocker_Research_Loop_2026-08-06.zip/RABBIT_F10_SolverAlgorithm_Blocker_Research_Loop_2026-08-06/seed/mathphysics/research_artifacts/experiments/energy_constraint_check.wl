(* Symbolic check for the exact comoving-energy coordinate. *)
ClearAll[Nn, rhoNu, rhoEM, pNu, pEM, W, dT, dW, df, q, rhoEMPrime];
expr = Exp[4 Nn] (4 (rhoNu + rhoEM) - 3 (rhoNu + rhoEM + pNu + pEM));
identity = FullSimplify[expr /. pNu -> rhoNu/3];
implicit = Solve[rhoEMPrime dT == Exp[-4 Nn] dW - q df, dT][[1]];
Print["dW/dN = ", identity];
Print["implicit dT = ", implicit];
