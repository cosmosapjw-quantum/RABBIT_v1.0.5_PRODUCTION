# Phase 4 — Divergent Hypothesis Tree

## Root question

```
Reopen G-F10 without treating a faster copy of the failed BDF instrument as new evidence
├── A. Exact-structure reformulations
│   ├── H-001 Comoving total-energy coordinate and algebraic T_gamma
│   ├── H-002 Exact mu–tau symmetry + postprocessed cosmic time
│   └── H-003 Conservation projection of the discrete collision exchange
├── B. Low-dimensional kinetic representations
│   ├── H-004 Dynamic orthogonal-polynomial / fugacity basis
│   ├── H-005 Three-parameter Fermi entropic manifold per independent species
│   ├── H-006 First invariant-manifold correction L^{-1} Delta
│   └── H-007 Dynamical low rank
├── C. Domain and error certification
│   ├── H-008 Three-channel analytic tail certificate
│   ├── H-009 Entropy-metric defect/tube bound
│   ├── H-010 Goal-oriented adjoint output certificate
│   └── H-011 Certified empirical operator interpolation of collision moments
├── D. Shortcuts and controls
│   ├── H-012 Published momentum-averaged T/mu model as direct replacement
│   ├── H-013 Late-time free-streaming termination
│   ├── H-014 Direct Jacobian/AP preconditioner only
│   └── H-015 Generic hardware/parallel/solver change
└── E. Composite
    └── H-016 ECEM-3C = H-001 + H-003 + H-005 + H-008 + H-009 + H-010,
                       with H-006/H-011 conditional
```

## Candidate records

### H-001 — Exact comoving-energy coordinate
CORE_CLAIM: evolve `W=a^4(rho_nu+rho_EM)` and recover `T_gamma` algebraically.
MINIMAL_ASSUMPTIONS: massless neutrinos; monotone electromagnetic EOS; explicit treatment of discrete first-law residual.
DISTINCTIVE_PREDICTION: the exchange term `Q_EM/H` disappears from the total-energy equation, while the transformed continuous system has identical eigenvalues.
FATAL_VULNERABILITY: no improvement in the entropy/logarithmic norm at creep states, or an ill-conditioned algebraic inversion.
STATUS: active-supporting.

### H-002 — Exact symmetry/time elimination
CORE_CLAIM: merge mu and tau spectra and integrate cosmic time after the thermodynamic solve.
DISTINCTIVE_PREDICTION: order-60 state count falls from 182 to 121.
FATAL_VULNERABILITY: the maximum dimension-only dense-FD speedup is only about 1.5×.
STATUS: supporting only.

### H-003 — Conservation projection
CORE_CLAIM: minimally project the discrete collision exchange onto the exact energy-conserving subspace.
FATAL_VULNERABILITY: correction exceeds the frozen first-law tolerance or changes F10 observables beyond their certified slack.
STATUS: active-supporting.

### H-004 — Dynamic orthogonal basis
CORE_CLAIM: temperature/fugacity-adapted basis moves dominant thermodynamic motion into the lowest modes.
KNOWN_LIMIT: already established in literature and partly prototyped internally; not sufficient novelty by itself.
STATUS: merged into H-005/016.

### H-005 — Three-parameter Fermi entropic manifold
CORE_CLAIM: each independent species is represented by number, energy, and one bounded shape moment on a realizable Fermi manifold.
DISTINCTIVE_PREDICTION: exact matched moments with a low shape error and bounded exponential tail; substantially fewer dynamical variables.
FATAL_VULNERABILITY: trajectory leaves the manifold or the moment map becomes unusably ill-conditioned.
STATUS: active-primary component.

### H-006 — First invariant-manifold correction
CORE_CLAIM: approximate the micro component by solving a projected linear equation `L_theta g_1=-Delta_theta`.
FATAL_VULNERABILITY: no projected spectral gap or correction is as costly as the original trajectory.
STATUS: conditional.

### H-007 — Dynamical low rank
CORE_CLAIM: low-rank collision representation reduces nonlinear work.
FATAL_VULNERABILITY: the present problem has no large physical-space × velocity tensor; the main rank-separation mechanism is absent.
STATUS: rejected as primary.

### H-008 — Three-channel tail certificate
CORE_CLAIM: certify omitted momentum domain through direct output, missing collision source, and propagated feedback channels.
DISTINCTIVE_PREDICTION: a gamma-function envelope closes each reaction channel at `Y=30` or determines a larger analytic cutoff.
FATAL_VULNERABILITY: a reaction kernel or domain-crossing geometry violates the assumed exponential-polynomial envelope.
STATUS: active-primary component.

### H-009 — Entropy-metric defect/tube bound
CORE_CLAIM: after projecting macro modes, the collision dynamics contract in the Hessian metric of Fermi relative entropy, permitting a tube bound for the micro residual.
FATAL_VULNERABILITY: nonnormal growth remains positive in every usable metric or the tube constants are too pessimistic.
STATUS: active-primary certificate.

### H-010 — Goal-oriented adjoint certificate
CORE_CLAIM: bound only the F10 quantities of interest using an adjoint-weighted residual instead of demanding uniform full-state accuracy.
FATAL_VULNERABILITY: adjoint amplification or fold-level nonsmoothness makes the bound vacuous.
STATUS: active-primary certificate.

### H-011 — Certified collision hyper-reduction
CORE_CLAIM: approximate only the moment collision map offline and carry a rigorous online residual bound.
FATAL_VULNERABILITY: training coverage is not prospective or positivity/conservation is lost.
STATUS: conditional acceleration.

### H-012 — Published momentum-averaged model as direct replacement
CORE_CLAIM: use a fast effective-temperature/chemical-potential model directly.
FATAL_VULNERABILITY: reported sub-0.04% integrated-observable agreement does not establish the tighter, fold-specific F10 predicates.
STATUS: rejected shortcut; retain as baseline/control.

### H-013 — Late-time free-streaming termination
CORE_CLAIM: stop when the integrated collision-to-Hubble residual is bounded.
FATAL_VULNERABILITY: the measured stall is at `N≈0.163`, before late free streaming; this cannot solve the primary blocker.
STATUS: rejected as primary; possible downstream optimization.

### H-014 — Direct Jacobian/AP preconditioner only
CORE_CLAIM: cure stiffness by analytic Jacobian or AP splitting.
FATAL_VULNERABILITY: D-071 explicitly excludes a faster implementation of the same instrument, and existing prototypes make this non-novel.
STATUS: rejected as reopening argument; supporting implementation tool only.

### H-015 — Hardware/parallelism/general solver
STATUS: rejected by D-071 and by the step-count-dominated miss.

### H-016 — ECEM-3C composite
CORE_CLAIM: a seven-state energy-constrained entropic moment system, with conservative collision projection and three-channel/goal-oriented certification, can replace the failed 182-state trajectory as a materially new validation instrument.
DECISIVE_TEST: the prospectively sealed stalled-phase discriminator in Phase 7.
STATUS: survivor candidate.
