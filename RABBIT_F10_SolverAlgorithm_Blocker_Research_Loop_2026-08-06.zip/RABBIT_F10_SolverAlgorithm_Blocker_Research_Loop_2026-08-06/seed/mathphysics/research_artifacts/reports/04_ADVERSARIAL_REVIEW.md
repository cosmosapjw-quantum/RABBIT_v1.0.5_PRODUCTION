# Phase 5 — Adversarial Review

This review was performed as a separate skeptical pass after candidate generation. It is independent in role and criteria, not in operator identity; therefore it does not satisfy the Phase-8 external reviewer requirement.

| Hypothesis | Review role | Main objection | Disposition before validation |
|---|---|---|---|
| H-001 energy coordinate | TRADEOFF | Exact coordinate changes cannot delete physical stiff eigenvalues; benefit is scaling-dependent | retain only as part of composite |
| H-002 symmetry/time elimination | INFORMATIVE_FAILURE | Correct but at most ~1.5× from dense-FD dimension arithmetic | support only |
| H-003 conservation projection | NEEDS_MORE_EVIDENCE | Projection may alter the discrete comparator | retain with explicit correction bound |
| H-005 3-parameter entropic manifold | DEFENDED WITH LIMITS | One endpoint is not trajectory coverage; inverse map conditioning rises rapidly; superficial MaxEnt similarity requires a D-029 operation-graph audit | serious candidate |
| H-006 invariant-manifold correction | NEEDS_MORE_EVIDENCE | Requires an invertible projected linearized collision operator | conditional |
| H-007 dynamical low rank | REJECTED_SHORTCUT | Low-rank tensor structure is largely absent | reject primary |
| H-008 tail certificate | DEFENDED WITH LIMITS | Energy tail alone is misleading; collision and feedback must be included | serious candidate |
| H-009 entropy-metric tube | DEFENDED CONCEPTUALLY | Proving a usable gap over a tube may be the hardest task | serious certificate |
| H-010 adjoint output certificate | TRADEOFF | Bound may blow up near nonsmooth fold statistics | serious if fold objectives are differentiable or bounded piecewise |
| H-011 hyper-reduction | TRADEOFF | Can overfit the retained trajectory and violate conservation | only after the analytic structure is fixed |
| H-012 published averaged model | REJECTED_SHORTCUT | External accuracy statement is not the gate-specific certificate | baseline only |
| H-013 late freeze-out stop | REJECTED_SHORTCUT | Does not touch the early creep epoch | reject primary |
| H-014 direct Jacobian/AP only | REJECTED_SHORTCUT | Solver repair; D-071-ineligible | support only |
| H-016 ECEM-3C | DEFENDED, NOT PROMOTED | Only candidate addressing step count, domain, realizability, and output certification together | send to Phase 6–7 |

## Red-team conclusions

1. The elegant part—exact energy conservation—is not the decisive speedup by itself.
2. The low-dimensional part is only credible if the residual orthogonal to the manifold is measured at creep states, not merely at the endpoint.
3. The certification part must control nonnormal amplification; eigenvalue plots are insufficient.
4. The tail proof must be reaction-aware. A scalar Fermi energy-tail fraction cannot license T13.
5. The composite is not allowed to hide its cost in an offline phase trained on post-hoc outputs. The basis, moments, cutoff, metrics and thresholds must be sealed before discriminator output.


## D-029 red-team addendum

The historical comparison does not identify ECEM-3C with D-029. D-029 was a target-dependent three-node collision deposition with selector ties and an exact-node branch; ECEM-3C is a fixed global distribution manifold. The distinction is killed if a future implementation introduces target-dependent support selection, an active-set rescue, or only piecewise inverse-map regularity. Because the original four D-029 envelopes are missing, the novelty verdict remains `HOLD` until Gate A0 is completed.

## Execution-boundary addendum

A real collision invariance-defect measurement was not performed. The source-level operator was inspected through remote source reads, but no complete local source snapshot was available, the attempted clone failed at DNS resolution, and no prospective collision-execution contract had been sealed. This is missing evidence, not a negative scientific result.
