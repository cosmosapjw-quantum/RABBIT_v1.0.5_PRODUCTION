# Phase 2–3 — Evidence Synthesis and Claim–Source Audit

## Baseline facts

1. **SUPPORTED:** The retained order-60, `y_max=30` domain holdout did not reach a scientific predicate. It consumed the 18 h budget and stalled near `N≈0.163`; D-071 therefore closes the instrument, not the physical proposition.
2. **SUPPORTED:** V3 localizes a severe numerical pathology: persistent finite-difference step factors corrupt selected Jacobian columns, Newton failures reset BDF progress, and the solver remains at low order. The true sampled operator is Hurwitz, but the report explicitly keeps the causal chain as inference because the controlled repair is disallowed.
3. **SUPPORTED:** A completing lower-resolution run exhibits the same factor ratchet. Therefore ratchet presence is not a sufficient discriminator; a proposed method must show that the reduced dynamics avoid the corruption-sensitive Newton loop.
4. **SUPPORTED:** Direct Jacobians or solver changes can be powerful in other neutrino-decoupling codes, but D-071 explicitly excludes a faster implementation of the same instrument from reopening.
5. **SUPPORTED:** Low-dimensional spectral and entropic descriptions of relic-neutrino spectra exist in the literature. They establish plausibility, not a project-specific error certificate.

## Claim audit

| Claim | Status | Audit judgment |
|---|---|---|
| C-001 Current failure disproves the underlying physics | UNSUPPORTED / REMOVED | No scientific predicate was evaluated. |
| C-002 Jacobian-factor pathology materially contributes to the stalled instrument | PARTIALLY_SUPPORTED | Strong measured association and exclusion of alternatives; controlled causality remains unavailable. |
| C-003 Pinning/capping the Jacobian alone reopens D-071 | CONTRADICTED | D-071 excludes it, and measured diagnostic variants remain far outside the required operating envelope. |
| C-004 A dynamically adapted low-dimensional spectrum is plausible | SUPPORTED | Birrell et al. and Bond et al.; endpoint probe agrees qualitatively. |
| C-005 Three parameters per species are sufficient for this full trajectory | INFERENCE_ONLY | Literature and one endpoint support a candidate; no creep-state or trajectory certificate exists. |
| C-006 `y>30` is negligible for every relevant quantity | CONTRADICTED AS BROAD CLAIM | Energy tail is tiny, but high-order moments grow to `~2.2e-5` at `k=10`; collision and feedback channels remain. |
| C-007 Hurwitz creep-state Jacobians certify contraction | CONTRADICTED | A simple nonnormal counterexample has the same negative spectral abscissa with large transient growth. |
| C-008 An exact energy coordinate removes physical stiffness | CONTRADICTED AS BROAD CLAIM | Eigenvalues are invariant under an exact coordinate change; it can only improve scaling/cancellation/nonnormality conditionally. |
| C-009 Exact mu–tau symmetry plus postprocessed time closes the runtime gap | CONTRADICTED | State/Jacobian-column arithmetic gives at most about 1.5× dense-FD reduction. |
| C-010 A composite energy-constrained entropic reduction with certified residuals is a legitimate D-071 candidate | HYPOTHESIS | It is structurally different from a solver repair, but no end-to-end certificate exists yet. |

## Conflict matrix

| Tension | Resolution in this loop |
|---|---|
| Three-parameter spectra are accurate vs. moment inversion becomes ill-conditioned | Both can hold. Representation error and inverse-map conditioning are different properties; use a Fisher/preconditioned coordinate and retain a conditioning gate. |
| Energy-coordinate reformulation is exact vs. the discrete collision action has a finite first-law residual | Separate a discrete-equivalent lane with an explicit residual from a prospectively defined method-internal conservative-correction lane. Never silently set the residual to zero, and forbid post-hoc projection. |
| Equilibrium tail is tiny vs. T13 is a domain blocker | T13 is not certified by the energy tail alone. Bound direct output, missing collision source, and propagated interior feedback separately. |
| Stable eigenvalues vs. BDF failure | Stability of eigenvalues does not control nonnormal transient growth or finite-difference Newton quality. Use an entropy/Lyapunov metric after projecting macro modes. |

## Missing evidence

- Entropic-manifold coverage at the three retained creep checkpoints and over the full retained base trajectory.
- Reaction-by-reaction polynomial/exponential envelope for domain-crossing collision terms.
- Entropy-metric logarithmic norm or spectral gap on a tube around the candidate manifold.
- A goal-oriented output bound for every fold-level F10 statistic.
- A prospectively sealed call-count/runtime discriminator on the stalled phase.
