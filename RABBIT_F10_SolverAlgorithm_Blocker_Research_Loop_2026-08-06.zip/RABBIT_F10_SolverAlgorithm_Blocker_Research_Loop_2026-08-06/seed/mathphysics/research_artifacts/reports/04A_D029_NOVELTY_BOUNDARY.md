# Phase 5A — D-029 Novelty Boundary for ECEM-3C

DATE: 2026-08-06
STATUS: historical comparison recovered at the decision-summary level; raw D-029 result envelopes remain unavailable in this workspace.

## 1. Why this comparison is binding

A three-parameter entropic distribution can look superficially like the rejected D-029 “three-node maximum-relative-entropy” route. That resemblance is not enough to identify the methods, but it is enough to forbid a novelty claim until the operation graphs are compared. The retained external audit records D-029 as a **local collision-deposition construction**, not as a global state-manifold model.

## 2. Recovered D-029 mechanism and failure

For one outgoing target energy `y_*`, D-029 selected a local support triple `(a,b,c)` and positive prior weights, then solved a strictly concave maximum-relative-entropy problem under zeroth- and first-moment constraints. The fixed-triple theorem was sound and produced positive weights when `y_*` lay in the open convex hull.

The executable method additionally required the global map

\[
y_*\mapsto(a(y_*),b(y_*),c(y_*),\pi(y_*),w(y_*)),
\]

including nearest-exterior support selection and a separate exact-node one-hot branch. The route was rejected before implementation because the available theorem did not cover selector-switch continuity, the exact-node limit, uniform Lipschitz/Jacobian existence, label-permutation covariance, or the full collision ledger. The historical audit explicitly leaves open the possibility of a **different globally smooth entropy-local basis**, while keeping the selector-based D-029 route closed.

## 3. Operation-level comparison

| Feature | D-029 | ECEM-3C candidate | Novelty judgment |
|---|---|---|---|
| Object being reduced | One off-grid collision leg/deposition event | The global species distribution along the cosmological trajectory | Distinct level of the computation |
| Support | Target-dependent three-node subset | Fixed analytic functions on the entire momentum half-line | No support selector or active-set switch |
| Entropy role | Select positive local deposition weights | Define a realizable global distribution manifold and its Hessian metric | Distinct primal object and norm |
| Evolved state | No global collision/trajectory state completed | Six moments plus total comoving energy | Distinct dynamical system |
| Collision action | Intended new local semidiscrete deposition | Evaluate the frozen collision action on reconstructed distributions first; project only moment outputs | Does not resurrect the D-029 deposition rule |
| Branch geometry | Selector ties and exact-node one-hot branch | Smooth fixed-basis inverse moment map, provided its Jacobian remains nonsingular | Distinct, but still requires a uniform inverse-map proof |
| Conservation | Two local moments for a fixed triple | Total-energy constraint plus explicit discrete residual or prospectively defined method-internal conservative correction | Broader, but the correction must be part of the sealed method rather than post-hoc |
| Certification | Fixed-triple positivity theorem only | Invariance defect, entropy-tube estimate, three-channel tail, goal-oriented output error | New composite obligation |

## 4. What is genuinely different

The candidate’s operation-level novelty, if it survives validation, is the composition

\[
\text{fixed global entropic manifold}
+\text{exact total-energy constraint}
+\text{micro-invariance defect}
+\text{reaction-aware domain enclosure}
+\text{goal-oriented output certificate}.
\]

None of these statements licenses reuse of D-029’s target-dependent support selector, local prior, or one-hot branch. ECEM-3C is killed as a novelty claim if an implementation introduces an adaptive support/active-set rule equivalent to D-029 or if its inverse moment map is only piecewise defined without a global regularity theorem.

## 5. Mandatory pre-output novelty discriminators

Before any candidate trajectory output:

1. **Fixed-basis proof:** the reconstruction basis and moment functionals are fixed globally; no target-dependent support selector or exact-node rescue branch exists.
2. **Moment-map regularity:** prove or interval-certify existence, uniqueness and a uniform bound on the inverse Jacobian over the predeclared admissible moment tube.
3. **Permutation covariance:** verify that the full reconstruction–collision–moment map commutes with exact mu–tau relabelling without changing reduction order.
4. **D-029 raw comparison:** if the four hash-locked D-029 envelopes become available, compare the exact operation graph and failure predicates before calling ECEM-3C materially new.
5. **No local-theorem inflation:** endpoint moment fitting or fixed-state invertibility cannot be described as a global semidiscrete theorem.

## 6. Residual evidence limit

The materialized `BD622_F10_external_audit_report.md` preserves a detailed decision summary and mathematical reconstruction of D-029, but the original four D-029 result/adjudication envelopes are not present. Therefore this cycle establishes a **credible structural distinction**, not a complete historical novelty proof. The D-029 raw comparison remains a Gate-A0 prerequisite for any external `PROMOTE` decision.
