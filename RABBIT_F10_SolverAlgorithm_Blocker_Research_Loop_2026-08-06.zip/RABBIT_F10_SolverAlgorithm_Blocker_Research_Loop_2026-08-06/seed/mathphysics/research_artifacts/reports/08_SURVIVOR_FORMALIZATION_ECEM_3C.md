# Phase 9 — Survivor Formalization: ECEM-3C

STATUS: research candidate; `REOPEN_VALIDATION`, not promoted.

## Definition 1 — Macro state

Under exact mu–tau degeneracy, define

\[
X=(m_{e,0},m_{e,1},m_{e,2},m_{x,0},m_{x,1},m_{x,2},W)\in\mathbb R^7.
\]

`m_0` is the number moment, `m_1` the energy moment and `m_2` a bounded shape moment. `W` is total comoving energy.

## Definition 2 — Entropic reconstruction

For `a=e,x`, reconstruct

\[
f_a^\lambda(y)=\sigma\!\left(\alpha_a+\lambda_{1,a} y+\eta_a\frac{y}{1+y}\right),
\quad \sigma(u)=\frac1{1+e^{-u}},\quad \lambda_{1,a}<0,
\]

by matching the three moments. The equivalent tail-slope parameter is `beta_a=-lambda_{1,a}>0`. Use a predeclared Fisher/Cholesky scaling of the inverse moment problem. Four or more parameters are comparators, not adaptive rescue paths.

## Definition 2A — Exclusion of the D-029 mechanism

The reconstruction uses one fixed global analytic basis for all momenta and states. It contains no target-dependent support selector, local three-node prior, active-set switch or separate exact-node one-hot branch. A future implementation that introduces any such mechanism is not this candidate and must return to design review. Global existence, uniqueness, differentiability and permutation covariance of the inverse moment map are proof obligations, not assumptions that can be inferred from endpoint fitting.

## Definition 3 — Macro dynamics

\[
\frac{dm_{a,j}}{dN}=\int_0^\infty y^2\psi_j(y)\frac{Q_a[f^\theta,T_\gamma]}{H}\,dy,
\]

and

\[
W'=e^{4N}(\rho_{\rm EM}-3P_{\rm EM})+e^{4N}R_E.
\]

`R_E` is either the explicitly retained discrete residual or zero under a prospectively defined, method-internal conservative correction with its own bound; post-hoc projection is excluded. `T_gamma` is recovered from the EOS constraint.

## Definition 4 — Micro defect and certificate

\[
\Delta_\theta=(I-P_\theta)Q[f^\theta],
\]

with the micro norm induced by the Fermi entropy Hessian. The model is admissible only when a projected dissipativity/tube estimate and a goal-oriented output error bound are available.

## Definition 5 — Three-channel tail accounting

Every omitted-domain bound is the sum of direct, collision-source and propagated-feedback terms. A thermodynamic tail fraction alone is never a domain certificate.

## Conjecture ECEM-3C-1 — Stalled-phase regularization

On the frozen no-QKE Standard-Model trajectory, the seven-state macro system avoids the finite-difference-Jacobian ratchet-sensitive Newton limit cycle and has a prospectively bounded full-trajectory call count below 5,500 at the frozen collision-map cost ceiling.

STATUS: HYPOTHESIS.

## Conjecture ECEM-3C-2 — Output certification

The sum of manifold, tail, quadrature and time-integration error propagated by the fold-level adjoint remains below the available G-F10 gate slack, so the certified lower bound of the coupling improvement can be evaluated.

STATUS: HYPOTHESIS.

## Proposition-level results already established in this cycle

1. Continuous comoving-energy identity and implicit derivatives: DERIVED / symbolically checked.
2. Fermi-tail incomplete-gamma bounds: DERIVED / numerically cross-checked.
3. Exact coordinate transformation preserves eigenvalues: DERIVED / numerically checked.
4. Hurwitz eigenvalues do not imply contraction: explicit counterexample / checked.
5. Exact symmetry reduction alone is insufficient: arithmetic bound / checked.
6. Three-parameter endpoint realizability and moment matching: exploratory numerical result / not trajectory validation.

## Paper/research memo structure

1. Measured failure geometry and D-071 contract.
2. Exact energy-constrained formulation.
3. Entropic moment manifold and realizability.
4. Projected entropy stability and invariant-manifold defect.
5. Reaction-aware tail and output certificates.
6. Prospectively sealed creep discriminator.
7. Five-fold independent scientific validation.
8. Limitations and failure cases.


## Historical novelty status

The retained D-029 audit supports an operation-level distinction, but the original D-029 envelopes are absent. ECEM-3C therefore remains `REOPEN_VALIDATION`; material novelty is not established until Gate A0 passes.
