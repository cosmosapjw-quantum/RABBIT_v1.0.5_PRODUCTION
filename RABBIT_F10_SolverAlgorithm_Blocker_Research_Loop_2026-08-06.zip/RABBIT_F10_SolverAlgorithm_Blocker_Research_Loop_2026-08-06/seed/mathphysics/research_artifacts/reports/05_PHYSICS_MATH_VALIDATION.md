# Phase 6 — Physics and Mathematics Validation

## 1. Exact comoving-energy identity

Let `N=ln a` and define

\[
W(N)=e^{4N}\left[\rho_\nu(N)+\rho_{\rm EM}(T_\gamma(N))\right].
\]

Total energy conservation in a flat FLRW background gives

\[
\frac{d\rho_{\rm tot}}{dN}=-3(\rho_{\rm tot}+P_{\rm tot}).
\]

With effectively massless neutrinos, `P_nu=rho_nu/3`, hence

\[
\boxed{\frac{dW}{dN}=e^{4N}\left(\rho_{\rm EM}-3P_{\rm EM}\right)}.
\]

The neutrino–electromagnetic exchange cancels exactly. The source is the electromagnetic trace, dominated by the electron mass; the photon trace vanishes.

Recover `T_gamma` from

\[
\rho_{\rm EM}(T_\gamma)=e^{-4N}W-\rho_\nu[f,T_{\rm cm}],
\]

which is locally unique wherever `d rho_EM/dT_gamma>0`. Implicit differentiation gives

\[
\frac{\partial T_\gamma}{\partial W}=
\frac{e^{-4N}}{\rho'_{\rm EM}(T_\gamma)},\qquad
\frac{\partial T_\gamma}{\partial f_j}=
-\frac{\partial\rho_\nu/\partial f_j}{\rho'_{\rm EM}(T_\gamma)}.
\]

Dimensions: `[W]=MeV^4`, `[partial T/partial W]=MeV^{-3}`, and `partial T/partial f_j` has units MeV. The sign is physical: at fixed total comoving energy, increasing neutrino occupancy lowers the plasma temperature.

**Validation status:** PASS for the continuous equations; CONCERN for discrete equivalence. The existing collision discretization carries a measured finite first-law residual. A new instrument must either retain that residual explicitly,

\[
W'=e^{4N}(\rho_{\rm EM}-3P_{\rm EM})+e^{4N}R_E,
\]

or project the collision exchange onto the exact conservation subspace and certify the induced correction. Setting `R_E=0` without that comparison is forbidden.

## 2. Energy coordinate does not erase stiffness

The toy exchange model

\[
x'=-K(x-aT),\qquad T'=\frac K C(x-aT)-\epsilon T,
\qquad W=x+CT
\]

was transformed exactly. The eigenvalues agree to floating-point accuracy for every tested heat capacity. However, the Euclidean logarithmic norm changes strongly with scaling: for `C=1` the energy coordinate worsens it, while for `C=1000` it changes a large positive value to about `-0.997`.

**Conclusion:** the coordinate can remove exchange cancellation and improve nonnormal scaling, but the benefit is conditional and must be measured on the retained creep states. It is not a proof of speedup.

## 3. Realizable entropic manifold

For each independent species `a∈{e,x}`, define the three-moment state

\[
m_{a,j}=\int_0^\infty y^2\psi_j(y)f_a(y)\,dy,
\quad \psi=(1,y,\phi),\quad \phi(y)=\frac{y}{1+y}.
\]

Use the Fermi exponential family in natural parameters

\[
f_a(y;\lambda_a)=\frac{1}{1+\exp[-u_a(y)]},\qquad
u_a(y)=\alpha_a+\lambda_{1,a} y+\eta_a\phi(y),\quad \lambda_{1,a}<0.
\]

Equivalently, `\beta_a=-\lambda_{1,a}>0`. This guarantees `0<f<1` and an exponential tail. In the natural coordinates `\lambda=(\alpha,\lambda_1,\eta)`, the moment Jacobian is the symmetric positive Gram/covariance matrix

\[
\frac{\partial m_i}{\partial\lambda_j}
=\int_0^\infty y^2\psi_i(y)\psi_j(y)f(1-f)\,dy,
\]

provided the sufficient statistics are linearly independent in the weighted space. In the implementation coordinates `(alpha,beta,eta)` the `beta` column has the opposite sign; invertibility is unchanged, but symmetry/positive-definiteness should not be claimed in those coordinates.

A frozen 48-node endpoint probe exactly matched moments `k=2,3,4` with three parameters. The energy-weighted L1 errors were about `7.63e-4` for `nu_e` and `2.53e-4` for `nu_x`; the next `k=5` relative errors were `2.62e-4` and `8.52e-5`. Adding parameters lowered some fit errors but drove the unscaled inverse-moment Jacobian condition from roughly `1.35e3` at 3 parameters to `4.1e4`, `1.2e6`, and `3.3e7` at 4–6 parameters.

**Conclusion:** three parameters form a plausible accuracy/conditioning knee, not a theorem. The condition number is coordinate-dependent, so a Fisher/Cholesky-preconditioned inversion should be tested. No trajectory coverage is claimed.

## 4. Tail bounds

For the equilibrium Fermi tail,

\[
I_k(Y)=\int_Y^\infty\frac{y^k}{e^y+1}\,dy
\le \int_Y^\infty y^k e^{-y}\,dy
=\Gamma(k+1,Y).
\]

The two-term alternating expansion also gives

\[
\Gamma(k+1,Y)-2^{-(k+1)}\Gamma(k+1,2Y)\le I_k(Y).
\]

At `Y=30`, the relative tail is `4.92e-10` for the energy moment `k=3`, but rises to `2.05e-6`, `7.13e-6`, and `2.24e-5` for `k=8,9,10`. Thus high-order collision weights can make the missing tail materially larger than the thermodynamic energy tail.

For any certified envelope `f(y)≤exp(A-b y)` with `b>0`,

\[
\int_Y^\infty y^k f(y)\,dy
\le e^A b^{-(k+1)}\Gamma(k+1,bY).
\]

**Validation status:** PASS for the scalar integral bound; CONCERN for the full T13 claim. Reaction kinematics, domain-crossing events and feedback into the interior require separate constants.

## 5. Hurwitz is not contraction

The family

\[
A_M=\begin{pmatrix}-5.75&M\\0&-5.75\end{pmatrix}
\]

has spectral abscissa `-5.75` for every `M`, yet the measured maximum `||exp(A_M t)||_2` on `0≤t≤3` grows to `6.42` at `M=100` and `19.2` at `M=300`. The Euclidean logarithmic norm is positive. A Lyapunov metric exists, but becomes poorly conditioned as `M` grows.

**Conclusion:** V3's negative eigenvalues exclude a physical linear instability but do not certify a small propagation factor. The candidate requires an entropy-weighted metric after macro tangent modes are projected out.

## 6. Exact symmetry arithmetic

The order-60 state has `3×60+2=182` variables. Exact mu–tau reduction and postprocessing of cosmic time give `2×60+1=121`. The corresponding dense finite-difference column ratio is approximately `122/183`, so dimension alone offers at most about `1.5×`. This is useful but cannot close the multi-thousand-fold evaluation-count miss.

## 7. Composite mathematical structure

Write `f=f_theta+g`, where `f_theta` is the six-parameter two-species entropic manifold and `g` satisfies the three moment orthogonality conditions per species. Let `P_theta` be the tangent/moment projector and

\[
\Delta_\theta=(I-P_\theta)Q[f_\theta]
\]

be the invariance defect. In the Fermi relative-entropy Hessian metric

\[
\|g\|_{H_\theta}^2=\sum_a\int
\frac{y^2|g_a|^2}{f_{\theta,a}(1-f_{\theta,a})}\,dy,
\]

a usable tube theorem would have the schematic form

\[
\frac{d}{dN}\|g\|_H
\le-\gamma(N)\|g\|_H+\|\Delta_\theta\|_H+L\|g\|_H^2.
\]

For a quantity of interest `J`, an adjoint `z` yields

\[
|\delta J|\lesssim |z(N_0)\delta x_0|
+\int\|z\|_*\bigl(\|r_{\rm model}\|+\|r_{\rm tail}\|+\|r_{\rm quad}\|\bigr)dN
+R_{\rm nl}.
\]

These are proof obligations, not results. The composite remains NOT_YET_TESTABLE until the metric, tube, reaction constants and fold-level output functional are instantiated.
