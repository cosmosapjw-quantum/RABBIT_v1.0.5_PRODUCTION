# Phase 1 — Research Contract

## PRIMARY_RQ

Can the closed `G-F10-INDEPENDENT-FLRW` trajectory lane be reopened by a materially new mathematical-physics formulation which (i) preserves or explicitly bounds the relevant neutrino-decoupling physics, (ii) survives the measured creep regime near `N≈0.163`, and (iii) prospectively predicts completion within the frozen 64,800 s wall budget with margin?

## SUB_RQS

1. Can exact conservation laws eliminate the numerically fragile electromagnetic-temperature exchange equation without silently changing the discrete physics?
2. Is the solution trajectory confined close enough to a low-dimensional realizable entropic manifold to replace 180 spectral degrees of freedom by a few moment variables?
3. Can the omitted `y>30` domain and model-reduction residual be bounded in the actual collision and output channels, not only in equilibrium energy density?
4. Which norm or Lyapunov structure can certify stability despite local nonnormality, given that Hurwitz eigenvalues alone are insufficient?
5. What bounded, prospectively sealed discriminator would distinguish a real reopening route from another fast-looking local repair?

## IN_SCOPE

- Standard no-QKE independent-FLRW comparator and its exact symmetries.
- Mathematical reformulation, asymptotic/moment reduction, analytic domain control, conservation projection, output-oriented certification.
- Short static or toy numerical probes using already retained endpoint data and analytic counterexamples.
- A design for a future prospectively sealed stalled-phase discriminator.

## OUT_OF_SCOPE

- Harness repair; it is a separate lane by user instruction.
- Generic solver tuning, a larger wall budget, faster hardware, or direct Jacobian repair as the reopening argument.
- Full end-to-end production implementation in this cycle.
- QKE, public-production claims, and DSMC as a candidate route.
- Editing the source repository or changing gate status.

## Conventions

- Metric signature `(-,+,+,+)` where spacetime conventions enter.
- E-fold time `N=ln a`; `T_cm=T_start exp(-N)`.
- Natural units follow the frozen source, with energy densities in powers of MeV; dimensions are stated explicitly.
- Neutrinos are effectively massless over the decoupling interval, hence `P_nu=rho_nu/3`.
- `x` denotes the exactly degenerate mu–tau pair when the frozen no-QKE assumptions hold.

## Completion bar

This cycle is complete when it has: (a) an audited evidence map; (b) genuinely distinct candidate families; (c) at least one symbolic identity and several numerical/counterexample probes; (d) a survivor with explicit proof obligations; (e) a prospective discriminator whose pass/kill criteria enforce the 18 h budget with margin; and (f) an honest external-gate disposition. No gate movement is permitted.
