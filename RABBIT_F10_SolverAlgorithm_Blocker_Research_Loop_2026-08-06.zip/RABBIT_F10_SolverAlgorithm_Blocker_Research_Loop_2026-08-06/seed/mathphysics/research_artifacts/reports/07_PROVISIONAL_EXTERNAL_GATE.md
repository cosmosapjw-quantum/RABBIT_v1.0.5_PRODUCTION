# Phase 8 — Provisional External Decision Gate

## Decision

`REOPEN_VALIDATION` for H-016 / ECEM-3C.

This is not `PROMOTE`. The candidate has a coherent mathematical mechanism, literature precedents for its components, and research-stage probes that reject several shortcuts. However, the decisive evidence—creep-state manifold coverage, entropy-metric tube constants, three-channel collision-tail bounds and the prospectively sealed runtime discriminator—has not been produced.

## Dimension-by-dimension review

- Evidence: sufficient to motivate, insufficient to validate.
- Physical validity: exact continuous conservation law passes; discrete conservation treatment remains open.
- Mathematical validity: realizability and scalar tail bounds pass; tube and output theorems remain obligations.
- Novelty: the operation graph differs from the retained D-029 summary, but the original D-029 envelopes are missing. Material novelty remains conditional on Gate A0; no broad novelty claim is made.
- Testability: high; Phase 7 provides explicit pass/kill criteria.
- Robustness: unknown outside the frozen endpoint and toy probes.
- Tractability: plausible but unmeasured; the 5,500-call bound is a future gate, not a prediction already earned.
- Assumption burden: moderate-to-high, concentrated in entropy contraction and reaction-tail envelopes.

## Externality limitation

The harness calls for a reviewer who did not generate or validate the candidates. This cycle used a separate skeptical pass and independent symbolic/numerical tools, but not a distinct human or organizational authority. Therefore the formal external gate is unresolved and must be repeated before any D-071 reopen claim.


## Historical-novelty limitation

The retained external audit was materialized and confirms that D-029 failed as a target-dependent local three-node deposition, whereas ECEM-3C is posed as a fixed global state manifold. This is enough to keep the candidate alive, not enough to promote it. The four original D-029 result/adjudication envelopes must be compared before a final external novelty verdict.
