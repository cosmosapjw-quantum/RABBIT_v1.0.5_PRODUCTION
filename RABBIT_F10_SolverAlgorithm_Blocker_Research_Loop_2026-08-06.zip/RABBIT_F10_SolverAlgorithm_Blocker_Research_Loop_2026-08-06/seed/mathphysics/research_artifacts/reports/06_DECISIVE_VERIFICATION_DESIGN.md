# Phase 7 — Minimal Decisive Verification Design

## Candidate under test

**ECEM-3C:** Energy-Constrained Entropic-Manifold Reduction with Three-Channel Certification.

The dynamical state is seven-dimensional: three moments for `nu_e`, three for the exactly degenerate `nu_x=(nu_mu,nu_tau)`, and total comoving energy `W`. `T_gamma` and the entropic parameters are algebraic; cosmic time is postprocessed. The collision moment map is evaluated exactly first and may be hyper-reduced only after an error certificate exists.

## Gate A0 — D-029 historical novelty boundary

1. **Claim:** the candidate is a fixed global state manifold, not the closed target-dependent three-node deposition method.
2. **Inputs:** retained D-029 audit summary now; the four hash-locked D-029 envelopes when available; candidate operation graph frozen before numerical output.
3. **Pass:** no target-dependent support selector, no active-set/exact-node rescue branch, uniform inverse-map regularity, and permutation-covariant reconstruction–collision–moment composition.
4. **Kill:** operation-level equivalence to D-029 or inability to prove global regularity.
5. **Current:** summary-level distinction established; raw historical comparison missing.

## Gate A — Static exactness and conditioning

1. **Claim:** the energy-coordinate system is algebraically equivalent to the frozen discrete system when the measured discrete first-law residual is retained.
2. **Inputs:** the three retained V3 creep checkpoints and their pinned-step Jacobians.
3. **Pass:** transformed and original Jacobian eigenvalues agree to relative `1e-10`; algebraic `T_gamma` inversion is unique; the conservation residual is reproduced to the frozen tolerance.
4. **Kill:** loss of uniqueness, a hidden residual term, or a correction larger than the available F10 error budget.
5. **Ambiguity:** coordinate helps only in a weighted norm; proceed to Gate C without claiming speed.

## Gate B — Manifold coverage

1. **Claim:** the two-species three-moment manifold covers the retained base and creep trajectories.
2. **Inputs:** every retained full state from D-069/V3, with endpoint states held out from basis selection.
3. **Measurements:** energy/number exactness, shape-moment residual, energy-weighted L1, collision-moment error, Fisher-metric condition, invariance defect.
4. **Pass:** no post-hoc basis change; every held-out state is realizable; the eventual goal-oriented bound, not an arbitrary state norm, fits inside one quarter of the available fold-level gate slack.
5. **Kill:** nonrealizability, unbounded moment inversion, or any held-out creep state whose certified output contribution exceeds half the gate slack.
6. **Ambiguity:** isolated local failure triggers one predeclared four-parameter comparator, not adaptive basis hunting.

## Gate C — Entropy-metric stability

1. **Claim:** the projected micro dynamics are dissipative on a tube around the manifold.
2. **Inputs:** projected pinned-step Jacobians at the three creep states plus early/late retained checkpoints.
3. **Pass:** a prospectively specified metric has `mu_H≤-gamma_*<0` after macro tangent modes are removed, with a tube/conditioning factor that keeps the integrated defect bound finite and below the Gate-B allowance.
4. **Kill:** only eigenvalue stability is available, the metric condition makes the bound vacuous, or `mu_H` is positive in the stalled window.

## Gate D — Three-channel domain certificate

For each reaction and each F10 quantity, decompose the `y>30` error into:

1. direct omitted output;
2. missing collision source, including domain-crossing incoming/outgoing events;
3. propagated feedback into the retained domain.

**Pass:** the sum of all three certified contributions is below one quarter of the fold-level gate slack. **Kill:** a reaction lacks a valid exponential-polynomial envelope or the feedback bound dominates the slack.

## Gate E — Prospectively sealed stalled-phase runtime discriminator

This is the D-071 reopening discriminator. Its contract must be committed before any candidate output.

- Windows: initialization, `N∈[0.14,0.22]` including the measured creep interval, a collision-decay window, and a late weak-collision window.
- Record: accepted/rejected steps, nonlinear iterations, RHS calls, collision-map wall, algebraic inversion failures, metric/defect indicators.
- Conservative per-call ceiling: `4.5 s`, slightly above the retained T13 post-drop value `4.42062 s/eval`.
- Full-trajectory call-count upper bound: `5,500` calls.
- Budget arithmetic: `5,500×4.5 s=24,750 s=6.875 h`; a `2.5×` safety factor gives `61,875 s=17.19 h`, still below `64,800 s`.

**PASS only if all hold:**

1. the upper, not central, call-count projection is at most 5,500;
2. the 95th-percentile collision-map call is at most 4.5 s or the product bound is tightened correspondingly;
3. no order-1/failure-reset limit cycle appears in `0.14≤N≤0.22`;
4. all Gates A–D remain within their predeclared budgets;
5. the projected total including certification overhead remains below 64,800 s.

**KILL if any hold:** projected calls exceed 5,500; the creep window shows nonprogress; a certificate is vacuous; or thresholds are changed after output.

## Gate F — Fold-level scientific discriminator

Only after A–E pass, run the sealed five-fold scientific contract. Propagate certified per-trajectory error into RMSE/MAE and the `>=20%` coupling improvement predicate. The lower confidence/certification bound—not the point estimate—must clear each gate. Deterministic rerun and no-test-fitting requirements remain unchanged.

## Cheapest next action

No new full trajectory. First complete Gate A0 and compute Gates A–D from retained checkpoints and frozen endpoint/base states. Only a clean static package justifies the bounded Gate-E implementation.
