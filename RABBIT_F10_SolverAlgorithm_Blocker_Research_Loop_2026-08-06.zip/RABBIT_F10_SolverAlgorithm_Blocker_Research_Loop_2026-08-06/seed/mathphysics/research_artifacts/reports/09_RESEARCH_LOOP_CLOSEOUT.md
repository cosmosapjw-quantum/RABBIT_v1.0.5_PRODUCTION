# Phase 10 — Research Loop Closeout

## Confirmed

- The failed T13 lane is an instrument failure, not a physical falsification.
- Local Jacobian repair is diagnostically relevant but D-071-ineligible and quantitatively insufficient as the whole route.
- The total comoving-energy formulation is exact at the continuous level and exposes an algebraic plasma-temperature constraint.
- Exact coordinate changes preserve physical eigenvalues; any benefit must come from scaling, cancellation removal and reduced dynamics.
- A realizable three-parameter entropic representation is plausible at the frozen endpoint, while higher moment counts rapidly worsen the unscaled inverse-map condition.
- The `y>30` energy tail is tiny, but high-order moments are several orders larger and force reaction-aware certification.
- Hurwitz spectra alone cannot support a trajectory error bound.
- Exact mu–tau/time elimination alone is far too small to close the runtime gap.

## Rejected or weakened

- Energy-coordinate-only reopening.
- Equilibrium-energy-tail-only T13 closure.
- Published momentum-averaged model as an unqualified substitute.
- Late free-streaming termination as the primary solution.
- Dynamical low rank as the main reduction mechanism for this homogeneous 1D momentum system.
- Direct Jacobian/AP/hardware changes as the D-071 reopening argument.
- DSMC, excluded by the project constraint.

## Survivor

ECEM-3C: energy-constrained, two-species three-moment entropic dynamics with conservative collision accounting, entropy-metric defect control, a three-channel tail bound and goal-oriented fold-level certification.

## Missing evidence

The four original D-029 envelopes and final operation-graph novelty audit; creep-state manifold coverage; a real collision invariance-defect measurement; weighted stability constants; reaction-tail constants; output adjoints; and the sealed 5,500-call runtime discriminator.

## Next primary question

Does the predeclared three-moment manifold admit a non-vacuous entropy/adjoint certificate at the three V3 creep checkpoints while preserving the discrete first-law residual within the frozen tolerance?

## Next minimal action

Complete Gate A0, then run only the static Gates A–D on retained states. Do not implement or launch an end-to-end candidate until those gates pass and Gate E is sealed in advance.
