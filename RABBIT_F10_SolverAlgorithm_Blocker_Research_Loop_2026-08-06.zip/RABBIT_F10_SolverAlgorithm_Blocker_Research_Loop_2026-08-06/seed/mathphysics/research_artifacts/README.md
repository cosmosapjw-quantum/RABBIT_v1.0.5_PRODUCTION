# Research artifacts

- `sources/`: source map, bibliography, and the materialized retained D-029 external audit.
- `reports/`: one report per harness phase plus a D-029 operation-level novelty boundary.
- `designs/`: ECEM-3C pre-contract and machine-readable error-budget schema.
- `experiments/`: endpoint compression, tail, nonnormality and energy-coordinate probes plus tests.
- `results/`: JSON/CSV outputs and reproducibility manifest.
- `figures/`: plots generated from the JSON outputs.
- `SHA256SUMS`: hashes of all research artifacts.

These artifacts are exploratory research evidence. They do not move a RABBIT gate and do not constitute the prospectively sealed D-071 discriminator.
