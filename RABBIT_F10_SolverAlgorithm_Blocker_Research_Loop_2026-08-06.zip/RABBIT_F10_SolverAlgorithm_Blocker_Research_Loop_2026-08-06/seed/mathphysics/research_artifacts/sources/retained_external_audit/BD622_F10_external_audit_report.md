# BD622 외부 F-10 독립검증 blocker 감사 보고서

**대상:** `cosmosapjw-quantum/RABBIT_v1.0.5_PRODUCTION`  
**감사 성격:** read-only, hostile-but-constructive, 제3자 과학 감사  
**감사 시각:** 2026-07-19T09:51:33Z  
**물리 실행:** 수행하지 않음  
**새 collision/GL48·64/Radau/trajectory/endpoint/RABBIT 출력:** 생성하지 않음  
**감사 역할:** early-universe kinetic theory / discrete kinetic method / stiff ODE & floating point / reproducibility & evidence adjudication

이 문서는 내부 상태 요약이 아니라, 반복된 F-10 독립검증 실패의 수학적·물리적·수치적 원인을 분리하고 다음 설계를 사전동결 가능한 형태로 제안하는 외부 감사 보고서다. 숨은 추론 과정은 제시하지 않는다. 대신 검산 가능한 식, 코드 경로와 함수, 조건수 추정, 잔차 정의, 재현 명령, 반증 실험을 제공한다.

---

# 1. Snapshot/evidence manifest 및 executive verdict

## 1.1 접근 가능한 snapshot

| 항목 | 프롬프트 관측값 | 이번 감사에서 직접 확인한 값 | 판정 |
|---|---|---|---|
| 저장소 | 로컬 `/home/cosmosapjw/Dropbox/rabbit/RABBIT_v1.0.5_PRODUCTION` | 공개 GitHub 저장소 `cosmosapjw-quantum/RABBIT_v1.0.5_PRODUCTION` | 공개 원격만 접근 가능 |
| 브랜치 | `bd612-remediation` | 공개 기본 브랜치 `main`; `bd612-remediation`은 공개 refs에서 발견되지 않음 | 역사 snapshot과 공개 baseline 분리 필요 |
| HEAD | `0b2339c676dba6f36dbf0850419c4d78e1a5f907` | 공개 `main` HEAD `70b050af5923d15afd6bc8443ce13869f042306f` | drift가 아니라 서로 다른 provenance surface |
| working tree | dirty | 원격 Git 객체에는 working-tree 개념이 없음 | **UNAVAILABLE** |
| shared context | `d9515008...a8` | 공개 `.agent-harness/generated/CONTEXT_PACK.md`에 동일 값 | 일치 |
| active run | `run-20260718-f10-maxent3-rejected-final` | 공개 baseline에서 raw run tree가 제거/격리되어 직접 열 수 없음 | 경로 수준 역사 증거만 존재 |
| 공개 이력 성격 | 미지정 | 2026-07-19에 새 public baseline으로 re-root된 curated history | 원시 로컬 감사 자료와 동일시 금지 |

공개 `main`은 프롬프트의 dirty local checkout을 그대로 공개한 것이 아니다. 문서와 registry는 D-025–D-029의 결과를 보존하지만, 지정된 raw `.agent-harness/runs/...` JSON과 adjudication 파일은 공개 저장소에서 404였다. 따라서 이번 보고서는 다음 두 층을 구분한다.

1. **직접 확인된 공개 source/registry/document evidence**: 코드, gate registry, context pack, validation ledger, frozen decision 문서.
2. **해시 잠금된 역사적 주장**: 공개 문서가 기록한 raw-run 결과. 원시 파일 부재 때문에 수치 재파싱과 SHA-256 재계산은 **UNAVAILABLE**이다.

이 한계는 결론을 완화하지 않는다. 반대로, 공개 문서가 보존한 실패 상태를 pass로 승격할 수 없다는 뜻이다.

## 1.2 감사 환경과 도구

| 항목 | 값 |
|---|---|
| UTC timestamp | `2026-07-19T09:51:33Z` |
| audit host | Linux container `2257ad316188`, kernel `4.4.0`, `x86_64` |
| Python | `3.13.5`, GCC `14.2` |
| NumPy / SciPy | `2.3.5` / `1.17.0` |
| Rust toolchain in audit host | **UNAVAILABLE** (`rustc`, `cargo` 미설치) |
| repository-declared toolchain | context pack 기록상 `rustc/cargo 1.94.1`, Python `3.12.3` |
| exact token counter | **UNAVAILABLE**; harness/API가 exact counter를 노출하지 않음 |

시도한 안전 명령과 결과:

```bash
# 원격 공개 baseline의 원시 바이트를 읽기 전용으로 복제하려 한 시도
git clone --depth 1 \
  https://github.com/cosmosapjw-quantum/RABBIT_v1.0.5_PRODUCTION \
  /mnt/data/RABBIT_public_audit
# 결과: Could not resolve host: github.com
```

네트워크 DNS 제한 때문에 shell clone은 실패했다. 이후 모든 저장소 읽기는 GitHub read connector로 수행했다. 커밋·브랜치·파일 조회 외의 write 동작은 하지 않았다.

수행한 정적 확인:

```text
- public repository metadata, default branch, current public HEAD
- AGENTS.md, anti-drift guardrails, cost policy
- CONTEXT_PACK.md, FROZEN_DECISIONS.md, GATE_REGISTRY.json, CLAIM_REGISTRY.jsonl
- PROJECT_STATE.md, CLAIM_LEDGER.md, VALIDATION_LEDGER.md, NEXT_SESSION_PROMPT.md
- F-10 future plan, full-collision implementation guide
- 지정된 report TeX sections
- Rust collision, FLRW, ODE, electron matrix-element sources
- independent comparator and focused tests
- primary-paper CRAG and method-transfer audit
- geometry-only GL48 conditioning calculation
```

명시적으로 건너뛴 실행:

```text
- full release suite: 현재 production edit 권한도 없고 Rust toolchain도 없음
- comparator collision execution: 프롬프트가 새 물리 출력을 금지
- GL48/GL64 comparator rerun: D-028 이후 금지
- Radau, trajectory, endpoint: static gate가 먼저 실패
- RABBIT physical output/unblinding: owner authorization 없음
- FortEPiaNO execution: D-025 이후 route DEPRECATED
```

## 1.3 파일 provenance manifest

프롬프트가 제시한 여섯 SHA-256은 역사적 dirty-tree 파일에 결박돼 있다. 공개 원격 connector는 Git blob ID를 제공하지만 raw bytes를 로컬로 materialize하지 못했으므로 SHA-256을 재계산할 수 없었다.

| 파일 | 역사 SHA-256 prefix/suffix | 공개 `main` Git blob | SHA-256 drift 판정 |
|---|---|---|---|
| `native/rabbit_cpu/src/neutrino_self_spectral.rs` | `1c6600a8…63a0` | `34e6870c4d09b78b668d35907097391e6bd0f020` | **UNAVAILABLE** |
| `native/rabbit_cpu/src/electron_spectral.rs` | `501ae08a…05a` | `90490b00fbfec95f6be42cde2cb706079bd4f5b5` | **UNAVAILABLE** |
| `native/rabbit_cpu/src/isotropic_boltzmann.rs` | `5ac3a3ea…ae5` | `95f51ed1e2c693f1b2dbe6f5951164e9c2690915` | **UNAVAILABLE** |
| `native/rabbit_cpu/src/ode.rs` | `78e141fd…bc1` | `4d9b1a9a6454f84459ec0154ab23cc9f1bbd90c4` | **UNAVAILABLE** |
| `src/rabbit/decoupling/_independent_noqke.py` | `535370c1…ac3` | `01a3ddf6944a5efad880a1143ec736e7b99d5183` | **UNAVAILABLE** |
| `tests/test_independent_noqke_comparator.py` | `abdc4e01…748` | `9e1d19d3e5f173da3b2590f2af51694c6386bd02` | **UNAVAILABLE** |

Git blob SHA-1과 SHA-256은 다른 해시 함수이므로 서로 직접 비교하지 않았다. 이 보고서의 source 판단은 공개 blob과 함수 구조를 기준으로 하며, 역사 수치 결과는 공개 decision/ledger가 밝힌 해시 잠금 evidence로만 취급한다.

## 1.4 현재 gate와 claim 상태

| gate/claim | 확인 상태 | 해석 |
|---|---|---|
| `G-F10-CATALOGUE` | pass | 9-row 구현과 내부 구조 시험에 대한 역사/집중 evidence |
| `G-F10-PERFORMANCE` | pass | BDF exact-point cache 및 topology aggregation의 same-code endpoint 성능 evidence |
| `G-F10-SCOPE` | pass | flat FLRW, no-QKE 경계 유지 |
| `G-F10-INDEPENDENT-FLRW` | fail | 세 independent route가 static 또는 design 단계에서 실패 |
| `G-HARNESS-INTEGRITY` | fail | static validator와 별개로 trusted hook activation/write attribution 미증명 |
| current full Rust regression | 미실행 | `230/230`은 2026-07-16 역사 기록; 2026-07-18 focused run은 crate에 240 tests가 있음을 보임 |

`230/230`을 현재-tree full-suite pass로 쓰면 안 된다. 공개 validation ledger의 최신 focused Rust 실행은 각 filter가 pass했고 239 tests가 filtered되었다고 기록한다. 따라서 현재 crate test total은 240이지만, 나머지 236개를 이번 tree에서 실행했다는 뜻은 아니다. 공개 release-maintenance preflight의 Python test 결과 역시 collision physics authority가 아니다.

## 1.5 Executive verdict

### Physics

Rust의 nine-row catalogue가 내부 시험을 통과했다는 사실은 중요하지만 독립 물리 검증은 아니다. 공개 source에서 전자 matrix-element coupling convention은 comparator와 겉보기 계수가 다르지만, Rust가 doubled couplings와 directed-edge `1/2` pairing을 함께 쓰므로 source-level normalization은 내부적으로 상쇄될 수 있다. 따라서 현재 증거만으로 숨은 normalization 오류를 확정할 수 없다. 그러나 이를 독립적인 explicit-species/high-precision oracle로 검증한 공개 raw artifact도 없다.

더 직접적인 source risk가 있다. `electron_spectral.rs`는 bitwise common-FD state를 인식하면 이미 계산한 electron action을 정확한 0으로 덮어쓰되 비영 Jacobian은 그대로 반환한다. 이는 “연속 연산자의 항등식”을 구현한 것이 아니라 한 입력점에서 출력값만 바꾸는 branch다. raw event action이 그 점에서 binary64 exact zero가 아니면 RHS map은 점 불연속이며, raw action이 우연히 매우 작더라도 branch를 포함한 map의 방향미분이 반환 Jacobian과 일치한다는 증거가 없다. trajectory 전 승인 전에 이 계약을 고쳐야 한다.

### Discretization

반복 실패의 가장 강한 직접 원인은 independent discretization이다. D-027은 target-leg point evaluation이 common-FD null을 통과했지만 resolved non-equilibrium self number, self energy, electron exchange에서 각각 frozen cap을 넘었다. D-028은 약형/modal 구조가 대부분의 static discriminator를 통과했으나 native action 변환에서 mu–tau covariance가 실패했다. D-029는 fixed support triple의 entropy theorem과 global selector/branch가 하나의 연속·공변 semidiscrete method를 이루지 못해 구현 전에 정당하게 닫혔다.

D-028의 GL48 native map은 `1/y^2` division과 global Legendre reconstruction을 결합한다. 이번 geometry-only 계산에서 2-norm condition estimate는 약 `7.53×10^6`, `ε64 κ≈1.67×10^-9`였다. 관측 `4.666×10^-10`은 ordinary binary64 backward error와 충분히 양립한다. 이는 “반드시 roundoff만의 문제”라는 증명이 아니라, favourable modal residual과 failing native residual이 수학적으로 모순되지 않는다는 뜻이다.

### Metrology

D-028의 native relative-L∞ `1e-10` co-gate는 출력 이후 바꿀 수 없고 D-028은 계속 fail이다. 다만 그 observable은 작은 첫 GL node에서 `1/y^2` 증폭을 받으면서 denominator가 action scale에 의존하므로 condition-aware하지 않다. 따라서 별도 meta-finding으로, 다음 설계에서는 weak/modal norm, physically weighted native norm, signal-floor가 사전동결된 native pointwise norm을 함께 써야 한다. cap은 high-precision oracle와 operation-count/condition bound로 output 전 유도해야 한다.

### Process and provenance

공개 baseline은 문서·registry는 잘 보존하지만 프롬프트가 지정한 dirty branch, raw run artifacts, SHA-256 대상 파일 bytes를 제공하지 않는다. 따라서 이번 감사는 역사 수치를 재실행·재해시하지 않았고, 공개 문서가 보존한 failure를 그대로 binding evidence로 인정했다. harness integrity failure는 process defect이지 physics defect의 증거가 아니다. 반대로 process pass도 physics pass가 아니다.

### 통합 판단

현 상태는 “Rust가 맞고 validator만 나쁘다”로 축약할 수 없다. 확인된 independent-method 실패, condition-blind metrology, exact-FD branch/Jacobian source risk, provenance gap이 동시에 존재한다. 숨은 Rust catalogue/normalization/EOS 오류도 아직 반증되지 않았다. 따라서 필요한 다음 단계는 기존 D-028의 cap을 바꾸거나 GL64를 실행하는 것이 아니라, explicit six-species positive conservative weak event/deposition method와 256-bit reference oracle을 하나의 사전동결 static package로 설계하는 것이다.

### Four-role reconciliation

- **Early-universe kinetic theorist:** continuum detailed balance, self number/energy, EM–ν first law, fermionic entropy sign은 명확히 유도된다. Rust self weak event는 이 구조를 상당 부분 반영하지만 electron spin/orientation normalization과 exact-FD branch는 독립 proof가 부족하다.
- **Discrete kinetic-method specialist:** D-027은 adjoint weak deposition 부재로 reject가 정당하고, D-028은 weak structure를 회복했으나 native inverse map이 ill-conditioned하다. D-029는 local theorem을 global selector method로 확장하지 못했다.
- **Stiff-ODE and floating-point specialist:** 현재 blocker는 solver 이전이지만 exact-FD branch/Jacobian, tail logit scaling, event root reconstruction은 이후 trajectory risk다. D-028 residual은 binary64 condition envelope와 양립한다.
- **Reproducibility and evidence adjudicator:** public baseline은 failure status를 보존하지만 dirty snapshot/raw artifacts를 제공하지 않는다. 역사 evidence와 current-tree claim을 섞을 수 없고, 230/230을 current full regression으로 승격할 수 없다.

네 역할의 합의는 다음과 같다. production physics error를 확정할 evidence는 없지만 배제할 evidence도 부족하며, independent discretization과 metrology defect는 이미 확인됐다. 그러므로 새 static method는 production correction과 validator replacement를 분리하고, 양쪽을 같은 explicit-species/high-precision oracle로 공격해야 한다.

---

# 2. Decision chronology와 causal failure tree

## 2.1 D-025–D-029 chronology

| Decision | attempt | discriminator | observation | decision | residual uncertainty |
|---|---|---|---|---|---|
| D-025 | Whole-program FortEPiaNO 1:1 authority | frozen no-QKE scope, exact-grid/source authority, initial collision invariants | QKE/oscillation/precision surface가 목표보다 넓고, corrected bounded initial slice도 resolved non-null endpoint evidence를 만들지 못함 | whole-program route **DEPRECATED**; diagonal classical slice는 contextual evidence만 허용 | Fort와 Rust가 공유할 수 있는 고전 convention 오류는 여전히 가능 |
| D-026 | private explicit six-species comparator 설계 | affine GL48/64, independent kinematics/EOS, cloglog state, future Radau, static-first | 구조적으로 다른 Python module/test surface가 정의됨 | static M0/M1만 **SPECIFIED**; trajectory 금지 | catalogue/formula/test vectors/caps 공유가 independence를 얼마나 약화하는지 남음 |
| D-027 | direct target-leg pointwise collision action | common-FD null; resolved self number/energy; electron exchange | null pass; `1.9782e-10`, `2.3350e-10`, `1.0684e-7`로 caps `1e-10`, `1e-10`, `1e-8` 실패 | evolving RHS 후보 reject | Rust error와 pointwise nonconservation 중 어느 쪽이 지배적인지 미분리 |
| D-028 | full-degree entropy-variable Galerkin–Petrov weak action | static conservation, exchange, entropy, CP, native mu–tau co-gate | 모든 기록된 static discriminator 중 native mu–tau만 `4.666064056497196e-10 > 1e-10` | GL64/Radau/trajectory/endpoint 금지; candidate reject | rounding, reduction-order asymmetry, native map conditioning, deeper covariance defect의 비율 미분리 |
| D-029 | three-node maximum-relative-entropy local deposition | fixed-triple theorem + global prior/selector/branch/continuity/Jacobian/covariance/binary64 contract | fixed triple negative-KL theorem은 sound; executable selector와 one-hot branch가 global method proof에 포함되지 않음 | implementation 전 reject; route closed | 다른 전역적으로 매끄러운 entropy-local basis는 아직 설계 가능 |

## 2.2 Failure tree

```text
G-F10-INDEPENDENT-FLRW = FAIL
|
+-- A. Production-physics uncertainty [OPEN]
|   +-- A1. nine-row multiplicity/kernel convention shared by tests/comparator
|   +-- A2. electron matrix-element normalization not yet high-precision explicit-species checked
|   +-- A3. exact-FD value overwrite with retained Jacobian [SOURCE RISK CONFIRMED]
|   +-- A4. finite-domain whole-event rejection lacks universal tail certificate
|   +-- A5. tree-level finite-me EOS/FLRW mapping not independently closed at endpoint
|
+-- B. Independent spatial discretization [CONFIRMED FAILURES]
|   +-- B1. D-027 target-point form does not conserve required weak moments to frozen caps
|   +-- B2. D-028 weak/modal -> native map amplifies binary64 perturbations
|   +-- B3. D-029 selector/branch does not define one global continuous covariant method
|
+-- C. Acceptance metrology [META DEFECT]
|   +-- C1. native rel-Linf co-gate ignores 1/y^2 conditioning
|   +-- C2. denominator may be dominated by small physical action/cancellation scale
|   +-- C3. modal diagnostic favourable but nonbinding
|
+-- D. Structural independence [OPEN]
|   +-- D1. explicit species/code language are independent axes
|   +-- D2. physical catalogue, constants, test states, and gates remain partly shared
|   +-- D3. post-unblinding method evolution risks epistemic circularity
|
+-- E. Time integration [SECONDARY NOW, MATERIAL LATER]
|   +-- E1. static collision fails before any solver
|   +-- E2. BDF cache is exact-point only and not a physics approximation
|   +-- E3. Rodas event refinement and finite-difference time derivatives need later audit
|
+-- F. Provenance/process [CONFIRMED LIMIT]
    +-- F1. public main differs from dirty historical branch/HEAD
    +-- F2. raw D-027/D-028/D-029 artifacts not publicly accessible
    +-- F3. 230/230 is historical, current tree has 240 tests but no current full run
    +-- F4. harness hooks/write attribution unproved
```

## 2.3 Competing hypotheses adjudication

| Hypothesis | 상태 | 가장 가까운 경쟁 가설과 구별하는 관측 |
|---|---|---|
| H1 production-correct/comparator-ill-conditioned | **PARTIALLY SUPPORTED, NOT ESTABLISHED** | D-028 modal pass + native-map condition estimate는 ill-conditioning을 지지한다. 그러나 electron exact-FD branch risk와 독립 normalization oracle 부재가 production-correct 결론을 막는다. |
| H2 shared hidden physics error | **OPEN** | Rust와 comparator가 같은 published constants와 catalogue grouping을 사용한다. 다른 spatial method의 agreement만으로 shared convention error를 배제할 수 없다. explicit-species 256-bit trace oracle가 필요하다. |
| H3 coordinate mismatch | **SUPPORTED AS A PLAUSIBLE D-028 MECHANISM** | `_native_action`이 modal reconstruction을 `T^3 y_i^2/(2π²)`로 나누고 GL48 `y_min≈0.01475`에서 `1/y_min²≈4598`을 만든다. modal/native residual 분리가 예상된다. |
| H4 floating-point reduction defect | **PLAUSIBLE, UNPROVED** | 관측 `4.67e-10`이 `ε κ≈1.67e-9`보다 작다. fixed-order pairwise/Kahan/MPFR 비교가 없으므로 ordinary rounding과 label-dependent order를 분리할 수 없다. |
| H5 gate-metrology defect | **SUPPORTED AS META-FINDING ONLY** | native co-gate가 condition-aware하지 않다. 그러나 output 후 gate 변경은 금지이므로 D-028 fail을 바꾸지 않는다. |
| H6 insufficient structural independence | **OPEN AND MATERIAL** | comparator는 six species, affine grid, CM kinematics가 독립적이지만 catalogue/formula/caps/test vectors를 공유한다. 어떤 요소가 unblinded 후 선택됐는지 raw provenance가 필요하다. |
| H7 solver is secondary | **ACCEPTED FOR CURRENT BLOCKER** | D-027/D-028은 static action에서 실패했다. BDF/Rodas/Radau는 해당 residual을 제거할 수 없다. |
| H8 provenance drift | **ACCEPTED** | public `main` HEAD/branch가 역사 dirty snapshot과 다르고, 230/230 이후 current focused run이 240-test crate를 보고했다. |

추가 가설 H9를 채택한다.

**H9 — point-overwrite RHS/Jacobian mismatch:** common-FD exact null을 강제하는 source branch가 value와 derivative를 일관되게 정의하지 않는다. 이 가설은 source만으로 **DERIVED**되며, one-ULP 양측 방향미분으로 falsify할 수 있다.

# 3. Equation-to-code ledger 및 continuum convention audit

## 3.1 가정, metric, 단위, 부호

이 절에서는 사용자 기본 convention에 맞춰

\[
g_{\mu\nu}=\operatorname{diag}(-,+,+,+)
\]

를 쓴다. 코드가 사용하는 양의 Minkowski invariant는

\[
\chi_{ij}\equiv -p_i\!\cdot p_j
=E_iE_j-\mathbf p_i\!\cdot\mathbf p_j\ge 0
\]

로 해석한다. 따라서 source의 `chi`, comparator의 `_minkowski_dot`, 그리고 `K_s`, `K_t`는

\[
K_s=\chi_{12}\chi_{34},\qquad K_t=\chi_{14}\chi_{23}
\]

이다. 이 정의를 쓰면 metric-signature 차이가 matrix-element 부호 차이로 오인되지 않는다.

코드는 자연단위 `c=\hbar=k_B=1`을 사용한다. 이 절에서는 차원 검산을 위해 상수를 복원한다.

- `G_F`: `MeV^{-2}`
- `C[f]`: `MeV`, 즉 물리 시간률은 `C/\hbar` (`s^{-1}`)
- `H`: `MeV`; `H/\hbar`가 `s^{-1}`
- number density: `MeV^3/(\hbar c)^3`
- energy density: `MeV^4/(\hbar c)^3`
- collision energy transfer: `MeV^5/(\hbar c)^3\hbar`

F-10 slice의 물리 가정은 다음과 같다.

```text
flat homogeneous isotropic FLRW
massless diagonal νe, antiνe, νμ, antiνμ, ντ, antiντ
zero lepton asymmetry
finite vacuum electron mass
FD electron/positron bath at Tγ
all tree-level electron and neutrino-self 2<->2 channels
no QKE, no oscillations, no density matrix, no finite-T QED correction
```

## 3.2 Continuum operator 재유도

occupation `f_s(t,\mathbf p)`를 한 neutrino helicity species당 정의한다. 고전적 flavour-diagonal fermionic `1+2\leftrightarrow3+4` channel의 target-leg collision operator는

\[
C_1[f] = \frac{1}{2E_1}
\int \prod_{i=2}^{4}\frac{d^3p_i}{(2\pi)^3 2E_i}
(2\pi)^4\delta^{(4)}(p_1+p_2-p_3-p_4)
\,\overline{|\mathcal M|^2}\,J[f],
\]

\[
J[f]
=F-R
=f_3f_4(1-f_1)(1-f_2)
-f_1f_2(1-f_3)(1-f_4).
\]

여기서 `J>0`이면 inverse reaction `3+4→1+2`가 target leg 1을 채운다. 전체 4-leg weak event에서는

\[
(\dot f_1,\dot f_2,\dot f_3,\dot f_4)
\propto(+J,+J,-J,-J).
\]

### 차원 검산

각 invariant measure `d^3p/(2E)`의 차원은 `E^2`다. 세 measure는 `E^6`, delta는 `E^{-4}`, target prefactor는 `E^{-1}`이므로 phase-space 부분은 `E`. 저에너지 four-Fermi matrix element는

\[
\overline{|\mathcal M|^2}\sim G_F^2 E^4
\]

로 무차원이다. 따라서

\[
[C]=E,\qquad C\sim G_F^2T^5.
\]

보고서 `09_pair_annihilation_and_creation.tex`의 dimensionless `y` 적분 앞 `G_F^2T^4` 표기는 이 convention에서는 차원적으로 틀리다. `df/dt`를 뜻한다면 `T^5`가 필요하고, `df/dN=C/H`를 뜻한다면 `G_F^2T^5/H`가 필요하다. 이는 현재 source physics의 오류를 곧바로 뜻하지 않고, 문서 convention defect다.

### spin sum/average와 degeneracy

- 각 neutrino 및 antineutrino는 massless single-helicity species로 명시적으로 열거된다. neutrino 초기 spin average는 없다.
- electron/positron FD occupation은 두 spin state에 공통이다. Rust `electron_phase_point.rs::physical_point_density`의 leading factor `2`는 source convention상 electron spin degeneracy를 복원하는 역할로 해석된다.
- `electron_hm.rs`의 `W`가 initial electron spin averaged인지 summed인지 주석으로 명시돼 있지 않다. leading `2`와 결합해 continuum formula를 재현하는지 explicit spin-state oracle로 확인해야 한다. 내부 thermal anchor만으로는 이 ambiguity를 제거하지 못한다.
- identical-particle `1/2!`와 “한 reversible event를 몇 orientation으로 적분하는가”는 별개다. 이 codebase의 `eta=1/2`는 단순한 보편적 identical factor가 아니라 directed/global event orientation convention까지 포함한다.

## 3.3 Matrix elements와 coupling convention

### Neutrino–neutrino

저에너지 neutral-current interaction은 schematically

\[
\mathcal L_{\nu\nu}
=-\frac{G_F}{\sqrt2}
\sum_{\alpha,\beta}
(\bar\nu_\alpha\gamma^\mu(1-\gamma^5)\nu_\alpha)
(\bar\nu_\beta\gamma_\mu(1-\gamma^5)\nu_\beta)
\]

로 쓸 수 있다. chiral trace는 crossing에 따라 `K_s` 또는 `K_t`를 만들며, identical same-flavour에서는 exchange amplitude가 추가된다. repository convention은 각 target-directed reaction을

\[
\overline{|\mathcal M|^2}=c_{\rm tag}G_F^2K_{s/t}
\]

로 나타낸다. global four-leg event는 orientation/symmetry factor `\eta`를 포함해

\[
c_{\rm global}=\eta c_{\rm directed-role}
\]

를 쓴다. 동일 event의 여러 target role을 모두 합하면 tagged target coefficient가 복원돼야 한다.

중요한 점은 `c_tag=64,128,32`를 Rust table에서 그대로 읽어 재진술한 것이 아니라, 아래 explicit six-species event enumeration으로 family 수와 target role 수를 별도 계산했다는 것이다.

### Neutrino–electron

standard half-coupling convention을

\[
L_e=\frac12+\sin^2\theta_W,\qquad
L_{\mu,\tau}=-\frac12+\sin^2\theta_W,\qquad
R=\sin^2\theta_W
\]

로 둔다. neutrino elastic scattering의 한 crossing은

\[
\overline{|\mathcal M|^2}
=128G_F^2\left[
L^2K_s+R^2K_t-LR\,m_e^2\chi_{13}
\right],
\]

이며 antineutrino/positron channel은 `L↔R`와 crossing으로 얻는다. pair channel은

\[
\overline{|\mathcal M|^2}_{\rm pair}
=128G_F^2\left[
L^2K_t+R^2K_u+LR\,m_e^2\chi_{12}
\right],
\qquad K_u=\chi_{13}\chi_{24},
\]

의 convention을 사용한다.

Rust는 `g_L=2L`, `g_R=2R`와 바깥계수 `32`를 쓰므로 algebraically `128[L^2...,R^2...]`가 된다. comparator는 half-coupling과 elastic `64`, pair `128`을 쓴다. 이 겉보기 차이는 Rust `conservative_explicit_action`이 두 directed elastic orientations를 `0.5(forward-reverse)`, pair orientations를 `0.5(forward+reverse)`로 결합하는 것과 함께 해석해야 한다. 두 directed orientations가 continuum variable exchange 아래 정확히 동등하다는 전제에서는 elastic target convention `64`, pair semantic event `128`로 정합될 수 있다. 그러나 이 전제는 현재 공개 evidence에서 256-bit pointwise oracle로 검증되지 않았다. 따라서 normalization bug는 **미확정**이지 **반증됨**이 아니다.

## 3.4 명시적 six-species reaction enumeration

명시 species 순서는

\[
\mathcal S=\{\nu_e,\bar\nu_e,\nu_\mu,\bar\nu_\mu,\nu_\tau,\bar\nu_\tau\}.
\]

아래 family count는 folded `E/X` factor를 읽어 역추론하지 않고 이 집합에서 직접 열거한 것이다.

### Self-collision nine-row equation-to-code ledger

| Row | explicit physical reactions | family multiplicity `m` | kernel / coefficients | symmetry·role interpretation | continuum scaling | Rust / independent comparator | existing falsifier / missing falsifier |
|---:|---|---:|---|---|---|---|---|
| 1 | `νeνe↔νeνe`, `antiνe antiνe↔antiνe antiνe` | 2 | `K_s`; tagged identical target `64`; global event `16` | four equal target roles; identical/orientation `eta=1/2` in folded row | `G_F²T_cm^5` | `neutrino_self_spectral.rs::{ROW1_KS_EEEE,FULL_EEEE,accumulate_folded_channel}`; comparator `independent_self_reactions`, `independent_self_events`, `_self_matrix`, `_assemble_self` | explicit enumerator and tagged-target normalization exist; independent spin-trace high-precision oracle missing |
| 2 | `νe antiνe↔νe antiνe` | 1 | `K_t`; tagged `128`; global `64` | two target species/roles; reversible elastic orientation | same | Rust `ROW2_KT_EEEE`; comparator category `same_pair_opposite_sign_elastic` | row oracle exists; independent crossing/sign trace missing |
| 3 | identical: `νμνμ`, `antiνμ antiνμ`, `ντντ`, `antiντ antiντ`; distinct same-sign: `νμντ`, `antiνμ antiντ` | 6 | `K_s`; tagged identical `64`, distinct `32`; each global `16` | folded X projection `(4 identical+2 distinct)/4=3/2` | same | Rust `ROW3_KS_XXXX`, `HEAVY_SHARED_X_ROW3_PROJECTION`; comparator row/category enumeration | explicit six-state fingerprint verifies `m=6`; unfolded-vs-folded 256-bit action missing |
| 4 | `νμ antiνμ↔νμ antiνμ`, `ντ antiντ↔ντ antiντ` | 2 | `K_t`; tagged `128`; global `64` | two separate flavour pairs, each two target roles | same | Rust `ROWS4_TO_6_KT_XXXX`; comparator row 4 | aggregate tests exist; isolated high-precision row action missing |
| 5 | `νμ antiντ↔νμ antiντ`, `ντ antiνμ↔ντ antiνμ` | 2 | `K_t`; tagged `32`; global `16` | distinct-flavour opposite-sign elastic | same | same Rust aggregate; comparator row 5 | isolated folded-channel oracle exists; matrix crossing oracle missing |
| 6 | `νμ antiνμ↔ντ antiντ` | 1 | `K_t`; tagged/global `32`; `eta=1` | genuine pair conversion, no elastic orientation half | same | same Rust aggregate; comparator `pair_conversion`, row 6 | row oracle exists; selector/tail sensitivity unbounded |
| 7 | same-sign e–heavy: `νeνμ`, `νeντ`, `antiνe antiνμ`, `antiνe antiντ` | 4 | `K_s`; tagged `32`; global `16` | EXEX; folded output multipliers E=2, X=1 | same | Rust `ROW7_KS_EXEX`, `FULL_EXEX`; comparator row 7 | explicit count and aggregation tests; independent pointwise trace missing |
| 8 | opposite-sign e–heavy: `νe antiνμ`, `νe antiντ`, `antiνeνμ`, `antiνeντ` | 4 | `K_t`; tagged `32`; global `16` | EXEX crossing; E=2, X=1 | same | Rust `ROW8_KT_EXEX`; comparator row 8 | isolated oracle exists; high-precision covariance oracle missing |
| 9 | `νe antiνe↔νμ antiνμ`, `νe antiνe↔ντ antiντ` | 2 | `K_t`; tagged/global `32`; `eta=1` | EEXX conversion; E=2, X=1 | same | Rust `ROW9_KT_EEXX`; comparator row 9 | isolated oracle exists; explicit-species first-law/tail oracle missing |

Rust source의 production contraction은 네 topology block `FULL_EEEE`, `FULL_XXXX`, `FULL_EXEX`, `ROW9_KT_EEXX`로 집계된다. seven folded-channel implementations는 test oracle로 남는다. 이는 효율적인 folded representation이지만, independent validator는 이 folding을 복제하면 안 된다.

### Electron/positron reaction ledger

| family | explicit rows | matrix/crossing | conservation law | Rust / comparator | missing falsifier |
|---|---:|---|---|---|---|
| `s+e−↔s+e−` | 6 target species | elastic-minus; CP에 따라 `L↔R` | 각 explicit neutrino species number, total energy with EM bath | `electron_catalog.rs::EXPLICIT_ELECTRON_PROCESSES`; `electron_hm.rs::author_hm_w_over_gf2_mev4`; comparator `_electron_matrix(...elastic_minus...)`, `_assemble_electron` | spin sum/average와 leading bath degeneracy 2를 포함한 256-bit phase-space point oracle |
| `s+e+↔s+e+` | 6 | elastic-plus crossing | same | same | same |
| `να+antiνα↔e−+e+` | 6 target rows, 3 global pair events | pair crossing; target/CP orientation | flavour-pair lepton number difference; EM–ν energy closure | Rust pair edge symmetrization; comparator 3 semantic pair events | target-directed `64/128` convention과 global event counting의 independent oracle |

총 target-directed electron catalogue는 `6×3=18` rows이고, global semantic events는 `12 elastic + 3 pair = 15`다.

## 3.5 Semidiscrete moments와 conservation hierarchy

single helicity species의 quadrature moments는

\[
n_s=\frac{T_{\rm cm}^3}{2\pi^2}\sum_iw_i y_i^2f_{s,i},\qquad
\rho_s=\frac{T_{\rm cm}^4}{2\pi^2}\sum_iw_i y_i^3f_{s,i}.
\]

한 particle–antiparticle pair shape의 moments는 두 배다.

\[
n_{\rm pair}=\frac{T_{\rm cm}^3}{\pi^2}\sum_iw_i y_i^2f_i,\qquad
\rho_{\rm pair}=\frac{T_{\rm cm}^4}{\pi^2}\sum_iw_i y_i^3f_i.
\]

folded `E/X` total은

\[
n_\nu=\frac{T_{\rm cm}^3}{\pi^2}\sum_iw_i y_i^2(E_i+2X_i),
\]

\[
\rho_\nu=\frac{T_{\rm cm}^4}{\pi^2}\sum_iw_i y_i^3(E_i+2X_i).
\]

collision energy transfer는

\[
Q_\nu=\frac{T_{\rm cm}^4}{2\pi^2}
\sum_{s,i}w_i y_i^3C_{s,i},
\qquad [Q_\nu]={\rm MeV}^5.
\]

반응 stoichiometry를 incoming legs에 `+1`, outgoing legs에 `-1`로 정의하면 conserved charge `q_a`는

\[
\sum_{a=1}^4\nu_aq_a=0,
\qquad
\sum_{a=1}^4\nu_aE_a=0.
\]

conservation level을 구분해야 한다.

| identity | continuum | Rust self event/deposition | Rust electron | D-028 weak form |
|---|---|---|---|---|
| total self neutrino number | eventwise | same interpolation/deposition basis가 `Σλ=1`을 재현하므로 retained eventwise exact arithmetic identity | N/A | test basis가 constant를 포함하므로 weak/modal exact arithmetic identity |
| total self neutrino energy | eventwise | `Σy_iλ_i(y)=y`로 retained eventwise identity | N/A | linear mode 포함 시 weak/modal identity |
| elastic species number | eventwise | N/A | antisymmetric cell-edge flux로 quadrature-level identity | incoming/outgoing basis deposition으로 weak identity |
| pair lepton-number difference | eventwise | N/A | conjugate species에 같은 sign flux를 넣어 identity | two incoming neutrino legs에 같은 weak flux |
| EM–ν energy exchange | eventwise including bath | N/A | source computes neutrino action and FLRW uses equal-opposite EM debit; sampled/assembled identity | event diagnostics `qν+qEM`; static tested |
| mu–tau covariance | continuum exact | folded representation makes X covariance implicit, explicit six-state oracle needed | heavy folded | modal favourable; native co-gate failed |

Rust self interpolation bracket는 exact node에서 one-hot이고, interior에서 nonnegative linear weights를 사용한다. 이 weights는

\[
\lambda_L+\lambda_R=1,
\qquad y_L\lambda_L+y_R\lambda_R=y
\]

를 만족한다. 같은 weights가 outgoing occupation evaluation과 deposition에 사용되므로 number와 energy reproduction은 adjoint identity다. binary64에서는 summation/reduction error만 남는다.

## 3.6 Detailed balance와 fermionic entropy

entropy variable을

\[
u_s=\log\frac{f_s}{1-f_s}
\]

로 두면

\[
\log\frac{F}{R}=u_3+u_4-u_1-u_2\equiv A.
\]

common-temperature zero-chemical-potential FD에서는

\[
u_i=-\frac{E_i}{T},
\]

이므로 event energy conservation에 의해 `A=0`, 따라서 `F=R`이고 `J=0`이다. 이 null은 target action cancellation보다 강하다. 올바른 event representation에서는 각 quadrature point에서 성립해야 한다.

fermionic entropy

\[
S=-\sum_sg_s\int\frac{d^3p}{(2\pi)^3}
\left[f_s\log f_s+(1-f_s)\log(1-f_s)\right]
\]

의 collision derivative는

\[
\frac{dS}{dt}=-\sum_sg_s\int\frac{d^3p}{(2\pi)^3}u_sC_s.
\]

한 global event의 contribution은

\[
\dot S_{\rm event}
=-J(u_1+u_2-u_3-u_4)
=(F-R)\log\frac{F}{R}\ge0.
\]

이는 `(x-y)log(x/y)≥0`에서 따른다.

- Rust self weak event는 nonnegative quadrature/kernel, 동일 interpolation/deposition, stable `F-R`를 쓰므로 retained event에 대해 entropy sign을 구조적으로 보존한다.
- D-028 weak/modal assembly도 entropy variable을 test/evaluation에 쓰므로 native inversion 전 weak entropy duality는 구조적으로 보존할 수 있다.
- Rust electron edge antisymmetrization은 number/lepton conservation은 구조적으로 보장하지만, edge-paired flux가 항상 해당 paired affinity와 같은 sign을 갖는다는 global proof가 source에서 명시되지 않았다. entropy tests가 sampled evidence인지 algebraic theorem인지 구분해야 한다.
- D-029 fixed support triple theorem은 그 triple에서만 유효하다. target-dependent selector가 바뀌는 경계의 continuity와 entropy duality를 포함하지 않으면 global method theorem이 아니다.

## 3.7 Symmetry, positivity, support

### CP 및 family transforms

zero lepton asymmetry에서는

\[
f_{\nu_\alpha}=f_{\bar\nu_\alpha}
\]

가 invariant subspace다. CP는 species를 conjugate하고 electron scattering에서 `L↔R`을 교환한다. mu–tau 교환은 constants와 electron neutral-current coupling이 동일하므로 continuum operator와 FLRW mapping의 exact covariance다.

folded Rust `X`는 mu와 tau를 같은 shape로 강제하므로 그 subspace 내부 covariance는 자동이다. 이것은 explicit six-state covariance 검증과 다르다. 독립 validator가 labels를 바꾸었을 때 event ordering과 floating-point reduction order까지 같아야 native covariance가 binary64에서 재현된다.

### Positivity와 Pauli bound

Rust production state는 logit `u`, comparator는 cloglog coordinate를 쓴다. 두 transform 모두 representable domain 안에서는 `0<f<1`을 구조적으로 보장한다. 그러나

\[
\frac{du}{dN}=\frac{C}{Hf(1-f)}
\]

은 tail에서 `f(1-f)`가 작아질수록 stiffness와 roundoff amplification을 키운다. implicit trial state가 finite logit이면 occupation은 open interval 안에 있지만, collision action/Jacobian이 branch 경계에서 불연속이면 solver positivity만으로 well-posedness가 확보되지 않는다.

### support와 tail

Rust self와 D-028은 outgoing momentum이 stored domain 밖이면 whole event를 버리고 clipping하지 않는다. 장점은 retained event의 four-leg conservation과 label covariance가 보존된다는 것이다. 단점은 continuum collision operator를 truncated operator로 바꾼다는 것이다.

```text
retained event: number/energy/entropy identity 유지
rejected whole event: identity 위반은 없지만 physical rate가 누락
one-leg clipping: 금지되어야 함; conservation과 detailed balance를 깨뜨림
```

기존 smooth-profile domain-loss evidence는 selected states에 대한 sampled bound다. arbitrary nonthermal state, support-edge state, high-energy tail에 대한 uniform error theorem은 없다. independent endpoint authority에는 high-precision extended-domain oracle로 tail contribution을 별도 bounded해야 한다.

## 3.8 FLRW coupling과 thermodynamics

comoving momentum `q=ap`, evolution variable `N=ln a`, `y=q/T_ref`를 쓰면

\[
T_{\rm cm}(N)=T_{\rm ref}e^{-N}.
\]

homogeneous isotropic massless distribution에서 free-streaming term은 fixed `y`에서 사라져

\[
\frac{df_{s,i}}{dN}=\frac{C_{s,i}}{H}.
\]

logit state에서는

\[
\frac{du_{s,i}}{dN}
=\frac{C_{s,i}}{Hf_{s,i}(1-f_{s,i})}.
\]

총 energy와 Hubble rate는

\[
\rho_{\rm tot}=\rho_{\rm em}(T_\gamma)+\rho_\nu,
\qquad
H=\sqrt{\frac{8\pi G_N}{3}\rho_{\rm tot}}.
\]

전자 collision action으로 얻은 neutrino gain을 `Q_ν`라 하면

\[
\frac{d\rho_\nu}{dt}+4H\rho_\nu=Q_\nu,
\]

\[
\frac{d\rho_{\rm em}}{dt}+3H(\rho_{\rm em}+P_{\rm em})=-Q_\nu.
\]

따라서

\[
\frac{dT_\gamma}{dN}
=\frac{-3(\rho_{\rm em}+P_{\rm em})-Q_\nu/H}
{d\rho_{\rm em}/dT_\gamma}.
\]

source의 sign은 이 식과 일치한다. `Q_ν>0`이면 neutrino가 EM bath에서 energy를 받아 photon cooling이 빨라진다. self-collision energy moment는 total neutrino sector 내부에서 0이어야 하므로 EM debit에 들어가면 안 되고, source는 이를 제외한다.

현재 spectral FLRW slice는 finite vacuum `m_e`를 tree-level electron EOS와 collision kinematics에 포함하지만 finite-temperature QED correction은 호출하지 않는다. `electromagnetic_eos_for_qed`가 별도 존재하더라도 F-10 spectral system은 `electromagnetic_eos`를 사용한다. 이는 frozen no-QED slice와 정합적이다.

common-FD collision null만으로 FLRW thermal limit가 자동 검증되지는 않는다. `T_γ=T_cm`일 때 `Q_ν=0`뿐 아니라 EOS, total pressure, `H`, `dTγ/dN`, comoving momentum map이 common-bath adiabatic law와 맞아야 한다. 반대로 final `N_eff` agreement 하나도 collision catalogue, entropy, exchange sign을 검증하지 못한다.

endpoint event는 decreasing `T_γ-0.005 MeV=0`이다. 물리적으로 monotone해야 하지만, solver가 실제 bracket를 유지하고 interpolated state가 valid한지 두 경로에서 별도로 검증해야 한다. BDF와 Rodas가 같은 final scalar를 내는 것만으로 event-state reproducibility가 증명되지는 않는다.

# 4. Discrete proof audit와 floating-point/conditioning analysis

## 4.1 먼저 써야 하는 semidiscrete weak form

species `s`에 대한 radial measure를

\[
d\mu_y=\frac{T_{\rm cm}^3}{2\pi^2}y^2dy
\]

로 두고 test basis `ψ_k(y)`를 택한다. global event set `e`와 event quadrature point `q`에 대해 올바른 weak collision action은

\[
\left\langle\psi_k,C_s\right\rangle_{\mu_y}
=
\sum_{e,q}W_{eq}\,\overline{|\mathcal M_{eq}|^2}\,J_{eq}
\sum_{\ell=1}^4\sigma_\ell
\mathbf1_{s_\ell=s}\psi_k(y_{\ell q}),
\]

\[
(\sigma_1,\sigma_2,\sigma_3,\sigma_4)=(+1,+1,-1,-1).
\]

`W_eq`는 invariant phase-space measure와 positive quadrature를 포함한다. 이 식에서 `ψ=1`과 `ψ=y`를 대입하면 event stoichiometry와 energy conservation 때문에 self-collision number/energy moments가 0이다.

trial representation이

\[
u_s(y)=\sum_i u_{s,i}\lambda_i(y),
\qquad f_s(y)=\operatorname{logistic}(u_s(y))
\]

라면 evaluation과 deposition이 adjoint이기 위한 최소 조건은 다음이다.

\[
\text{evaluation: }u_s(y_q)=\sum_i\lambda_i(y_q)u_{s,i},
\]

\[
\text{deposition: }\dot f_{s,i}\propto
\sum_{e,q,\ell}W_{eq}\mathcal M^2J_{eq}\sigma_\ell
\mathbf1_{s_\ell=s}\lambda_i(y_{\ell q}),
\]

즉 같은 `λ_i`가 양쪽에 나타나야 한다. conservation에는 추가로

\[
\sum_i\lambda_i(y)=1,
\qquad
\sum_i y_i\lambda_i(y)=y
\]

가 필요하다. entropy proof에는 event에서 평가한 `u(y)`와 semidiscrete entropy derivative에 나타나는 `u_i`가 같은 dual pairing으로 연결돼야 한다.

## 4.2 네 방법의 구조 분류

| method | evolved/evaluated representation | conservation by construction | exact arithmetic only | sampled or failed | unproved |
|---|---|---|---|---|---|
| D-027 direct target-leg point evaluation | target native nodes; outgoing interpolation; target equation을 직접 계산 | common-FD event null 가능 | 일부 catalogue symmetries | self number/energy 및 electron exchange frozen caps 실패 | global four-leg adjoint deposition, entropy duality |
| D-028 full-degree Galerkin–Petrov | six species entropy logits; affine GL; global Legendre weak coefficients; native mass inversion | weak number/energy, weak entropy, global species stoichiometry | modal-to-native covariance는 rounding 전 exact | native mu–tau relative-L∞ 실패 | binary64 backward bound, native metric conditioning justification |
| D-029 three-node relative entropy | target마다 선택한 3-node local support와 entropy-max weights | fixed triple에서 two moments, positive weights | fixed selector cell 내부 | standalone local stencil만 pass | selector switch continuity, exact-node branch consistency, global covariance/Jacobian, collision ledger |
| Rust folded event stream | E/X logits; local nonnegative linear bracket; same bracket deposition | retained self event number/energy, electron edge number/lepton number | binary64 reduction 전 event identities | internal tests/anchors pass | explicit-species external normalization, arbitrary tail bound, exact-FD branch derivative |

D-027 실패는 tolerance가 약간 빡빡해서가 아니다. evolving RHS가 보존해야 할 weak invariant를 global deposition으로 구성하지 않았기 때문에 non-equilibrium resolved states에서 residual이 남았다. common-FD null은 `J=0`이라는 local algebra 하나만 시험하므로 이 결함을 가리지 못한다.

D-028은 그 결함을 약형으로 고쳤다. 따라서 self conservation, exchange, first law, entropy, CP가 통과하고 native covariance만 실패한 것은 “같은 실패의 반복”이 아니라 failure mode가 mass inversion/coordinate conditioning으로 이동한 것이다.

## 4.3 D-028 modal-to-native map

comparator의 mapped orthonormal Legendre basis를

\[
B_{ik}=\phi_k(y_i)
\]

라 하고 modal weak vector를 `g_k`라 하자. source `_native_action`은

\[
C_i=\frac{\sum_kB_{ik}g_k}
{(T_{\rm cm}^3/2\pi^2)y_i^2}.
\]

온도 prefactor는 모든 node에 공통이므로 conditioning의 핵심 map은

\[
M=D_{y^{-2}}B,
\qquad D_{y^{-2}}=\operatorname{diag}(y_i^{-2}).
\]

GL48, `[0,24]`에서 geometry-only 계산 결과는 다음과 같다.

| quantity | value |
|---|---:|
| `y_min` | `1.4747912970887178e-2` |
| second node | `7.763793280379083e-2` |
| first GL weight | `3.7840152627718095e-2` |
| `1/y_min^2` | `4.597681342469004e3` |
| `cond_2(B)` | `4.5309868887821265` |
| `||M||_2` | `2.3635371234050395e4` |
| `σ_min(M)` | `3.139295110640362e-3` |
| `cond_2(M)` | `7.528878426860986e6` |
| `ε64 cond_2(M)` | `1.671746835820939e-9` |
| `γ_48 cond_2(M)` | `8.024384811940592e-8` |
| first-row/median-row norm ratio | `2.7243937896172144e6` |
| `min(w_i y_i^2)` | `8.230268652632966e-6` |
| inverse smallest diagonal mass | `1.2150271664340963e5` |
| diagonal mass condition ratio | `2.8145339508848745e7` |

여기서

\[
\epsilon_{64}=2^{-52},\qquad
\gamma_n=\frac{n\epsilon_{64}}{1-n\epsilon_{64}}.
\]

`ε κ`는 first-order backward-error scale이고 `γ_48κ`는 48-term dot product의 매우 보수적인 worst-case envelope다. 실제 error는 cancellation, data orientation, BLAS reduction order에 따라 이 둘 사이 또는 그 아래에 놓일 수 있다.

재현 가능한 비물리 geometry command는 다음과 같다.

```python
import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

n, ymax = 48, 24.0
x, wu = leggauss(n)
y = 0.5 * ymax * (x + 1.0)
w = 0.5 * ymax * wu
B = legvander(x, n - 1) * np.sqrt((2*np.arange(n)+1)/ymax)
M = np.diag(1.0/y**2) @ B
s = np.linalg.svd(M, compute_uv=False)
eps = np.finfo(np.float64).eps
gamma48 = 48*eps/(1-48*eps)
print(y[0], np.linalg.cond(B), s[0]/s[-1])
print(eps*s[0]/s[-1], gamma48*s[0]/s[-1])
print((w*y**2).min(), (w*y**2).max()/(w*y**2).min())
```

이 계산은 collision output을 생성하지 않으며 grid와 linear map의 condition만 평가한다.

## 4.4 관측 `4.666064056497196e-10`의 backward-error 해석

mu–tau continuum covariance가 exact라면 true native actions를 `C_μ=C_τ=C`라 쓸 수 있다. floating-point 결과는

\[
\widehat C_\mu=C+\delta C_\mu,\qquad
\widehat C_\tau=C+\delta C_\tau.
\]

registered metric은 대략

\[
r_\infty=
\frac{\|\widehat C_\mu-\widehat C_\tau\|_\infty}
{\max(\|\widehat C_\mu\|_\infty,
      \|\widehat C_\tau\|_\infty,
      \text{tiny})}.
\]

따라서 관측값은 absolute difference가 아니라

\[
\|\delta C_\mu-\delta C_\tau\|_\infty
\approx4.666\times10^{-10}\,A,
\quad A=\max(\|C_\mu\|_\infty,\|C_\tau\|_\infty)
\]

라는 뜻이다. raw artifact가 공개되지 않아 `A`, summand absolute scale, cancellation ratio를 재구성할 수 없다.

modal event sum의 absolute scale을 `S_g=Σ|term|`, true modal result를 `|g|`, cancellation factor를 `χ=S_g/|g|`라 하면 native perturbation은 schematically

\[
\frac{\|\delta C\|}{\|C\|}
\lesssim \kappa(M)\,\gamma_m\,\chi
\]

로 증가한다. `κ(M)≈7.53×10^6`이므로 `4.67×10^-10`은 ordinary binary64 roundoff와 양립한다. 특히 favourable modal residual과 failing native residual은 수학적으로 동시에 참일 수 있다.

그러나 다음 중 무엇이 지배적인지는 현재 evidence로 결정할 수 없다.

1. 동일 event multiset의 label-dependent summation order.
2. BLAS/dot reduction의 ordinary rounding.
3. first nodes의 small physical denominator.
4. modal basis evaluation의 asymmetry.
5. 실제 catalogue/permutation mapping defect.

따라서 결론은 “roundoff로 확정”이 아니라 **roundoff-compatible, deeper defect not excluded**다.

## 4.5 prospective arithmetic discriminator

D-028을 재실행하거나 pass로 바꾸는 실험이 아니라, 새 방법의 사전동결 metrology를 위한 discriminator는 다음과 같아야 한다.

```text
same event bytes, same physical state, same quadrature
A. binary64 naive source order
B. binary64 canonical pairwise tree
C. binary64 compensated/Neumaier
D. MPFR 256-bit, round-to-nearest
E. MPFR result rounded once to binary64
```

비교해야 할 양:

\[
\delta_{\rm sum}=\|A-D_{53}\|,
\quad
\delta_{\rm map}=\|D_{53}-D_{256}\|,
\quad
\delta_{\rm perm}=\|P C(f)-C(Pf)\|.
\]

- A/B/C가 D에 수렴하면 reduction defect다.
- modal D는 covariant인데 native D가 covariant이면 binary64 map defect다.
- 256-bit native D도 covariant하지 않으면 discrete catalogue/basis/permutation defect다.
- 256-bit 결과가 exact covariant이지만 binary64 floor가 `1e-10`보다 높으면 gate observable가 condition-incompatible하다.

이 discriminator는 새 method contract에 포함할 수 있지만, D-028의 status를 retroactively 바꾸지는 않는다.

## 4.6 gate metrology audit

현재 native relative-L∞ co-gate의 문제는 세 가지다.

1. `1/y^2` inverse mass가 first nodes의 absolute noise를 크게 만든다.
2. denominator가 true action이 작은 state에서 cancellation scale을 반영하지 않는다.
3. cap `1e-10`이 operation graph, condition number, high-precision reference에서 유도됐다는 evidence가 없다.

따라서 prospective replacement은 세 norm을 동시에 freeze해야 한다.

\[
r_{\rm weak}
=\max_k\frac{|g_{\mu,k}-g_{\tau,k}|}{G_k^{\rm ref}},
\]

\[
r_{M,2}
=\frac{\sqrt{(C_\mu-C_\tau)^TM(C_\mu-C_\tau)}}
{\sqrt{C_\mu^TMC_\mu}+\sqrt{C_\tau^TMC_\tau}},
\]

\[
r_{\infty,\rm resolved}
=\max_{i:A_i>A_{\rm floor}}
\frac{|C_{\mu,i}-C_{\tau,i}|}{A_i}.
\]

`A_floor`는 output을 본 뒤 정하면 안 된다. 256-bit reference state에서 physical signal scale, tail scale, binary64 rounding envelope를 이용해 사전동결해야 한다. weak/modal norm만 통과했다고 native physical action을 무시해서도 안 되고, ill-conditioned native pointwise norm 하나가 weak conservation과 physical weighted agreement를 전부 대체해서도 안 된다.

## 4.7 exact-node, selector tie, event order audit

### Rust local linear bracket

exact node에서 one-hot으로 바꾸는 branch는 interior linear weights의 limit와 일치한다. value map은 연속이다. 다만 outgoing energy가 node를 통과할 때 derivative는 bracket slope가 바뀌므로 piecewise smooth이며 Jacobian의 kinematic derivative가 필요하면 양측 검사가 필요하다.

### D-029 three-node relative entropy

고정 support triple `(a,b,c)`와 positive prior `π_i`에 대해

\[
\max_{w_i>0}
-\sum_{i\in\{a,b,c\}}w_i\log\frac{w_i}{\pi_i}
\]

subject to

\[
\sum_iw_i=1,\qquad \sum_iw_i y_i=y_*
\]

는 `y_*`가 open convex hull 안에 있으면 strictly concave optimization이고 unique positive solution을 갖는다. 이 fixed-triple theorem은 sound하다.

하지만 executable method는 추가로 다음 map을 정의해야 한다.

\[
y_*\mapsto (a(y_*),b(y_*),c(y_*),\pi(y_*),w(y_*)).
\]

nearest-exterior selector의 tie에서 support가 바뀌고 exact node에서 별도 one-hot branch를 쓰면, 좌우 limit가 one-hot과 일치하는지, first derivative와 Jacobian이 존재하는지, label permutation이 selector 결과를 commute하는지 증명해야 한다. 현재 evidence는 이 global map을 포함하지 않는다. fixed triple theorem만으로는 continuity, Lipschitz bound, exact-node consistency, covariance, Jacobian existence를 결론낼 수 없다.

### Reduction order와 covariance

floating-point addition은 associative하지 않다. event list를 species label로 sort하면 mu↔tau permutation이 operation order도 바꿔 residual을 만들 수 있다. 다음 method는

- physical kinematics와 reaction-orbit ID로 canonical event key를 정의하고,
- label permutation 전후 동일 reduction tree를 사용하며,
- event order shuffle test를 binding arithmetic discriminator로 포함해야 한다.

post-output symmetrization `C←(C+PCP^{-1})/2`는 독립 증거를 지우는 후처리이므로 금지다.

# 5. Solver/Jacobian audit와 structural-independence graph

## 5.1 State vector와 chain rules

Rust spectral FLRW state는

\[
Y=(T_\gamma,t_{\rm sec},u_{E,1},\ldots,u_{E,N},u_{X,1},\ldots,u_{X,N}),
\]

\[
f=\sigma(u)=\frac{1}{1+e^{-u}},\qquad
h(f)=f(1-f)=\frac{df}{du}
\]

다. occupation RHS는

\[
R_i(Y,N)=\frac{du_i}{dN}=\frac{C_i(Y,N)}{H(Y,N)h_i}.
\]

occupation coordinate `u_j`에 대한 완전한 Jacobian은

\[
\frac{\partial R_i}{\partial u_j}
=
\frac{1}{Hh_i}\frac{\partial C_i}{\partial u_j}
-R_i\frac{\partial\log H}{\partial u_j}
-\delta_{ij}R_i(1-2f_i).
\]

전자 action source가 `∂C/∂f_j`를 반환하면

\[
\frac{\partial C_i}{\partial u_j}
=\frac{\partial C_i}{\partial f_j}f_j(1-f_j).
\]

self action은 source가 logit derivative를 직접 반환한다. Hubble derivative는

\[
\frac{\partial\log H}{\partial u_j}
=\frac{1}{2\rho_{\rm tot}}
\frac{\partial\rho_\nu}{\partial u_j}.
\]

EM temperature row에는 `Q_ν`, `H`, `dρ_em/dTγ`의 모든 derivative가 포함돼야 한다. source는 occupation block과 Friedmann rank-one term을 analytic하게 조합하고, photon-temperature column과 explicit-`N` derivative는 finite difference로 계산한다.

### 단위 검산

- `C_i/H`는 무차원이다.
- `du_i/dN`는 무차원이다.
- `dTγ/dN`는 `MeV`다.
- `dt_sec/dN=(\hbar/H)`는 `s`다.
- Jacobian occupation–occupation block은 무차원이고 temperature column은 `MeV^{-1}`이 곱해진 RHS 단위를 갖는다.

## 5.2 Exact-FD overwrite와 Jacobian contract

`electron_spectral.rs::evaluate_isotropic_electron_spectral_action_impl`은 먼저 event stream과 raw conservative action/Jacobian을 계산한 뒤,

```text
Tγ bits == Tcm bits
and every input occupation bits == directly evaluated FD(y) bits
```

이면 folded action arrays를 exact zero로 채운다. `fold_jacobian` 결과는 그대로 반환한다. focused test도 “action은 모두 exact zero, Jacobian에는 nonzero entry가 존재”를 명시적으로 요구한다.

branch map을

\[
\widetilde C(x)=
\begin{cases}
0,&x=x_*\text{ (bitwise exact FD)},\\
C_{\rm raw}(x),&x\ne x_*,
\end{cases}
\]

로 쓰자.

- `C_raw(x_*)≠0`이면 `\widetilde C`는 점 불연속이다.
- `C_raw(x_*)=0`이면 value branch는 중복일 수 있지만, `J_raw(x_*)`가 실제 양측 방향미분과 일치하는지 확인해야 한다.
- 현재 public API는 overwritten value만 노출하므로 첫 조건을 직접 판별할 evidence가 없다.
- exact equality branch는 Newton/BDF가 우연히 정확한 FD bit pattern을 밟을 때만 활성화되며, one-ULP 이웃에서는 raw map으로 바뀐다.

따라서 이 branch는 “analytic detailed balance identity”로 간주할 수 없다. identity라면 stable Pauli algebra에서 eventwise `A=0`로 0이 나와야 하며 별도 point overwrite가 필요 없어야 한다. 적어도 trajectory 승인 전 raw action, overwritten action, returned Jacobian, one-sided derivatives를 함께 검사해야 한다.

## 5.3 BDF exact-point cache

`ode.rs::solve_bdf`의 cache key는

\[
(t.to\_bits(),[y_i.to\_bits()]_{i=1}^n)
\]

이다. finite full dense Jacobian만 저장하고 같은 BDF solve 내부 한 entry만 보유한다. 따라서

- 다른 time/state에서 근사 재사용하지 않는다.
- NaN equality나 tolerance-based alias가 없다.
- deterministic RHS/Jacobian이면 arithmetic-neutral optimization이다.
- system 내부 mutable state, non-deterministic reduction, hidden cache가 있다면 exact input만으로 동일 Jacobian을 보장할 수 없으므로 별도 purity assumption이 필요하다.

역사 evidence의 55.815% improvement와 bitwise endpoint equality는 performance claim을 지지하지만 collision physics correctness를 지지하지 않는다.

## 5.4 Rodas5P path

custom Rodas path는 accepted point에서 `rhs_and_jacobian`, `dfdt`를 평가해 한 linearization

\[
W=\frac{1}{\gamma h}I-J
\]

를 만들고 8 stages에 같은 LU를 사용한다. rejected step에서는 state/time이 변하지 않으므로 같은 point linearization을 재사용하고 `h`만 줄인다. accepted step 뒤에는 linearization을 무효화한다.

error norm은

\[
\|e\|_W=
\left[\frac1n\sum_i
\left(\frac{e_i}{atol_i+rtol|y_i|}\right)^2\right]^{1/2}
\]

이다. component tolerances가 temperature, seconds, logits의 다른 physical scales를 충분히 반영해야 한다. tail logits의 large magnitude와 small `f(1-f)` 때문에 occupation action error와 logit error의 관계가 node마다 크게 다르다.

## 5.5 Event finding

BDF는 accepted-step bracket 안에서 solver dense interpolation을 호출해 bisection한다. Rodas는 accepted step의 시작점과 같은 frozen linearization을 사용해 shorter-step `rodas_attempt`를 반복한다. 후자는 일반적인 continuous extension polynomial과 동일하지 않으며 다음을 별도로 검증해야 한다.

\[
|T_\gamma(Y_{event})-T_{stop}|,
\quad
|N_{left}-N_{right}|,
\quad
\|Y_{event}^{BDF}-Y_{event}^{Rodas}\|_W.
\]

또한 bracket 전 구간에서 `Tγ(N)`가 감소한다는 monotonicity diagnostic과, event interpolation state가 strict-open occupation을 유지하는지 필요하다. final `N`과 `N_eff`만 비교하면 root interpolation defect를 숨길 수 있다.

## 5.6 Stiffness sources와 solver boundary

주요 stiffness scale은

\[
\frac{\Gamma}{H}\sim G_F^2M_{\rm Pl}T^3
\]

이며 10 MeV 부근에서 크고 냉각과 함께 급격히 감소한다. 추가 stiffness는

1. collision Jacobian의 fast equilibration eigenmodes,
2. logit chain `1/[f(1-f)]`의 tail amplification,
3. finite electron-mass threshold와 support geometry,
4. photon EOS derivative,
5. off-grid event-domain changes

에서 온다.

IMEX/AP scheme는 fast collision mode를 implicit 또는 penalized 처리해 temporal stiffness를 줄일 수 있다. 그러나 잘못된 spatial action `C_h`를 정확히 적분할 뿐이므로 D-027 nonconservation, D-028 native covariance, D-029 selector discontinuity를 고칠 수 없다. 현재 blocker에는 solver 개발보다 static collision method가 먼저다.

## 5.7 Radau independence

SciPy Radau는 Rust BDF/Rodas와 다른 implicit Runge–Kutta time discretization을 제공할 수 있다. 그러나 comparator가 같은 collision event bytes, same EOS routine, same mapper를 호출하면 time integrator만 independent다. endpoint authority에는 적어도 다음 axes를 구분해야 한다.

```text
collision derivation
momentum-space discretization
EOS/FLRW mapping
Jacobian construction
stiff time integration
event/output metrology
```

Radau numerical Jacobian은 Rust analytic Jacobian의 독립 check가 될 수 있지만, static collision action이 먼저 통과하고 comparator bytes가 blind-frozen된 뒤에만 의미가 있다.

## 5.8 최소 prospective Jacobian directional contract

trajectory 권한 전 다음 contract가 필요하다.

### States

1. exact common FD at `T=10, 3, 1 MeV`.
2. exact FD의 각 coordinate one-ULP 양측.
3. resolved nonthermal S1 states.
4. outgoing support edge의 양측.
5. exact interpolation node의 양측.
6. CP/mu–tau permuted states.

### Directions

- each component basis vector,
- seeded orthonormal random vectors,
- total-temperature mode,
- electron–heavy antisymmetric mode,
- mu–tau permutation-odd mode,
- tail-localized mode.

### Residual

\[
r_J(h;v)=
\frac{\|Jv-[F(Y+hv)-F(Y-hv)]/(2h)\|_W}
{\|Jv\|_W+\|D_hFv\|_W+A_{floor}}.
\]

smooth cell에서는 five-point stencil도 함께 사용한다.

\[
D_h^{(5)}Fv=
\frac{-F(Y+2hv)+8F(Y+hv)-8F(Y-hv)+F(Y-2hv)}{12h}.
\]

`h` ladder는 output 전에 정한다. 예: `h=2^{-k}max(1,||Y||∞)`, `k=18,...,34`, 단 strict domain을 벗어나는 step은 one-sided stencil로 분리한다. pass는 최소 residual 하나를 고르는 방식이 아니라, truncation-dominated slope와 roundoff plateau가 256-bit oracle 예측과 일치하고 analytic `Jv`가 그 envelope 안에 들어오는 것으로 정의해야 한다.

exact-FD overwrite 지점에서는 raw/branched map 양쪽의 one-sided derivative를 별도 artifact로 기록한다. branch가 남아 있고 좌우 derivative가 반환 Jacobian과 다르면 trajectory는 금지다.

## 5.9 Structural-independence dependency graph

```text
Published constants/formulas
|-- GF, me, sin^2θW, GN, FD statistics, FLRW identities
|
+-- Rust production
|   |-- folded E/X state
|   |-- selected positive half-line N48 grid
|   |-- local linear interpolation/deposition
|   |-- 4 aggregated self topologies + 15 electron semantic events
|   |-- tree finite-me EM EOS
|   |-- analytic/FD mixed Jacobian
|   `-- Rust BDF + Rust Rodas5P
|
+-- D-027
|   |-- explicit 6 species
|   |-- affine GL48 finite interval
|   |-- independently written CM kinematics
|   |-- direct target-leg native action
|   `-- shared constants/catalogue semantics/test states/gates
|
+-- D-028
|   |-- explicit 6 species
|   |-- affine GL48 + full Legendre entropy basis
|   |-- global weak event assembly
|   |-- native 1/y^2 mass inversion
|   `-- shared constants/catalogue semantics/test states/gates
|
`-- D-029
    |-- no collision implementation
    |-- fixed 3-node entropy weight theorem
    |-- local GL prior + target-dependent selector
    `-- no global collision/Jacobian/covariance evidence
```

## 5.10 무엇을 공유해도 되는가

공유가 epistemically 허용되는 것:

- CODATA/PDG-like universal constants with exact source and units.
- published Standard Model amplitudes, 단 independently rederived crossing/spin convention.
- physical endpoint definition `Tγ=0.005 MeV`.
- comparison output schema와 pre-output caps.
- same physical initial condition.

공유하면 agreement가 circular해지는 것:

- Rust nine-row folded coefficients를 그대로 복사한 independent catalogue.
- Rust event aggregation 또는 exact same event byte stream.
- same local interpolation/deposition code translation.
- same grid, tail rejection, exact-FD overwrite.
- Rust EOS/FLRW function 호출.
- Rust endpoint output을 보고 선택한 test states, denominator, cap, reduction order.
- failed output 뒤에 정한 favourable norm.

## 5.11 Endpoint authority에 필요한 최소 independent axes

| axis | independence requirement | 허용 cross-check |
|---|---|---|
| collision derivation | **must be independent** explicit species/spin/crossing ledger | published formulas/constants 공유 가능 |
| spatial discretization | **must be materially independent** | 같은 invariant weak form은 물리적으로 공유 가능, basis/grid/deposition은 달라야 함 |
| time integrator | **must be independent** for endpoint | Rust BDF/Rodas와 SciPy Radau 비교 |
| EOS/FLRW mapping | 독립 구현 또는 256-bit formula oracle 필요 | same physical EOS formula는 가능, Rust call 금지 |
| Jacobian | numerical or independently derived | Rust analytic J와 directional check 가능 |
| output metrology | pre-output frozen independent implementation | exact schema와 physical units 공유 가능 |

다른 언어라는 사실만으로 independence가 생기지 않는다. 반대로 같은 `G_F`를 쓴다고 independence가 사라지는 것도 아니다. 핵심은 오류가 전파될 수 있는 algorithmic/convention dependency를 끊는 것이다.

# 6. Ranked P0–P3 findings와 replacement-method matrix

## 6.1 Ranked findings overview

| ID | Priority | status | root cause | blocker effect |
|---|---:|---|---|---|
| F10-AUD-001 | P0 | **VALIDATED** | independent static gate failure | endpoint authority 직접 차단 |
| F10-AUD-002 | P0 | **DERIVED** | exact-FD point overwrite/Jacobian contract | trajectory/Jacobian authority 차단 |
| F10-AUD-003 | P0 | **DERIVED** | D-028 native map conditioning | 반복 covariance 실패 설명 후보 |
| F10-AUD-004 | P1 | **VALIDATED** | D-027 nonconservative point form | direct pointwise route 폐기 |
| F10-AUD-005 | P1 | **DERIVED** | condition-blind gate metrology | 새 method cap 설계 필요 |
| F10-AUD-006 | P1 | **DERIVED** | normalization proof gap | hidden Rust physics error 미배제 |
| F10-AUD-007 | P1 | **DERIVED** | finite-domain tail truncation | continuum/endpoint error 미정 |
| F10-AUD-008 | P1 | **VALIDATED** | provenance and regression drift | current-tree claim inflation 방지 |
| F10-AUD-009 | P2 | **DERIVED** | incomplete structural independence | apparent agreement의 순환 위험 |
| F10-AUD-010 | P2 | **DERIVED** | solver/Jacobian later risks | static pass 후 trajectory 조건 |
| F10-AUD-011 | P2 | **SPECIFIED** | electron entropy proof gap | H-theorem authority 미완성 |
| F10-AUD-012 | P3 | **DERIVED** | stale docs and obsolete source surface | 감사·유지보수 비용 증가 |

## 6.2 Findings in required schema

### F10-AUD-001 / P0 / VALIDATED

**Symptom / Source / Mathematical or physical mechanism:**  
`G-F10-INDEPENDENT-FLRW`는 공개 `GATE_REGISTRY.json`, `CONTEXT_PACK.md`, `FROZEN_DECISIONS.md`, `VALIDATION_LEDGER.md`에서 fail로 유지된다. D-027은 non-equilibrium moment caps를 넘었고 D-028은 native mu–tau co-gate를 넘었으며 D-029는 semidiscrete method proof 전에 reject됐다. 세 실패 모두 time integration 전 단계다.

**Exact evidence path and line or function / Assumptions:**  
`.agent-harness/context/GATE_REGISTRY.json`; `.agent-harness/generated/CONTEXT_PACK.md`의 D-027–D-029 summary; `.agent-harness/context/FROZEN_DECISIONS.md`; `src/rabbit/decoupling/_independent_noqke.py::{_assemble_self,_assemble_electron,_native_action,evaluate_independent_collision_action}`. 역사 raw artifacts는 공개 baseline에 없으므로 registry/decision record를 hash-locked historical evidence로 사용한다.

**Consequence / Remedy:**  
trajectory, Radau, endpoint, RABBIT unblinding은 허가할 수 없다. 기존 method를 cap 변경 또는 GL64로 계속하는 대신 materially new static method를 pre-register해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
현재 confidence는 높다. gate registry가 pass로 바뀌는 것만으로는 부족하고, 사전동결된 새 static package가 catalogue, moments, entropy, covariance, arithmetic bounds를 통과해야 바뀐다.

### F10-AUD-002 / P0 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
전자 operator는 exact bitwise common-FD state에서 computed action을 0으로 덮지만 computed Jacobian을 유지한다. raw action이 그 점에서 exact zero가 아니면 map은 불연속이고, exact zero여도 branch를 포함한 map의 derivative와 returned Jacobian 일치가 미증명이다.

**Exact evidence path and line or function / Assumptions:**  
`native/rabbit_cpu/src/electron_spectral.rs::exact_reference_state`; `evaluate_isotropic_electron_spectral_action_impl`, 특히 `electron_pair_mev.fill(0.0)`, `heavy_pair_mev.fill(0.0)` 뒤 `fold_jacobian`; focused test `common_temperature_fd_is_an_exact_null_with_a_nonzero_linear_response`. Assumption은 adjacent one-ULP states가 raw branch를 탄다는 source semantics다.

**Consequence / Remedy:**  
Newton/BDF/Rodas/Radau가 사용하는 RHS/Jacobian contract에 source-level 위험이 있다. exact null은 event affinity로 algebraically 얻도록 바꾸거나, branch를 포함한 raw/one-sided derivative가 일치함을 증명해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
raw action을 overwrite 전 노출하는 test-only pure function, exact state와 각 coordinate one-ULP 양측의 256-bit directional ladder를 실행한다. raw action이 bitwise zero이고 모든 one-sided derivative가 returned Jacobian과 맞으면 finding을 P2 documentation issue로 낮출 수 있다. 현재 confidence는 중상이다.

### F10-AUD-003 / P0 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
D-028에서 weak/modal discriminators는 favourable했지만 native mu–tau relative-L∞가 `4.666064056497196e-10`으로 실패했다. `_native_action`의 `1/y²` inverse mass와 global Legendre reconstruction이 binary64 perturbation을 증폭한다.

**Exact evidence path and line or function / Assumptions:**  
`src/rabbit/decoupling/_independent_noqke.py::_native_action`; affine GL48 `[0,24]` grid/basis; geometry-only calculation `cond_2(diag(y^-2)B)=7.528878426860986e6`, `ε64κ=1.671746835820939e-9`. raw collision scale/cancellation factor는 공개 artifact 부재로 **UNAVAILABLE**이다.

**Consequence / Remedy:**  
관측 residual은 ordinary rounding과 양립하므로 modal/native 결과가 모순되지 않는다. 다음 method는 `y^-2` pointwise inversion을 binding covariance gate의 중심에 두지 말고 local positive mass와 physically weighted weak norms를 사용해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
동일 event bytes를 naive/pairwise/compensated/MPFR 256-bit로 평가하고 modal 및 native permutation residual을 분리한다. 256-bit native residual이 남으면 deeper covariance defect로 판정이 바뀐다. conditioning 결론 confidence는 높고 root-cause exclusivity confidence는 중간이다.

### F10-AUD-004 / P1 / VALIDATED

**Symptom / Source / Mathematical or physical mechanism:**  
D-027 direct target-point action은 common-FD total null을 통과했지만 self number `1.9782e-10`, self energy `2.3350e-10`, electron exchange `1.0684e-7`로 frozen caps를 넘었다. target equation을 직접 계산하는 방식은 global four-leg weak deposition의 adjoint identities를 보장하지 않는다.

**Exact evidence path and line or function / Assumptions:**  
D-027 decision record; historical `M1_POINTWISE_STATIC_RESULT.json` path; rejected predecessor implementation in comparator history. 수치는 공개 decision/ledger를 따른다.

**Consequence / Remedy:**  
D-027을 evolving RHS로 재사용하거나 cap을 완화하면 안 된다. conservation을 후처리하지 말고 semidiscrete equation 자체에 all-leg deposition을 넣어야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
같은 target quadrature를 global event weak form으로 다시 유도했을 때 constants/linear functions가 exact 재현되는지 symbolic test한다. D-027 자체는 frozen fail이므로 status는 바뀌지 않는다. confidence 높음.

### F10-AUD-005 / P1 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
D-028 binding native relative-L∞ cap `1e-10`은 inverse-mass condition, signal floor, cancellation scale에서 유도되지 않았다. 작은 node의 absolute noise를 large relative residual로 바꿀 수 있다.

**Exact evidence path and line or function / Assumptions:**  
`_native_action`; `evaluate_independent_collision_action`의 `_relative_max_difference`; D-028 registered metric/cap. Assumption은 native action이 scientific observable로 쓰이려면 quadrature-weighted physical contribution과 pointwise signal 둘을 구별해야 한다는 것이다.

**Consequence / Remedy:**  
D-028은 여전히 fail이다. 다음 design에는 weak/modal, mass-weighted native, resolved pointwise norms와 사전동결 denominator를 함께 등록해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
256-bit output 전 condition model로 cap을 derive하고 blind binary64 result가 그 envelope를 따르는지 검사한다. condition-aware derivation이 기존 `1e-10`을 정당화하면 meta-finding은 철회 가능하다. confidence 높음.

### F10-AUD-006 / P1 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
Rust와 comparator의 electron coupling coefficient가 source상 다르게 보인다. doubled `gL/gR`, outer `32`, spin factor, directed-edge `1/2`, pair orientation을 결합하면 정합 가능하지만, 독립 spin/crossing/phase-space oracle가 없다.

**Exact evidence path and line or function / Assumptions:**  
`native/rabbit_cpu/src/electron_hm.rs::author_hm_w_over_gf2_mev4`; `electron_phase_point.rs::physical_point_density`; `electron_spectral.rs::conservative_explicit_action`; comparator `_electron_couplings`, `_electron_matrix`, `_event_measure`. 정합 해석은 forward/reverse directed orientations가 exact change of variables로 대응한다는 가정을 쓴다.

**Consequence / Remedy:**  
hidden factor-of-two 또는 crossing 오류는 반증되지 않았다. thermal aggregate anchor와 common-FD null만으로는 검출할 수 없다.

**Proof or prospective falsifier / Confidence and what would change it:**  
명시 spin states와 한 fixed physical four-momentum tuple에서 analytic trace, Rust convention, comparator convention을 256-bit로 비교한다. 각 channel의 target/global multiplicity와 measure를 별도 출력한다. 현재 confidence는 “proof gap 존재”에 높고 “실제 normalization bug”에는 낮다.

### F10-AUD-007 / P1 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
Rust self와 D-028은 outgoing energy 하나라도 stored grid 밖이면 whole event를 버린다. retained event conservation은 보존되지만 continuum collision rate가 truncation된다.

**Exact evidence path and line or function / Assumptions:**  
`neutrino_self_spectral.rs::{interpolation_bracket,build_event_stream}`; comparator `_assemble_self`의 `domain=(y3,y4 inside)`와 rejection count; electron elastic off-grid domain. Assumption은 endpoint nonthermal tail이 selected smooth-profile training envelope 밖으로 갈 수 있다는 것이다.

**Consequence / Remedy:**  
number/energy residual이 작아도 physical rate와 `N_eff`가 bias될 수 있다. clipping은 금지하고, extended-domain high-precision tail oracle와 whole-event lost-action bound를 binding convergence gate로 둬야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
`Ymax=32,40,48` extended oracle에서 retained/rejected event의 absolute collision L1, energy transfer, entropy contribution을 기록한다. tail bound가 모든 frozen states에서 cap의 1/4 아래면 risk를 P3로 낮출 수 있다. confidence 높음.

### F10-AUD-008 / P1 / VALIDATED

**Symptom / Source / Mathematical or physical mechanism:**  
프롬프트 dirty branch/HEAD와 공개 `main`이 다르고 raw run files가 공개되지 않았다. `230/230`은 역사 full release이며 later focused run은 240-test crate를 보고했다.

**Exact evidence path and line or function / Assumptions:**  
public repository metadata/HEAD; `.agent-harness/generated/CONTEXT_PACK.md`; `docs/harness/VALIDATION_LEDGER.md` 2026-07-16 `230/230` row와 2026-07-18 four focused filters row; public-history re-root rows. remote connector가 working tree를 제공하지 않는다는 표준 Git semantics.

**Consequence / Remedy:**  
현재-tree full regression pass 또는 역사 SHA-256 일치를 주장할 수 없다. future owner review는 raw bundle 또는 hash-locked read-only checkout을 제공해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
`bd612-remediation@0b2339c...` bundle과 dirty patch, six files, raw runs를 read-only로 제공하고 prompt hashes를 재계산하면 provenance gap이 닫힌다. confidence 매우 높음.

### F10-AUD-009 / P2 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
D-026/D-028은 다른 언어, explicit species, 다른 grid/basis를 쓰지만 physical catalogue semantics, constants, test states, gates를 상당 부분 공유한다. agreement가 생겨도 shared convention error를 완전히 배제하지 못한다.

**Exact evidence path and line or function / Assumptions:**  
`independent_self_reactions`, `independent_self_events`, fingerprint `(2,1,6,2,2,1,4,4,2)`; F-10 future-plan nine-row table; shared context의 frozen constants/caps.

**Consequence / Remedy:**  
다음 validator는 row factors를 production table에서 복사하지 말고 explicit Lagrangian/spin/crossing derivation artifact에서 생성해야 한다. grid, basis, event ordering, EOS, solver도 별도 구현한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
blind dependency manifest와 source provenance를 작성하고, production outputs unblinding 전 comparator hash를 freeze한다. independent derivation notes가 row-by-row trace를 재현하면 risk가 낮아진다. confidence 중상.

### F10-AUD-010 / P2 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
BDF/Rodas 성능은 개선됐지만 static collision blocker와 무관하다. 이후에도 mixed analytic/finite-difference Jacobian, tail logit stiffness, Rodas event refinement가 endpoint risk다.

**Exact evidence path and line or function / Assumptions:**  
`isotropic_boltzmann.rs::{write_rhs,write_jacobian,dfdt}`; `ode.rs::{solve_bdf,rodas_attempt,solve_rodas5p,weighted_norm,event_fires}`; exact cache key implementation.

**Consequence / Remedy:**  
solver optimization이나 IMEX/AP 구현을 현재 blocker progress로 세면 안 된다. static pass 후 directional-Jacobian contract와 bounded segment가 먼저다.

**Proof or prospective falsifier / Confidence and what would change it:**  
section 5.8 contract, independent Radau numerical Jacobian, event residual/monotonicity artifacts가 pass하면 endpoint risk가 낮아진다. confidence 높음.

### F10-AUD-011 / P2 / SPECIFIED

**Symptom / Source / Mathematical or physical mechanism:**  
Rust electron edge construction은 number/lepton invariants를 구조적으로 보존하지만, paired flux와 paired fermionic affinity의 sign relation을 모든 channels에 대해 source-level theorem으로 제시하지 않는다.

**Exact evidence path and line or function / Assumptions:**  
`electron_spectral.rs::conservative_explicit_action`; `electron_event::pauli_gradient`; electron matrix/channel catalogue. Assumption은 H-theorem claim이 sampled states가 아니라 all admissible `0<f<1` states에 대해 필요하다는 것이다.

**Consequence / Remedy:**  
전자 sector entropy production을 **VALIDATED**로 과장하면 안 된다. global semantic event를 복원해 `(F-R)log(F/R)` 형태를 직접 증명하거나 counterexample search를 해야 한다.

**Proof or prospective falsifier / Confidence and what would change it:**  
각 paired directed-edge algebra를 symbolic하게 canonical event flux로 reduce하고, 256-bit random/adversarial states에서 sign을 검사한다. exact reduction이 성립하면 **DERIVED**로 승격 가능하다. 현재는 proof obligation이 **SPECIFIED**됐다.

### F10-AUD-012 / P3 / DERIVED

**Symptom / Source / Mathematical or physical mechanism:**  
문서와 source header 일부가 현재 authority와 어긋난다. pair report의 `T^4` 차원 오류, implementation guide의 오래된 JAX-first 서술, `isotropic_boltzmann.rs`의 obsolete incomplete-catalogue header, 약 `1531–3924` line Fort exporter가 대표적이다.

**Exact evidence path and line or function / Assumptions:**  
`docs/RABBIT_report/sections/09_pair_annihilation_and_creation.tex`; `docs/IMPLEMENTATION_GUIDE_FULL_COLLISION_NOQKE.md`; `native/rabbit_cpu/src/isotropic_boltzmann.rs` module header 및 test-only Fort evidence exporter.

**Consequence / Remedy:**  
외부 감사자가 obsolete architecture를 current physics로 오해하고, 약 2.4k-line stopped exporter가 source review surface를 크게 만든다. evidence archive 후 삭제/격리가 비용효율적이다.

**Proof or prospective falsifier / Confidence and what would change it:**  
current authority를 반영한 docs diff와 exporter deletion 후 source-line audit를 수행한다. physics result는 바뀌지 않아야 한다. confidence 높음.

## 6.3 Replacement family 1 — positive conservative explicit-event/deposition method

### Semidiscrete equations

독립 validator는 six species를 fold하지 않고 유지한다. momentum knots `0=y_0<...<y_N=Ymax`와 nonnegative local hat basis `λ_i(y)`를 택한다.

\[
\lambda_i(y)\ge0,\qquad
\sum_i\lambda_i(y)=1,\qquad
\sum_i y_i\lambda_i(y)=y.
\]

entropy variable과 occupation은

\[
u_s(y)=\sum_i\lambda_i(y)u_{s,i},
\qquad f_s(y)=\sigma(u_s(y)).
\]

positive lumped measure는

\[
m_i=\frac{T_{\rm cm}^3}{2\pi^2}
\int_0^{Y_{max}}y^2\lambda_i(y)dy>0.
\]

각 global physical event `e,q`의 flux를

\[
\Phi_{eq}=W_{eq}\overline{|\mathcal M_{eq}|^2}(F_{eq}-R_{eq})
\]

로 두면

\[
m_i\frac{df_{s,i}}{dt}
=\sum_{e,q}\Phi_{eq}
\sum_{\ell=1}^4\sigma_\ell
\mathbf1_{s_\ell=s}\lambda_i(y_{\ell q}),
\]

\[
m_if_{s,i}(1-f_{s,i})\frac{du_{s,i}}{dt}
=\text{same RHS}.
\]

전자 bath legs는 `u_e=-E_e/Tγ`로 event affinity에 포함하고, evolved electron DOF 대신 eventwise `Q_em=-Q_ν`와 bath entropy contribution을 누적한다.

### 구조적 성질

number:

\[
\sum_{s,i}m_i\dot f_{s,i}
=\sum_{e,q}\Phi_{eq}\sum_\ell\sigma_\ell=0
\]

for self `2↔2` events.

energy:

\[
\sum_{s,i}m_iy_i\dot f_{s,i}
=\sum_{e,q}\Phi_{eq}\sum_\ell\sigma_\ell y_{\ell q}=0.
\]

entropy:

\[
\dot S_h=-\sum_{s,i}m_iu_{s,i}\dot f_{s,i}
=\sum_{e,q}W_{eq}|M|^2(F-R)\log(F/R)\ge0.
\]

이 세 identity는 같은 `λ`를 evaluation과 deposition에 쓸 때 eventwise exact arithmetic으로 성립한다. `u`가 finite이면 reconstructed `f`는 자동으로 `0<f<1`이다. conservation projection이나 post-hoc symmetrization이 필요 없다.

### covariance와 tail

explicit species catalogue를 flavour-orbit generator로 만들고 event reduction key를 kinematics/reaction-orbit 기반으로 정의한다. mu–tau/CP permutation은 input/output indices만 바꾸며 reduction tree는 동일해야 한다. exact node는 hat basis의 자연스러운 one-hot limit이므로 별도 selector branch가 없다.

`Ymax` 밖 event는 whole-event reject하되 extended-domain 256-bit oracle로 lost collision L1, energy, entropy를 bounded한다. clipping이나 one-leg tail extrapolation은 금지한다.

### conditioning/Jacobian

mass `m_i`는 cell-integrated positive quantity라 `1/y_i²` singular inversion이 없다. local basis support 때문에 Jacobian sparsity는 event coupling이 정하지만 basis evaluation 자체는 well-conditioned다. event flux derivative는 smooth logistic/Pauli algebra이며, support boundary에서만 piecewise smooth하다. branch 양측 directional checks가 필요하다.

### complexity

`Q`를 retained event quadrature count, `R`을 reaction count라 하면 action은 `O(RQ)`이고 각 event deposition은 four legs × at most two local basis entries다. memory는 block streaming 시 `O(N_species N + block Q)`다. dense Jacobian materialization은 `O((6N)^2)`이지만 matrix-free JVP 또는 sparse accumulation이 가능하다.

### independence/cost

- Rust folding, N48 half-line grid, four-topology aggregation을 복제하지 않는다.
- explicit six species, independent local compact grid, independent CM parameterization과 event order를 쓴다.
- Radau와 호환되고 Rust endpoint와 physical moments로 비교 가능하다.
- smallest static surface estimate: implementation/tests `+1,300–1,800` lines.
- replacement pass 후 obsolete D-027/D-028 comparator와 stopped Fort exporter를 archive/delete하면 `-3,500–4,200` lines; net `-2,900` to `-1,700` lines.
- blocker-movement ratio estimate `0.8–0.9`; cost verdict **PROPOSED / COST-EFFECTIVE**, 단 static-only owner authorization 조건.

### pre-output falsifiers와 abandonment

abandon if any of the following occurs before trajectory:

1. `Σλ=1` 또는 `Σy_iλ_i=y`가 binary64/MPFR operation graph에서 frozen bound를 넘음.
2. event entropy sign counterexample.
3. permutation changes event multiset/reduction tree.
4. support-edge Jacobian이 unbounded or discontinuous beyond declared piecewise contract.
5. tail lost-action bound가 physical gate budget의 1/4를 넘고 feasible `Ymax`에서도 감소하지 않음.
6. high-precision explicit-species matrix oracle와 row normalization 불일치.

**Primary recommendation:** 이 family를 다음 static design으로 선택한다.

## 6.4 Replacement family 2 — conservative spectral/Galerkin–Petrov

### Semidiscrete equations

basis `φ_k(y)`로

\[
u_s(y)=\sum_{k=0}^{K-1}a_{s,k}\phi_k(y)
\]

를 두고

\[
M(a)\dot a=G(a),
\qquad
M_{jk}(a)=\int d\mu_y\,\phi_j\phi_k f(1-f),
\]

\[
G_{s,j}=\langle\phi_j,C_s[f_a]\rangle
\]

를 푼다. `φ_0=1`, `φ_1=y`를 포함하면 weak number/energy identities를 직접 보존할 수 있다.

Fourier conservative spectral literature에서 자주 쓰는 correction은

\[
G_c=G-M^{-1}Q^T(QM^{-1}Q^T)^{-1}QG
\]

형태의 Lagrange-multiplier projection이다. 이는 mass/momentum/energy를 enforce하지만 current decision 아래 post-hoc correction으로 사용하면 안 된다. method definition의 일부로 output 전 유도·승인해도 positivity, fermionic entropy, covariance를 별도 증명해야 한다.

### 평가

- global full-degree basis는 D-028과 같은 native conditioning/oscillation 위험이 있다.
- orthonormality를 `y²dy` measure에 맞추고 modal coefficients를 직접 evolve하면 `1/y²` native inversion을 피할 수 있다.
- logistic reconstruction은 positivity를 주지만 global polynomial `u`의 tail oscillation과 dense Jacobian을 만든다.
- complexity는 naive event–mode `O(RQK)`; mass solve `O(K^3)` 또는 structured `O(K²)`.
- structural independence는 medium; D-028와 너무 가깝기 때문에 global version은 권고하지 않는다.

local element basis와 block mass를 사용하고 conservation을 weak form 자체에 넣는다면 viable fallback이 된다.

- estimate `+1,600–2,300`, deletion after pass `-3,500–4,200`, net `-2,600` to `-1,200`.
- blocker-movement `0.65–0.8`.
- abandonment: block condition `>10^4`, negative/oscillatory reconstructed occupation without transform, covariance floor above frozen bound, or need for output-dependent projection.

**Fallback recommendation:** full global Legendre가 아니라, entropy-variable local Galerkin/Petrov with block-diagonal exact mass와 basis `{1,y}` reproduction을 선택한다.

## 6.5 Replacement family 3 — entropy-stable renormalized moment / DG

fermionic exponential-family ansatz를

\[
f_\alpha(y)=\sigma(\alpha\cdot m(y))
\]

로 두고 moments

\[
U_k(\alpha)=\int d\mu_y\,m_k(y)f_\alpha(y)
\]

를 evolve한다.

\[
H_{kj}(\alpha)\dot\alpha_j
=\langle m_k,C[f_\alpha]\rangle,
\]

\[
H_{kj}=\frac{\partial U_k}{\partial\alpha_j}
=\int d\mu_y\,m_km_j f_\alpha(1-f_\alpha).
\]

`H`는 realizable interior에서 positive definite이고 `0<f<1`은 automatic이다. collision weak form이 event affinity와 dual이면 entropy dissipation을 설계할 수 있다.

하지만 다음 obligation이 크다.

- chosen finite moments가 decoupling spectral distortion을 충분히 표현하는가.
- moment vector가 realizable set interior에 남는가.
- dual solve conditioning이 tail/near-FD에서 안정적인가.
- local cells/DG interfaces를 쓰면 interface entropy flux가 momentum-space collision과 어떻게 결합되는가.
- electron bath와 six-species permutation covariance가 dual basis에서 exact인가.

Abdelmalik–van Brummelen의 result는 classical Boltzmann renormalization과 physical-space DG에 대한 구조다. `φ`-divergence/entropy-variable 원리는 transfer 가능하지만 fermionic entropy, cosmological radial measure, Pauli bounds, reaction catalogue는 새로 유도해야 한다.

- complexity: each RHS에 nonlinear dual solve plus collision, roughly `O(Ncell K^3+RQK)`.
- estimate `+2,500–4,000`; deletion 후 net `-1,700` to `+500`.
- blocker-movement `0.45–0.7`; first replacement으로는 비용이 크다.
- abandonment: realizability boundary 접근, dual Hessian condition excess, low-order moments가 frozen nonthermal states를 재현 못함.

## 6.6 Replacement family 4 — matrix-free weak collocation with constrained local solves + IMEX/AP

local collocation action을 먼저 계산하고 each event의 deposition weights `w`를 constrained solve로 정할 수 있다.

\[
\min_w\frac12\|w-w_0\|_{R}^2
\quad\text{s.t.}\quad
Aw=b,
\quad w\ge0,
\]

여기서

\[
A=\begin{pmatrix}1&\cdots&1\\y_{i_1}&\cdots&y_{i_m}\end{pmatrix},
\qquad b=(1,y_*)^T.
\]

이 weights를 evaluation/deposition에 동일하게 쓰면 moments와 positivity를 얻을 수 있다. 그러나 active set이 바뀌면 `w(y_*)`의 derivative가 discontinuous할 수 있다. fixed support 또는 smooth interior barrier와 global feasibility proof가 필요하다. D-029가 실패한 바로 그 지점이다.

시간 discretization은 예를 들어

\[
\frac{f^{n+1}-f^n}{\Delta t}
=\frac1\varepsilon P(f^{n+1})
+\left[C_h(f^n)-\frac1\varepsilon P(f^n)\right]
\]

같은 penalized IMEX/AP form을 쓸 수 있다. Filbet–Hu–Jin의 quantum AP idea는 stiff temporal relaxation에 transfer 가능하다. 그러나 `C_h`의 spatial conservation/entropy/covariance가 먼저 증명돼야 한다.

- complexity: local QP/Newton per off-grid leg plus collision; active-set/Jacobian overhead가 큼.
- estimate `+2,200–3,200`; deletion 후 net `-2,000` to `-300`.
- blocker-movement `0.5–0.7`.
- abandonment: selector/active-set branch의 global Lipschitz proof 실패, local solve failure, covariance가 solver tie-breaking에 의존.

## 6.7 Replacement family 5 — high-precision/interval reference evaluator

production endpoint가 아니라 validation oracle다. 같은 continuum event formula를 MPFR 256-bit round-to-nearest와 directed rounding으로 평가한다.

\[
C^{[\downarrow,\uparrow]}=
\sum_{eq}^{\rm fixed\ order}
W_{eq}^{[\downarrow,\uparrow]}
|M|_{eq}^{2,[\downarrow,\uparrow]}
J_{eq}^{[\downarrow,\uparrow]}.
\]

가능한 경우 conservation combinations는 exact rational/MPFR identity로 평가하고, transcendental FD/logistic만 directed interval로 감싼다.

용도:

- spin/crossing/normalization point oracle.
- naive/pairwise/Kahan binary64 error attribution.
- mu–tau/CP permutation exactness.
- tail and quadrature ladder reference.
- cap derivation.

하지 말아야 할 용도:

- slow MPFR endpoint를 production number-of-record로 승격.
- 같은 flawed discretization을 high precision으로 돌리고 “continuum validation”이라 부름.
- output 후 cap을 high-precision result에 맞춰 조정.

- estimate `+500–800` lines, net same unless obsolete utilities deleted.
- blocker-movement `0.4–0.55` alone, but primary/fallback의 필수 ancillary.
- cost verdict **PROPOSED / COST-EFFECTIVE AS ORACLE ONLY**.

## 6.8 Replacement-method matrix

| criterion | positive event/deposition | local conservative GP | renormalized moment/DG | constrained collocation + IMEX/AP | MPFR oracle |
|---|---|---|---|---|---|
| unknowns | six-species nodal logits | local modal logits | dual variables/moments | nodal/cell logits + local weights | none evolved |
| number/energy | eventwise by partition/linear reproduction | weak exact if `{1,y}` in test space | moment exact if included | constraint exact | reference check |
| entropy | direct event proof | possible with entropy-variable duality | central design property | requires smooth constrained weights | evaluates sign |
| positivity/Pauli | logistic + nonnegative basis | logistic; modal oscillation risk | exponential family | logistic + positive weights | arbitrary precision only |
| covariance | explicit species + canonical tree | basis/catalogue proof | moment-basis proof | tie-breaking risk | exact discriminator |
| tail | whole-event + extended bound | same | closure/tail moment risk | local support/tail solve | strongest bound |
| binary64 conditioning | local, no `1/y²` point inversion | block condition manageable | dual Hessian can stiffen | local solve conditioning/branches | not production |
| Jacobian regularity | piecewise smooth support | smooth inside elements | smooth realizable interior | active-set risk | directional reference |
| complexity | `O(RQ)` | `O(RQK)+mass solve` | collision + nonlinear dual | collision + many local solves | high constant |
| structural independence | high | medium-high if local/new grid | high | medium-high | high arithmetic axis |
| Radau compatibility | strong | strong | possible but dense | possible, IMEX optional | no trajectory |
| smallest surface | best | moderate | large | large | small ancillary |
| verdict | **primary** | **fallback** | research option | later option | mandatory oracle |

## 6.9 Web-CRAG: retained primary sources와 transfer limits

검색일은 2026-07-19이며, query는 arXiv identifier/title와 `fermionic/Uehling-Uhlenbeck/conservative/entropy/AP` 조합으로 수행했다. blog, vendor summary, secondary review만 있는 결과는 제외했다.

실제 query log:

```text
site:arxiv.org 1710.05903 Galerkin-Petrov Boltzmann Gamba Rjasanow
site:arxiv.org 1611.04171 conservative spectral approximation Boltzmann Alonso Gamba Tharkabhushanam
site:arxiv.org 1602.01312 entropy stable renormalized moment discontinuous Galerkin Boltzmann Abdelmalik van Brummelen
site:arxiv.org 1009.3352 asymptotic preserving quantum Boltzmann Filbet Hu Jin
arXiv astro-ph/9506015 neutrino decoupling Hannestad Madsen
arXiv hep-ph/0506164 relic neutrino decoupling Mangano
arXiv 1912.09378 incomplete neutrino decoupling Froustey Pitrou
arXiv 2008.01074 neutrino decoupling full collision QKE diagonal limit
site:arxiv.org fermionic Boltzmann entropy stable numerical method Uehling Uhlenbeck positivity conservation
site:arxiv.org conservative discrete velocity method quantum Boltzmann Fermi Dirac
MPFR official manual arbitrary precision correct rounding
```

| source | retained claim | 이 operator에 transfer되는 가정 | transfer되지 않는 가정 / rejection criterion |
|---|---|---|---|
| Gamba & Rjasanow, [arXiv:1710.05903](https://arxiv.org/abs/1710.05903) | spatially homogeneous classical Boltzmann Galerkin–Petrov weak design | global weak testing, collision invariants | classical Maxwellian/statistics; Pauli bound와 FLRW radial fermion entropy 자동 아님 |
| Alonso, Gamba & Tharkabhushanam, [arXiv:1611.04171](https://arxiv.org/abs/1611.04171) | conservative spectral method와 error analysis | invariant-constrained spectral approximation | Lagrangian optimization correction은 current policy상 post-hoc projection; positivity/fermionic entropy 미보장 |
| Abdelmalik & van Brummelen, [arXiv:1602.01312](https://arxiv.org/abs/1602.01312) | divergence closure와 entropy-stable renormalized DG | entropy-variable/dual closure principle | classical Boltzmann/physical-space DG theorem을 그대로 fermionic collision에 적용 불가 |
| Filbet, Hu & Jin, [arXiv:1009.3352](https://arxiv.org/abs/1009.3352) | Fermi/Bose quantum Boltzmann AP temporal treatment | quantum equilibrium과 stiff collision penalization | spatial collision discretization correctness를 주지 않음; current static blocker 해결 못함 |
| Hannestad & Madsen, [astro-ph/9506015](https://arxiv.org/abs/astro-ph/9506015) | full FD statistics, finite electron mass neutrino decoupling | physical reaction context와 tree-level finite-me treatment | historical whole calculation을 one-to-one code authority로 쓰면 안 됨 |
| Mangano et al., [hep-ph/0506164](https://arxiv.org/abs/hep-ph/0506164) | momentum-dependent decoupling and flavour context | spectral-distortion/output context | oscillations/QKE가 scope 밖; old endpoint number를 gate로 쓰면 안 됨 |
| Froustey & Pitrou, [arXiv:1912.09378](https://arxiv.org/abs/1912.09378) | no-oscillation decoupling consequences for BBN | F-10 scope에 가장 가까운 physical context | specific implementation/grid를 독립 authority로 복사 금지 |
| Froustey, Pitrou & Volpe, [arXiv:2008.01074](https://arxiv.org/abs/2008.01074) | full collision QKE derivation | diagonal zero-mixing limit의 reaction/convention cross-check | off-diagonal/QKE architecture **FORBIDDEN** |
| Wu, [arXiv:1810.03090](https://arxiv.org/abs/1810.03090) | quantum Uehling–Uhlenbeck fast spectral method | fermionic factors와 quantum mixture conservation evidence | nonrelativistic gas/cross sections; cosmological weak matrix elements와 Pauli entropy 재유도 필요 |
| Prakapenia et al., [arXiv:1801.02408](https://arxiv.org/abs/1801.02408) | isotropic relativistic Uehling–Uhlenbeck event method, exact particle/energy conservation | reaction-oriented isotropic relativistic deposition의 선례 | QED plasma reactions; weak flavour catalogue와 FLRW mapping은 별도 |
| [GNU MPFR current manual](https://www.mpfr.org/mpfr-current/mpfr.html) | arbitrary precision, explicit rounding, reproducible 53-bit emulation | high-precision/reference arithmetic | continuum or quadrature correctness를 자체로 보장하지 않음 |

CRAG rejection rules:

```text
- method name만 같고 semidiscrete equation이 없는 source 제외
- classical positivity/H-theorem을 fermionic Pauli bound로 자동 이전하는 주장 제외
- post-hoc conservation correction을 current authorization 없이 recommendation으로 쓰지 않음
- QKE/off-diagonal architecture는 diagonal-limit formula context 외 제외
- endpoint Neff agreement만 제시하는 method는 collision validator로 제외
- inverse problem이 정의되지 않은 Bryan-style maximum entropy는 category error로 제외
```

Bryan-style maximum entropy는 likelihood, prior, reconstructed object가 있는 inverse problem을 푸는 방법이다. 현재 forward nonlinear collision discretization은 inverse reconstruction으로 정식화되지 않았으므로 적용 대상이 아니다. local entropy-variable closure를 “maximum entropy”라 부를 경우에는 primal `f/weights`, dual multipliers, feasible moments, prior measure, selector, global regularity를 모두 명시해야 한다.

# 7. Prospective experiment contract와 bounded patch sequence

## 7.1 Proposed contract identity

**Contract ID:** `F10-PCED-S0-v0`  
**Status:** **PROPOSED**  
**Immediate authority requested:** static source + static tests + high-precision oracle only  
**Not authorized by this contract:** Rust production edit other than separately approved exact-FD branch repair; collision trajectory; GL64 resurrection; Radau segment; endpoint; RABBIT output; Fort; QKE.

이 contract는 결과를 본 뒤 바뀌지 않도록 inputs, operation order, norms, cap derivation, failure policy를 먼저 고정한다.

## 7.2 Frozen physical inputs

```text
species order:
  [nu_e, antinu_e, nu_mu, antinu_mu, nu_tau, antinu_tau]

constants:
  m_e       = 0.5109989500 MeV
  G_F       = 1.1663788e-11 MeV^-2
  sin2theta = 0.23122
  G_N       = 6.708830746231458e-45 MeV^-2
  MeV_to_s-1= 1.519267447878626e21 s^-1

metric:
  (-,+,+,+), chi_ij = -p_i.p_j

statistics:
  strict-open Fermi occupations, zero chemical potential for equilibrium tests

production-candidate spatial representation:
  local nonnegative piecewise-linear entropy basis
  knots y_i = 32*(i/64)^2, i=0,...,64
  Ymax = 32

extended static reference representation:
  knots y_i = 40*(i/96)^2, i=0,...,96
  Ymax = 40

base event quadrature:
  self p2: 64-point affine GL on [0,32]
  electron p2: 64-point GL in r in (0,1), p=Tgamma*r/(1-r)
  incoming mu12: GL12
  final mu*: GL12
  final phi: 16 exact midpoint angles

reference event quadrature:
  p2: 96-point corresponding rules, Ymax=40 for neutrino legs
  mu12: GL16
  mu*: GL16
  phi: 32 midpoints

arithmetic:
  binary64 round-to-nearest, FMA contraction disabled for reference comparisons
  MPFR 256-bit round-to-nearest
  MPFR directed up/down for interval checks
```

위 grid/quadrature 숫자는 owner가 승인하기 전 **PROPOSED**일 뿐이다. 승인되면 output 전에 source bytes, generated nodes/weights, ordering manifest를 hash-lock해야 한다. 다른 숫자를 쓰려면 이 contract를 실행하기 전에 새 version으로 review해야 한다.

## 7.3 Frozen states

### E0 common FD family

For `T=Tγ=Tcm∈{10,3,1} MeV`:

\[
u_s(y)=-y\quad\forall s.
\]

### S-self common nonthermal shape

`Tγ=Tcm=3 MeV`, self block만 평가:

\[
u_s(y)=-y+0.10\,y e^{-y/4}
\quad\forall s.
\]

이는 affine FD가 아니므로 self energy redistribution은 nonzero지만 species symmetry는 유지된다.

### S-split flavour-resolved state

`Tγ=Tcm=3 MeV`:

\[
\begin{aligned}
u_{\nu_e}=u_{\bar\nu_e}&=-y+0.08y e^{-y/3},\\
u_{\nu_\mu}=u_{\bar\nu_\mu}&=-y-0.05\frac{y^2}{1+y^2}e^{-y/5},\\
u_{\nu_\tau}=u_{\bar\nu_\tau}&=-y+0.03\sin(y/2)e^{-y/6}.
\end{aligned}
\]

### S-electron exchange

`Tcm=1 MeV`, `Tγ=1.2 MeV`, all neutrinos exact FD at `Tcm`:

\[
u_s(y)=-y.
\]

self block은 eventwise null이고 electron block만 energy exchange를 만든다.

### S-CP and permutation negative controls

- CP-odd control: add `+0.02e^{-y/4}` to `νe` and `-0.02e^{-y/4}` to `antiνe`; transformed state swaps them and electron couplings.
- mu–tau control: use S-split and exact swap `μ↔τ`.
- family control: relabel `e↔μ` while also transforming charged-current coupling flag; without coupling transform it is an intentionally non-symmetry negative control.

### Support/branch states

Construct event tuples analytically so `y3` or `y4` is

```text
exactly y_i
nextafter(y_i, -infinity)
nextafter(y_i, +infinity)
exactly Ymax
nextafter(Ymax, -infinity)
nextafter(Ymax, +infinity)
```

for selected interior and boundary knots. No random search is used to choose favourable cases.

## 7.4 Frozen ordering and reduction

Canonical event key:

```text
(reaction_orbit_id,
 canonical_unordered_initial_species_pair,
 canonical_unordered_final_species_pair,
 target_grid_index,
 p2_quadrature_index,
 mu12_index,
 mustar_index,
 phi_index,
 orientation_id)
```

The key is defined before assigning concrete `mu` or `tau` integer labels. A permutation changes species indices in the deposited result but not the physical event order.

Binding binary64 reduction is balanced pairwise summation with a deterministic tree over the canonical key. Naive source-order and Neumaier compensated sums are diagnostic comparators, not alternative pass routes. A binding failure may not be retried with another order.

## 7.5 Norms and cap derivation

### Algebraic event identities

For an event with deposited vector `d`, define

\[
r_N^{event}=\frac{|\sum_i d_i|}{\sum_i|d_i|+\mathrm{tiny}},
\]

\[
r_E^{event}=\frac{|\sum_i y_i d_i-\sum_\ell\sigma_\ell y_\ell\Phi|}
{\sum_i|y_id_i|+\sum_\ell|y_\ell\Phi|+\mathrm{tiny}}.
\]

MPFR cap:

\[
r^{event}_{MPFR}\le2^{-180}.
\]

binary64 pairwise cap is operation-count based:

\[
B_{fp}(n)=128\,[\lceil\log_2n\rceil+8]\epsilon_{64}.
\]

`n`은 해당 reduction의 exact nonzero summand count이며 output value와 무관하게 event manifest에서 계산된다.

### Catalogue-level weak moments

\[
r_N=\frac{|\sum_s\langle1,C_s\rangle|}{\sum_s\langle1,|C_s|\rangle+S_N},
\]

\[
r_E=\frac{|\sum_s\langle y,C_s\rangle|}{\sum_s\langle y,|C_s|\rangle+S_E}.
\]

`S_N,S_E`는 MPFR reference의 smallest nonzero absolute scale를 seal한 값이며 candidate output을 보기 전에 hash-lock한다. cap은 `max(B_fp(n),4*MPFR_interval_width/scale)`다.

### First law

\[
r_{1st}=\frac{|Q_\nu+Q_{em}|}{|Q_\nu|+|Q_{em}|+Q_{floor}}.
\]

`Q_floor`는 E0 MPFR interval의 upper bound와 IEEE minimum-normal가 아니라 S-electron MPFR physical scale의 `2^-80`배 중 큰 값으로 미리 정한다. binding cap은 same operation-count formula plus MPFR interval width다.

### Entropy

\[
\Sigma=\sum_{eq}W_{eq}|M|^2(F-R)\log(F/R).
\]

Pass:

```text
MPFR lower interval bound >= 0
binary64 Sigma >= -B_entropy
```

`B_entropy`는 pairwise absolute summand bound `B_fp(n)*Σ|term|`로 사전 계산한다. 단순 `Sigma>=-1e-X` 같은 scale-free cap은 쓰지 않는다.

### Covariance

weak and mass-weighted metrics:

\[
r_{weak}=\frac{\|g_\mu-Pg_\tau\|_2}{\|g_\mu\|_2+\|g_\tau\|_2+G_{floor}},
\]

\[
r_{M}=\frac{\|C_\mu-PC_\tau\|_M}{\|C_\mu\|_M+\|C_\tau\|_M+C_{floor}}.
\]

resolved pointwise metric is reported only where MPFR reference `A_i>A_floor`. `A_floor`, all denominators, and caps are sealed from the oracle before binary64 candidate unblinding. The cap is

\[
B_{cov}=4\left(B_{sum}+B_{round}+B_{basis}\right),
\]

where each term is computed from operation count, MPFR rounding-once difference, and analytic local-basis condition. No hard-coded `1e-10` is imported automatically.

### Physical quadrature/tail budget

The eventual cross-code collision weighted-L1 budget is `2e-2`. This static contract allocates it prospectively:

```text
base-to-reference quadrature: <= 5e-3
Ymax tail/lost whole-event action: <= 2.5e-3
binary64 arithmetic versus 256-bit same quadrature: <= 2.5e-3
remaining unallocated reserve: 1.0e-2
```

These caps are not derived from observed candidate output. They are a fixed error-budget split of the existing endpoint collision cap. Failure rejects the grid/quadrature design; it does not permit a favourable norm change.

## 7.6 Test-by-test contract

### T01 — explicit-species reaction/multiplicity oracle

**Identity:** 48 target-directed self rows reduce to family fingerprint `(2,1,6,2,2,1,4,4,2)`; 24 reversible self events; 18 electron target rows; 15 global electron events.  
**Input:** symbolic species set and Standard Model current/crossing rules, no Rust table import.  
**Oracle:** independently generated machine-readable reaction graph plus human trace ledger.  
**Units:** coefficients dimensionless; matrix blocks `G_F² MeV^4`.  
**Norm/cap:** exact integer equality; coefficient rational equality before floating conversion.  
**Conditioning:** none.  
**Pass/fail:** one missing/duplicate row or coefficient rejects source before collision execution.  
**Artifact:** `T01_CATALOGUE.json`, graph hash, derivation PDF/Markdown hash.  
**Failure action:** stop; classify production/comparator convention discrepancy, no tuning.

### T02 — common-FD eventwise nulls at three temperatures

**Identity:** `A=u3+u4-u1-u2=0`, `F-R=0` for every supported event.  
**Input:** E0 at 10, 3, 1 MeV, all reaction families.  
**Oracle:** MPFR 256-bit event affinity and stable Pauli factor.  
**Units:** event flux `MeV` after full measure; affinity dimensionless.  
**Norm/cap:** event `|A|` and `|J|` interval contains 0; binary64 under `B_fp`.  
**Conditioning:** null is absolute, not signed/absolute `0/0`.  
**Pass/fail:** any family-specific nonzero outside bound rejects formula/kinematics.  
**Artifact:** per-family max, worst event key, interval, no action overwrite.  
**Failure action:** stop; exact-reference branch may not hide result.

### T03 — resolved self-scattering non-equilibrium

**Identity:** total self number and energy zero; action nonzero; entropy nonnegative.  
**Input:** S-self and S-split, electron events disabled by catalogue mask fixed before output.  
**Oracle:** PCED weak event sum at MPFR; independent direct invariant moment reduction.  
**Units:** action `MeV`, number rate `MeV^4`, energy rate `MeV^5`.  
**Norm/cap:** `r_N,r_E≤B_fp/interval`; `Σ≥-B_entropy`; nonzero action must exceed sealed MPFR signal floor.  
**Conditioning:** reports cancellation factor `Σ|term|/|Σterm|`.  
**Pass/fail:** invariant or entropy fail rejects method.  
**Artifact:** weak coefficients, moments, entropy, event counts, tail losses.  
**Failure action:** no conservation projection; redesign deposition.

### T04 — resolved electron exchange

**Identity:** self block null for S-electron; electron `Qν=-Qem`; elastic species number and pair lepton difference exact.  
**Input:** `Tcm=1`, `Tγ=1.2`, neutrino FD.  
**Oracle:** explicit 15-event MPFR evaluator with analytic electron bath logits.  
**Units:** `Q` in `MeV^5`; action `MeV`.  
**Norm/cap:** first-law and weak charges under frozen arithmetic bounds; action signal above floor.  
**Conditioning:** separate elastic and pair cancellation scales.  
**Pass/fail:** factor-of-two/crossing discrepancy rejects matrix convention.  
**Artifact:** per-event family `Qν,Qem`, spin/multiplicity factors.  
**Failure action:** stop and adjudicate H2 versus implementation error.

### T05 — exact conserved weak moments and FLRW first law

**Identity:** all T03/T04 catalogue combinations satisfy charge vectors and EM–ν closure.  
**Input:** S-split plus S-electron.  
**Oracle:** reaction stoichiometric matrix `S` with exact integer null vectors; MPFR energy.  
**Units:** charge dimensionless, energy `MeV^5`.  
**Norm/cap:** exact integer charge null; numeric energy under formula cap.  
**Conditioning:** per-event and aggregate residual both stored.  
**Pass/fail:** aggregate pass cannot rescue eventwise fail.  
**Artifact:** nullspace matrix, row residuals, aggregate residual.  
**Failure action:** localize exact event key; candidate fail.

### T06 — entropy production

**Identity:** total neutrino+EM collision entropy is `Σ(F-R)log(F/R)≥0`.  
**Input:** E0, S-self, S-split, S-electron, 100 pre-seeded adversarial finite-logit states whose seed/hash is frozen.  
**Oracle:** directed MPFR interval.  
**Units:** entropy rate in natural-unit `MeV^3` times rate convention; normalized sign dimensionless.  
**Norm/cap:** lower interval bound nonnegative; binary64 `>=-B_entropy`.  
**Conditioning:** log ratio evaluated from logits, not `log(F/R)` of underflowed products.  
**Pass/fail:** one negative lower bound rejects candidate.  
**Artifact:** worst state/event, affinity, interval, summation variant.  
**Failure action:** stop; do not clip negative entropy.

### T07 — CP, family, and exact mu–tau transformations

**Identity:** `C(Pf)=PC(f)` for true symmetries; designated e↔μ negative control must not pass without coupling transform.  
**Input:** frozen CP/mu–tau states and transformed copies.  
**Oracle:** permutation of MPFR event graph, not independent rerouting code.  
**Units:** action `MeV`.  
**Norm/cap:** `r_weak,r_M,r_inf,resolved` with sealed floors/caps.  
**Conditioning:** operation order and event multiset hashes must be identical under permutation.  
**Pass/fail:** weak or weighted binding fail rejects; pointwise diagnostic cannot rescue.  
**Artifact:** event-order hashes, modal/weighted/native arrays.  
**Failure action:** distinguish event graph, reduction, basis map via arithmetic variants.

### T08 — support edge, exact node, selector tie, and tail

**Identity:** local hat basis continuous; exact node limit one-hot; whole-event support decision consistent; no selector tie.  
**Input:** exact/nextafter cases listed above, `Ymax=32/40`.  
**Oracle:** analytic basis and MPFR kinematics.  
**Units:** `y` dimensionless; action `MeV`.  
**Norm/cap:** value continuity under local Lipschitz bound; one-sided derivative finite; tail fraction `≤2.5e-3`.  
**Conditioning:** distance in ulps and physical `Δy` both stored.  
**Pass/fail:** branch discontinuity or one-leg loss rejects.  
**Artifact:** exact binary64 tuples, support booleans, basis weights, derivatives.  
**Failure action:** redesign support representation, not tolerance widening.

### T09 — reduction order and arithmetic

**Identity:** physical action invariant under event permutation in exact arithmetic.  
**Input:** T03/T04/T07, canonical list plus 16 pre-seeded permutations.  
**Oracle:** MPFR canonical sum.  
**Units:** all action/moment units.  
**Norm/cap:** pairwise binding result against MPFR rounded once; naive/Neumaier diagnostic.  
**Conditioning:** cancellation and pairwise tree depth reported.  
**Pass/fail:** canonical pairwise exceeds sealed arithmetic cap → fail; no retry with compensated binding result.  
**Artifact:** permutation seeds, hashes, all four arithmetic outputs.  
**Failure action:** reduce local cancellation or alter representation in a new contract version.

### T10 — native, weak, and physically weighted norms

**Identity:** independent representations describe the same semidiscrete action.  
**Input:** all static states.  
**Oracle:** direct weak moments and local mass map at MPFR.  
**Units:** weak coefficients with their basis units; native `MeV`; weighted moment physical units.  
**Norm/cap:** all three predeclared metrics; no metric replacement.  
**Conditioning:** local mass/basis condition estimates included.  
**Pass/fail:** any binding weak/weighted metric fails candidate; resolved pointwise applies only above sealed floor.  
**Artifact:** denominators and floor source hashes.  
**Failure action:** reject or new design review; no favourable subset.

### T11 — directional Jacobian across smooth and branch boundaries

**Identity:** analytic/JVP derivative agrees with high-order finite difference in smooth cells and declared one-sided derivative at support boundaries.  
**Input:** section 5.8 states/directions and exact-FD raw/one-ULP states.  
**Oracle:** MPFR finite-difference ladder with exact source order.  
**Units:** component-aware weighted norm.  
**Norm/cap:** truncation/roundoff envelope from step ladder, not minimum residual alone.  
**Conditioning:** `||J||`, spectral-radius estimate, chain-factor minima stored.  
**Pass/fail:** no valid convergence plateau or branch mismatch rejects trajectory authority.  
**Artifact:** all `h`, one/two/five-point estimates, slopes, raw branch values.  
**Failure action:** repair derivative/source; static collision value evidence remains separate.

### T12 — base/reference quadrature and tail convergence

**Identity:** physical collision action converges as quadrature/domain are enlarged while invariants remain structural.  
**Input:** base and reference grids/quadratures, T03/T04 states.  
**Oracle:** reference MPFR plus a second directed tail-only integration over `32<y<40`.  
**Units:** weighted collision L1, `Q`, entropy.  
**Norm/cap:** base/reference weighted L1 `≤5e-3`; tail `≤2.5e-3`.  
**Conditioning:** separate quadrature truncation from arithmetic using same-node MPFR.  
**Pass/fail:** failure rejects selected static design; no trajectory.  
**Artifact:** component/error budget ledger.  
**Failure action:** owner decides new grid contract or abandons route before more code.

### T13 — conditional 10-to-3 MeV segment

**Authorization condition:** T01–T12 all pass under blind review and owner issues a new explicit execution authorization.  
**Identity:** independent Radau reaches decreasing `Tγ=3 MeV` with first law, positivity, event residual, and tolerance/grid ladder.  
**Input:** `a=1`, `Tγ=Tcm=10 MeV`, exact FD; stop at `Tγ=3 MeV`.  
**Oracle:** SciPy Radau numerical Jacobian; no Rust collision/EOS calls.  
**Norm/cap:** static caps remain; segment cross-grid/tolerance budget allocated before run.  
**Pass/fail:** any static invariant drift or event failure stops; favourable endpoint scalar cannot rescue.  
**Artifact:** trajectory checkpoints, solver stats, raw failures.  
**Failure action:** no full endpoint.

### T14 — conditional full independent endpoint

**Authorization condition:** T13 pass plus fresh owner authorization and second blind hash review.  
**Identity:** reach decreasing `Tγ=0.005 MeV`; compare Rust only after independent artifact freeze.  
**Input:** frozen initial state, constants, grids, tolerances, event algorithm.  
**Oracle:** independent Radau endpoint and uncertainty ladder.  
**Norm/cap:** existing endpoint/collision/energy/spectral caps with independent uncertainty; no output-driven change.  
**Conditioning:** mapper, tail, solver, quadrature uncertainties separated.  
**Pass/fail:** any structural gate fails outright; uncertainty above half hard cap is inconclusive, not pass.  
**Artifact:** sealed independent bundle, then RABBIT unblinding diff.  
**Failure action:** retain independent failure; do not tune Rust or comparator constants.

## 7.7 Artifact schema

각 test artifact는 최소 다음 JSON schema를 따른다.

```json
{
  "contract_id": "F10-PCED-S0-v0",
  "test_id": "Txx",
  "status": "pass|fail|not_run|forbidden",
  "authorization_id": "owner-signed-id-or-null",
  "source_commit_or_bundle": "...",
  "source_sha256": {"file": "hash"},
  "input_manifest_sha256": "...",
  "platform": {"os": "...", "compiler": "...", "python": "...", "mpfr": "..."},
  "constants": {"units": "MeV natural units", "values": {}},
  "species_order": [],
  "grid": {},
  "quadrature": {},
  "event_order": {"key_version": "...", "event_count": 0, "hash": "..."},
  "arithmetic": {"mode": "pairwise|naive|neumaier|mpfr256", "fma": false},
  "metrics": [{"name": "...", "value": 0.0, "denominator": 0.0, "cap": 0.0,
               "cap_derivation": "...", "binding": true}],
  "conditioning": {"sum_abs": 0.0, "cancellation_factor": 0.0, "basis_condition": 0.0},
  "worst_case": {"event_key": "...", "state_id": "..."},
  "raw_array_sha256": {},
  "failure_policy_action": "...",
  "notes": []
}
```

`status=pass`는 모든 binding metric이 pass일 때만 가능하다. exception, missing artifact, nonfinite value, hash mismatch는 raw fail이다.

## 7.8 Bounded patch sequence — maximum five patches

### Patch 1 — exact-FD branch contract repair

**Scope:** `electron_spectral.rs`와 focused tests만.  
**Action:** overwrite 전 raw action을 test-only로 노출하고 one-ULP/Jacobian contract를 추가한다. raw event algebra가 exact null을 주지 못하면 point overwrite를 제거하고 affinity-based exact detailed balance를 method level에서 구현한다.  
**Authority:** production physics edit이므로 별도 owner authorization 필요.  
**Blocker movement:** trajectory/Jacobian risk 직접 제거.  
**Size estimate:** `+120–220/-20–60`, net `+80–200`.

### Patch 2 — high-precision explicit-species oracle and frozen contract

**Scope:** 새 private oracle module, reaction derivation data, static tests; no production call.  
**Action:** T01/T02/T04 matrix/measure/multiplicity, MPFR arithmetic, cap manifests.  
**Authority:** static nonphysical evidence generation authorization.  
**Blocker movement:** H2 normalization/catalogue uncertainty 직접 공격.  
**Size estimate:** `+500–800`; BMR high for evidence slice.

### Patch 3 — PCED static independent method

**Scope:** one private implementation module + one focused test module; no public registry/driver.  
**Action:** six species, local entropy basis, all-leg deposition, T03–T12.  
**Authority:** static collision execution only, exact source hashes blind-reviewed.  
**Blocker movement:** independent spatial blocker의 핵심.  
**Size estimate:** `+800–1,000` implementation, `+500–800` tests/artifacts.

### Patch 4 — evidence archive and net source deletion

**Condition:** Patch 3 static pass 또는 owner가 route abandonment를 확정한 뒤.  
**Scope:** failed comparator code와 stopped Fort exporter를 immutable evidence archive로 옮긴 뒤 active source에서 삭제; stale headers/docs 수정.  
**Authority:** deletion/archive authorization.  
**Blocker movement:** obsolete surface를 additions보다 크게 삭제.  
**Size estimate:** `+150–300/-3,500–4,200`, net `-3,200` to `-3,350`.

### Patch 5 — conditional Radau segment and endpoint adapter

**Condition:** T01–T12 pass, fresh owner authorization.  
**Scope:** private Radau segment, event/root metrology, no new public wrapper. Endpoint는 segment pass 후 같은 patch 안에서도 별도 authorization checkpoint를 요구한다.  
**Blocker movement:** static에서 independent FLRW endpoint로 이동.  
**Size estimate:** `+350–600`; old trajectory stubs가 있으면 net smaller.

이 sequence는 “작은 wrapper를 계속 추가”하지 않는다. Patch 1–3은 각각 physics/Jacobian, independent convention, independent spatial method blocker를 이동하고, Patch 4는 추가보다 훨씬 많은 obsolete surface를 지운다. Patch 5는 조건부 endpoint evidence만 만든다.

# 8. Owner decision memo와 red-team objections

## 8.1 Owner decision memo

### Recommended decision

다음 한정된 작업만 승인하는 것이 합리적이다.

1. 역사 `bd612-remediation@0b2339c...` dirty snapshot과 raw D-027/D-028/D-029 evidence를 read-only bundle로 제공한다. 이 작업은 physics output을 만들지 않는다.
2. `electron_spectral.rs` exact-FD overwrite의 raw-action/one-ULP/Jacobian contract를 별도 production-edit authorization으로 감사한다.
3. `F10-PCED-S0-v0`를 design review 후 hash-lock하고, explicit six-species MPFR oracle와 positive conservative event/deposition static method만 구현·실행한다.
4. T01–T12가 모두 pass하기 전에는 Radau, segment, endpoint, RABBIT unblinding을 금지한다.
5. static pass 또는 route abandonment 후 failed comparator와 stopped Fort exporter를 evidence archive로 보존하고 active source에서 삭제한다.

### Exact authorization boundary

**허용하려면 owner가 명시해야 할 문구의 핵심:**

```text
Authorize only the hash-locked F10-PCED-S0-v0 static source and T01-T12
executions, plus the separately scoped exact-FD branch/Jacobian audit.
No GL64 resurrection, no D-028 cap or metric change, no Fort execution,
no Radau segment, no trajectory, no endpoint, no RABBIT unblinding,
no QKE, no public production surface, and no post-output method change.
Any binding failure closes this contract version.
```

T13에는 별도 segment authorization이, T14에는 segment pass 후 두 번째 endpoint/unblinding authorization이 필요하다.

### Why this is the smallest useful slice

- D-027 실패 원인인 non-adjoint target action을 all-leg weak deposition으로 제거한다.
- D-028의 global modal/native `1/y²` condition을 local positive mass로 피한다.
- D-029의 target-dependent selector를 사용하지 않는다.
- explicit species와 independent reaction oracle로 shared-folding error를 공격한다.
- MPFR는 arithmetic metrology를 제공하지만 production endpoint를 대체하지 않는다.
- pass 후 obsolete source를 대량 삭제할 수 있어 policy상 cost-effective하다.

## 8.2 Red-team objections

### Objection 1 — “D-028는 겨우 `4.7e-10`이므로 사실상 pass다.”

반론: frozen cap은 `1e-10`이고 output 후 바꿀 수 없다. condition analysis는 D-028를 pass시키는 근거가 아니라 다음 metric을 더 잘 설계해야 한다는 meta-finding이다.

판정을 바꿀 evidence: D-028 자체는 바뀌지 않는다. 새 method에서 pre-output 256-bit condition-derived cap을 통과해야 한다.

### Objection 2 — “exact-FD overwrite는 물리 항등식을 코드에 넣은 것뿐이다.”

반론: 항등식이면 raw event algebra가 0을 내야 한다. 한 bit pattern에서 value만 바꾸고 Jacobian은 유지하는 것은 derivative contract를 자동 보장하지 않는다.

판정을 바꿀 evidence: overwrite 전 raw action이 exact zero이고 one-ULP 양측 directional derivative가 returned Jacobian과 일치한다는 sealed artifact.

### Objection 3 — “새 positive event/deposition method도 Rust와 너무 비슷해 독립적이지 않다.”

반론: conservation을 위해 같은 universal weak identity를 사용하는 것은 불가피하다. independence는 explicit six species, independently derived spin/crossing graph, different compact local grid, no E/X folding, no four-topology aggregation, independent event ordering, independent EOS/Radau, MPFR metrology에서 확보한다.

판정을 바꿀 evidence: source dependency audit가 Rust row table 또는 event stream translation을 발견하면 recommendation을 철회한다.

### Objection 4 — “tail event loss는 기존 smooth tests에서 이미 작다.”

반론: sampled smooth states와 arbitrary nonthermal endpoint state는 다르다. whole-event rejection은 invariant를 보존하면서도 physical rate를 bias할 수 있다.

판정을 바꿀 evidence: frozen states와 extended-domain MPFR에서 lost weighted collision action, energy, entropy가 각각 allocated budget 아래이고 domain ladder에서 감소하는 evidence.

### Objection 5 — “global spectral method에 conservation projection만 붙이면 더 싸다.”

반론: Lagrange projection은 conservation 외에 positivity, Pauli bound, entropy, covariance를 보장하지 않는다. current decision은 post-hoc projection을 허용하지 않는다.

판정을 바꿀 evidence: projection이 method 정의에 사전 포함되고, feasible set 내부에서 `0<f<1`, entropy nondecrease, permutation covariance, smooth Jacobian을 동시에 증명하는 owner-approved design.

### Objection 6 — “three-node maximum entropy를 selector만 조금 고쳐 다시 쓰면 된다.”

반론: 문제는 작은 coding bug가 아니라 global selector/prior/exact-node branch가 하나의 continuous covariant semidiscrete map으로 증명되지 않았다는 것이다. output 없이 selector를 바꾸더라도 D-029 route의 continuation이 아니라 새 design review가 필요하다.

판정을 바꿀 evidence: fixed global support 또는 globally smooth partition, positive weights, moment feasibility, exact-node limit, uniform Lipschitz/Jacobian, permutation covariance, full 24-self/15-electron binary64 ledger를 하나의 theorem/implementation contract로 제공하는 것.

### Objection 7 — “solver endpoint를 먼저 돌리면 실제 영향이 작은지 알 수 있다.”

반론: endpoint scalar는 compensating errors를 숨긴다. static conservation/covariance/Jacobian이 실패한 상태에서 endpoint agreement는 collision correctness evidence가 아니다.

판정을 바꿀 evidence: 없음. ordering rule상 static pass가 선행 조건이다.

### Objection 8 — “public raw evidence가 없으므로 이번 감사도 inconclusive다.”

반론: raw absence는 exact hash and numerical re-adjudication을 제한하지만, 공개 source에서 확인한 exact-FD branch, comparator native map, gate registry fail, stale 230/230 provenance는 독립적으로 판정 가능하다. 다만 historical raw numbers의 재계산은 의도적으로 주장하지 않았다.

판정을 바꿀 evidence: read-only bundle 제공으로 source/hash detail이 달라질 수 있다. 그 경우 manifest와 line-level findings를 갱신하되 binding fail을 pass로 추정하지 않는다.

### Objection 9 — “electron coefficient convention은 source에서 이미 algebraically 맞으므로 H2를 닫아도 된다.”

반론: doubled couplings, spin factor, phase-space measure, directed orientation을 모두 결합한 해석은 plausible하지만, 한 fixed physical tuple의 independent spin trace와 integrated target/global counting이 없다. aggregate anchor는 factor/crossing 오류의 상쇄를 배제하지 못한다.

판정을 바꿀 evidence: T01/T04 explicit spin-state 256-bit oracle가 모든 18 target rows와 15 semantic events를 exact하게 재현하는 것.

### Objection 10 — “새 method의 proposed grid/caps도 임의적이다.”

반론: 그래서 이 문서는 실행 권한이 아니라 owner-reviewable contract다. grid는 local conditioning과 independent-axis를 위해 선택했고, physical caps는 existing collision budget을 사전 분할하며 arithmetic caps는 operation count와 MPFR interval에서 유도한다. owner가 숫자를 바꾸려면 output 전에 contract version을 올려 재review해야 한다.

판정을 바꿀 evidence: pre-output condition/quadrature-only analysis가 다른 grid가 명백히 더 작고 안정적임을 보이면 `v1` contract로 교체 가능하다. `v0` output을 본 뒤 교체하는 것은 금지다.

## 8.3 Evidence that would reverse the main recommendation

primary PCED recommendation을 철회할 충분한 evidence는 다음 중 하나다.

1. symbolic proof에서 local hat evaluation/deposition entropy identity가 electron semantic event pairing과 양립하지 않음.
2. source-independent matrix trace가 Rust/comparator catalogue와 근본적으로 다른 operator를 요구해 spatial method보다 physics convention repair가 먼저임.
3. pre-output condition-only audit에서 local mass/Jacobian condition이 global alternative보다 나쁘고 frozen bound를 충족하지 못함.
4. T08 이전의 analytic support proof가 whole-event truncation과 local basis를 연속 RHS로 만들 수 없음을 보임.
5. source dependency audit에서 proposed implementation이 Rust algorithm의 mechanical translation임.

반대로 recommendation을 강화하는 evidence는 T01–T12의 blind pass, exact-FD branch repair, explicit-species normalization equality, pairwise/MPFR arithmetic agreement, tail budget pass다.

## 8.4 Final adjudication

MULTIPLE_ROOT_CAUSES

- `G-F10-INDEPENDENT-FLRW`는 **반드시 fail로 유지**해야 한다.
- D-029는 **closed 상태를 유지**해야 한다; fixed-triple theorem은 보존하되 현재 selector-based design을 재개하면 안 된다.
- 가장 작은 owner-authorized next design slice는 **exact-FD branch/Jacobian static audit + explicit six-species MPFR reaction oracle + PCED T01–T12 static package**다.
- 권고 작업은 repository policy 아래 **조건부로 cost-effective**하다: independent blocker를 직접 움직이고, pass 또는 abandonment 뒤 obsolete comparator/Fort source를 additions보다 크게 삭제할 수 있다.
