# BIBLIOGRAPHY

## Internal repository records

1. `BD622_D071_trajectory_closure_2026-08-04.md`, commit snapshot `2d866dfd…`.
2. `BD622_V3_report_2026-08-06.md`, commit snapshot `2d866dfd…`.
3. `scripts/audit/_trajectory_core.py`, blob `465a73f0…`.
4. `src/rabbit/decoupling/_independent_noqke.py`, branch snapshot `f10-independent-validation-b3v2`.
5. Existing candidate probes listed in `00_SOURCE_MAP.md`.

## External literature

1. Birrell, J.; Wilkening, J.; Rafelski, J. “Boltzmann Equation Solver Adapted to Emergent Chemical Non-equilibrium.” *Journal of Computational Physics* 281 (2015), 896–916. arXiv:1403.2019. DOI: 10.1016/j.jcp.2014.10.056.
2. Birrell, J.; Yang, C.-T.; Rafelski, J. “Relic Neutrino Freeze-out: Dependence on Natural Constants.” arXiv:1406.1759.
3. Bond, J. R.; Fuller, G. M.; Grohs, E.; Meyers, J.; Wilson, M. J. “Cosmic Neutrino Decoupling and its Observable Imprints: Insights from Entropic-Dual Transport.” arXiv:2403.19038.
4. Escudero, M.; Jackson, G.; Laine, M.; Sandner, S. “Fast and Flexible Neutrino Decoupling Part I: The Standard Model.” arXiv:2511.04747.
5. Froustey, J.; Pitrou, C.; Volpe, M. C. “Neutrino decoupling including flavour oscillations and primordial nucleosynthesis.” arXiv:2008.01074.
6. Bennett, J. J. et al. “Towards a precision calculation of N_eff in the Standard Model II.” arXiv:2012.02726.
7. Filbet, F.; Jin, S. “A class of asymptotic preserving schemes for kinetic equations and related problems with stiff sources.” arXiv:0905.1378.
8. Gamba, I. M.; Jin, S.; Liu, L. “Micro-macro decomposition based asymptotic-preserving numerical schemes and numerical moments conservation for collisional nonlinear kinetic equations.” arXiv:1809.00028.
9. Einkemmer, L.; Hu, J.; Zhang, S. “Asymptotic-Preserving Dynamical Low-Rank Method for the Stiff Nonlinear Boltzmann Equation.” arXiv:2502.08951.
10. Veroy, K.; Patera, A. T. “Certified real-time solution of the parametrized steady incompressible Navier–Stokes equations: rigorous reduced-basis a posteriori error bounds.” DOI: 10.1002/fld.867.
11. Canuto, C.; Tonn, T.; Urban, K. “A Posteriori Error Analysis of the Reduced Basis Method for Nonaffine Parametrized Nonlinear PDEs.” DOI: 10.1137/080724812.
12. Drohmann, M.; Haasdonk, B.; Ohlberger, M. “Reduced Basis Approximation for Nonlinear Parametrized Evolution Equations based on Empirical Operator Interpolation.” DOI: 10.1137/10081157X.
13. “Goal-oriented model reduction for parametrized time-dependent nonlinear partial differential equations.” DOI: 10.1016/j.cma.2021.114206.
