# SOURCE MAP

PROJECT: RABBIT F10 Independent-FLRW Mathematical-Physics Blocker Resolution
SOURCE SNAPSHOT: `cosmosapjw-quantum/RABBIT_v1.0.5_PRODUCTION`, branch `f10-independent-validation-b3v2`, HEAD `2d866dfd3b0a09b52f4ef5d4191b7d713e084ed9`
DATE: 2026-08-06

## Internal authoritative sources

| ID | Source | Role in this loop | Audit status |
|---|---|---|---|
| S-I01 | `docs/audit/BD622_D071_trajectory_closure_2026-08-04.md` | Reopen contract; 18 h wall budget; retained T13 failure geometry | DIRECT / AUTHORITATIVE |
| S-I02 | `docs/audit/BD622_V3_report_2026-08-06.md` | Measured Jacobian-factor ratchet, column corruption, Hurwitz creep-state operator, BDF failure loop | DIRECT / AUTHORITATIVE, diagnostic ceiling |
| S-I03 | `scripts/audit/_trajectory_core.py` | Exact state equations, BDF configuration, thermodynamics and comoving-energy diagnostic | DIRECT / SOURCE |
| S-I04 | `src/rabbit/decoupling/_independent_noqke.py` | Independent collision operator, variables, positivity transform and finite-domain handling | DIRECT / SOURCE |
| S-I05 | `src/rabbit/debug/micromacro_probe.py` | Existing micro–macro prototype; novelty exclusion | DIRECT / SOURCE |
| S-I06 | `src/rabbit/debug/posbulk_tailsplit_contract.py` | Existing bulk/tail prototype; novelty exclusion | DIRECT / SOURCE |
| S-I07 | `src/rabbit/transport/reduced_modal_bridge.py` | Existing reduced modal bridge; novelty exclusion | DIRECT / SOURCE |
| S-I08 | `src/rabbit/jax/collision_ap_preconditioner_jax.py` | Existing AP/preconditioner prototype; novelty exclusion | DIRECT / SOURCE |
| S-I09 | `scripts/audit/_f10c2_anchors.py` | Frozen 48-node endpoint spectrum used in the compression probe | DIRECT / FROZEN DATA |
| S-I10 | `docs/superpowers/specs/2026-08-04-blocker-resolution-brainstorm-design.md` | Prior candidate/objection inventory | CONTEXTUAL; not treated as validation |
| S-I11 | `research_artifacts/sources/retained_external_audit/BD622_F10_external_audit_report.md` (SHA-256 `578bc914d81fcc824002df0a90018c10f2ea4a60d9dcd601dcb0300d50ed62a3`) | Retained D-025–D-029 chronology and operation-level reconstruction of the D-029 three-node MaxEnt failure | DIRECT / RETAINED AUDIT; original D-029 envelopes unavailable |

## External primary literature

| ID | Reference | Direct relevance | Claim limit |
|---|---|---|---|
| S-E01 | J. Birrell, J. Wilkening, J. Rafelski, *Boltzmann Equation Solver Adapted to Emergent Chemical Non-equilibrium*, JCP 281 (2015) 896–916, arXiv:1403.2019, DOI 10.1016/j.jcp.2014.10.056 | Dynamically adapted orthogonal-polynomial basis with effective temperature and fugacity; lowest mode captures number and energy | Model demonstration, not a certificate for the RABBIT collision system |
| S-E02 | J. Birrell, C.-T. Yang, J. Rafelski, *Relic Neutrino Freeze-out: Dependence on Natural Constants*, arXiv:1406.1759 | Spectral neutrino freeze-out solver and smooth collision-integral evaluation | Different code and scientific target |
| S-E03 | J. R. Bond et al., *Cosmic Neutrino Decoupling and its Observable Imprints: Insights from Entropic-Dual Transport*, arXiv:2403.19038 | Three parameters per species accurately describe Standard-Model spectra | Empirical representation result; not a trajectory error bound |
| S-E04 | M. Escudero et al., *Fast and Flexible Neutrino Decoupling Part I: The Standard Model*, arXiv:2511.04747 | Momentum-averaged effective-chemical-potential model differs by <0.04% in integrated observables | Accuracy level is not automatically sufficient for the F10 gate |
| S-E05 | J. Froustey, C. Pitrou, M. C. Volpe, arXiv:2008.01074 | Direct Jacobian plus averaged oscillations can yield ~100× speedup | Solver/physics approximation precedent; D-071 disallows it as a stand-alone repair |
| S-E06 | J. J. Bennett et al., arXiv:2012.02726 | Momentum-resolution convergence and numerical uncertainty near 1e-4 in N_eff | External precision target, not a proof for this implementation |
| S-E07 | F. Filbet, S. Jin, arXiv:0905.1378 | BGK-penalized asymptotic-preserving treatment of stiff Boltzmann collisions | Classical Boltzmann setting; requires a project-specific quantum/expanding adaptation |
| S-E08 | I. M. Gamba, S. Jin, L. Liu, arXiv:1809.00028 | Micro–macro AP schemes with exact numerical moment conservation | Strong structural precedent; not directly specialized to cosmological Fermi transport |
| S-E09 | L. Einkemmer, J. Hu, S. Zhang, arXiv:2502.08951 | AP dynamical low-rank treatment of stiff nonlinear Boltzmann equations | Low-rank advantage relies on physical-space/velocity separation absent in this homogeneous 1D momentum problem |
| S-E10 | K. Veroy, A. T. Patera, DOI 10.1002/fld.867 | Rigorous reduced-basis a posteriori bounds for nonlinear outputs | Framework precedent; assumptions must be rebuilt for this ODE/collision system |
| S-E11 | C. Canuto, T. Tonn, K. Urban, DOI 10.1137/080724812 | A posteriori RB analysis for nonaffine nonlinear problems | Framework precedent |
| S-E12 | M. Drohmann, B. Haasdonk, M. Ohlberger, DOI 10.1137/10081157X | Nonlinear evolution RB plus empirical operator interpolation and a posteriori estimation | Hyper-reduction precedent; no automatic positivity/conservation |
| S-E13 | *Goal-oriented model reduction for parametrized time-dependent nonlinear PDEs*, DOI 10.1016/j.cma.2021.114206 | DWR-based output control with hyper-reduction; reports large speedups in another domain | Transfer of method, not of numerical guarantees |

## Search termination

Broad searches covered neutrino spectral/moment reductions, stiff kinetic AP methods, micro–macro conservation, low-rank kinetic solvers, and certified goal-oriented reduced models. Targeted follow-up was used only for the three-parameter neutrino representation, the 2025 momentum-averaged model, and nonlinear output certification. Additional sources repeating those conclusions were not collected because they would not change a candidate decision. A retained historical audit was materialized specifically to resolve the D-029 novelty boundary; its underlying four raw D-029 envelopes remain an explicit evidence gap.
