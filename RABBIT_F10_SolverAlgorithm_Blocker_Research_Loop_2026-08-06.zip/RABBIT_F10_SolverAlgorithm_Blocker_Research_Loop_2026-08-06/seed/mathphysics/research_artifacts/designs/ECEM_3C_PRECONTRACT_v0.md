# ECEM-3C Prospective Discriminator Pre-Contract v0

STATUS: DRAFT FOR FUTURE SEALING. This document was produced after exploratory probe output and therefore is **not** itself the D-071 prospective contract.

Before any Gate-E output, copy this specification to a new immutable decision artifact and replace every `TO_BE_PINNED` entry with a digest or exact threshold. No threshold may be changed after the first output byte.

## Frozen candidate

- State: six moments plus `W`.
- Shape statistic: `phi(y)=y/(1+y)`.
- Entropic reconstruction: natural form `logit f=alpha+lambda1*y+eta*phi`, `lambda1<0` (equivalently `beta=-lambda1>0`).
- Species: `e` and exact `x=mu=tau`.
- Plasma temperature: algebraic EOS inversion.
- Time: postprocessed.
- Collision moment evaluation: exact frozen operator for the first discriminator.
- Method-internal conservative correction: `TO_BE_PINNED` (choose either the discrete-equivalent residual lane or the prospectively defined correction lane before output; no post-hoc projection or lane switching).
- Tail cutoff and envelopes: `Y=30`, reaction constants `TO_BE_PINNED`.
- Metric and scaling: `TO_BE_PINNED` from a no-output analytic construction.

## Predeclared runtime criteria

- frozen wall budget: 64,800 s;
- collision-map 95% call ceiling: 4.5 s;
- full-trajectory call-count upper bound: 5,500;
- safety factor: 2.5;
- creep window: `0.14<=N<=0.22`;
- no threshold adjustment after output.

## Scientific/error criteria

For every fold-level observable `J`, require the certified error bound to be no more than one quarter of its available gate slack. For the 20% improvement predicate, propagate both model errors and require the certified lower bound of improvement to exceed 0.20.

## Mandatory kill conditions

- nonunique EOS inversion;
- nonrealizable moment state;
- positive/unbounded projected entropy logarithmic norm in the creep window;
- missing reaction-tail envelope;
- projected runtime above budget;
- any post-output contract edit;
- any use of test-fold data to define the manifold, metric, threshold or hyper-reduction.
