# RABBIT F10 수학·물리 blocker 해소 연구 루프 요약

- 날짜: 2026-08-06
- 대상: `G-F10-INDEPENDENT-FLRW`의 D-071 이후 수학·물리적 reopening 가능성
- 모드: 연구 전용, 원 저장소 수정 없음, gate 이동 없음, full trajectory 실행 없음
- 사용 하네스: PHYS–MATH RESEARCH HARNESS 5.6

## 1. 결론

이번 루프는 현재 blocker를 해소한 새 solver를 만들지 않았다. 대신 D-071의 “기존 구현을 더 빠르게 하는 것”과 구별되는 하나의 연구 후보를 남겼고, 여러 매력적이지만 불충분한 우회로를 반례와 수치검산으로 제거했다.

생존 후보는 **ECEM-3C**다.

> Energy-Constrained Entropic-Manifold Reduction with Three-Channel Certification

핵심 상태는

\[
X=(m_{e,0},m_{e,1},m_{e,2},m_{x,0},m_{x,1},m_{x,2},W)\in\mathbb R^7
\]

이며, 여기서 `x`는 정확히 퇴화한 `mu–tau` sector, `W`는 총 comoving energy다. 후보의 본질은 다음 다섯 요소의 결합이다.

1. 총에너지 제약을 이용한 `T_gamma` 교환방정식의 구조적 재정식화
2. 전역적으로 고정된 3-moment Fermi entropic manifold
3. 기존 discrete collision action의 first-law residual을 숨기지 않는 보존 accounting
4. entropy Hessian norm에서의 micro invariance-defect/tube 제어
5. direct-output, missing-collision-source, propagated-feedback를 분리한 꼬리오차와 goal-oriented output 인증

현재 판정은 **`REOPEN_VALIDATION`**이다. 이는 후보가 검증 루프로 들어갈 가치가 있다는 뜻이지, D-071 reopen 또는 `PROMOTE`가 성립했다는 뜻이 아니다.

## 2. 출발점이 된 blocker 구조

### 2.1 현재 instrument의 실패

- order-60, `y_max=30` T13 경로는 frozen 18 h budget 안에서 scientific predicate에 도달하지 못했다.
- V3는 persistent finite-difference `jac_factor` ratchet, 일부 Jacobian 열의 오염, Newton 실패, BDF order-1 reset loop를 계측했다.
- 그러나 completing 48/24 경로에도 ratchet이 존재하므로 ratchet의 존재 자체는 충분한 discriminator가 아니다.
- 현재 실패는 physical proposition의 반증이 아니라 해당 validation instrument의 실패다.

### 2.2 D-071의 reopening 조건

새 경로는 다음을 모두 만족해야 한다.

1. 기존 구현의 단순 가속이 아닌 materially new method
2. output 전에 봉인된 contract
3. stalled phase를 포함하며 frozen wall budget 내 full completion을 margin과 함께 예측하는 bounded discriminator

따라서 direct Jacobian, Jacobian cap/reset, 다른 stiff integrator, 더 많은 core 또는 긴 wall time은 보조수단이 될 수는 있어도 reopening 논거가 될 수 없다.

## 3. 수학적 구조

### 3.1 정확한 총 comoving energy 식

`N=ln a`에서

\[
W=e^{4N}(\rho_\nu+\rho_{\rm EM})
\]

를 정의한다. 질량 없는 중성미자에 대해 `P_nu=rho_nu/3`이므로 총 에너지 보존식은

\[
\boxed{W'=e^{4N}(\rho_{\rm EM}-3P_{\rm EM})}
\]

로 정리된다. 중성미자–전자기 sector의 exchange 항은 연속식에서 정확히 소거된다. `T_gamma`는

\[
\rho_{\rm EM}(T_\gamma)=e^{-4N}W-\rho_\nu[f]
\]

에서 대수적으로 복원하며,

\[
\frac{\partial T_\gamma}{\partial W}
=\frac{e^{-4N}}{\rho'_{\rm EM}},\qquad
\frac{\partial T_\gamma}{\partial f_j}
=-\frac{\partial\rho_\nu/\partial f_j}{\rho'_{\rm EM}}
\]

이다.

차원은 `[W]=MeV^4`, `[partial T/partial W]=MeV^{-3}`다. 단, 현재 discrete collision action의 finite first-law residual이 있으므로 실제 후보에서는

\[
W'=e^{4N}(\rho_{\rm EM}-3P_{\rm EM})+e^{4N}R_E
\]

로 residual을 명시적으로 유지하거나, output 전에 수식과 연산 그래프가 고정된 method-internal conservative correction을 별도 오차예산으로 인증해야 한다. 결과를 본 뒤 붙이는 post-hoc projection은 제외한다.

### 3.2 전역 3-moment entropic manifold

각 독립 종 `a=e,x`에 대해

\[
m_{a,j}=\int_0^\infty y^2\psi_j(y)f_a(y)\,dy,
\qquad \psi=(1,y,\phi),\quad \phi(y)=\frac{y}{1+y}
\]

를 사용한다. 자연매개변수는

\[
f_a(y;\lambda)=\sigma(u_a),\qquad
u_a=\alpha_a+\lambda_{1,a}y+\eta_a\phi(y),\qquad
\lambda_{1,a}<0
\]

이다. `beta=-lambda_1>0`로 써도 되지만, positive Gram 구조는 자연매개변수에서 명확하다.

\[
\frac{\partial m_i}{\partial\lambda_j}
=\int_0^\infty y^2\psi_i\psi_j f(1-f)\,dy.
\]

충분통계가 weighted space에서 선형독립이면 이 행렬은 양의정부호다. `(alpha,beta,eta)` 좌표에서는 beta 열 부호가 뒤집히므로 같은 행렬을 대칭 positive Gram이라고 부르면 안 된다.

### 3.3 micro defect와 비정상 증폭

`f=f_theta+g`로 놓고 tangent/moment projector를 `P_theta`라 하면

\[
\Delta_\theta=(I-P_\theta)Q[f_\theta]
\]

가 manifold invariance defect다. Fermi relative-entropy Hessian norm은

\[
\|g\|_{H_\theta}^2
=\sum_a\int\frac{y^2|g_a|^2}{f_{\theta,a}(1-f_{\theta,a})}\,dy
\]

로 잡는다. 필요한 theorem은 대략

\[
\frac{d}{dN}\|g\|_H
\le-\gamma(N)\|g\|_H+\|\Delta_\theta\|_H+L\|g\|_H^2
\]

형태다. V3의 local eigenvalue가 모두 음수라는 사실만으로 이 bound는 나오지 않는다.

## 4. 연구단계 수치검산

### 4.1 endpoint 압축

frozen 48-node endpoint에서 tail-compatible entropic family를 moment matching했다.

| 종 | 3-parameter energy-weighted L1 | 다음 `k=5` moment 상대오차 | unscaled inverse condition |
|---|---:|---:|---:|
| `nu_e` | `7.63e-4` | `2.62e-4` | `1.35e3` |
| `nu_x` | `2.53e-4` | `8.52e-5` | `1.36e3` |

4–6 parameter로 늘리면 일부 fit error는 감소하지만 condition은 약 `4.1e4`, `1.2e6`, `3.3e7`까지 증가했다. 따라서 3 parameters는 가능한 accuracy/conditioning knee지만, 한 endpoint만으로 trajectory closure를 증명하지 않는다.

### 4.2 `y>30` 꼬리

평형 Fermi tail은

\[
I_k(Y)=\int_Y^\infty\frac{y^k}{e^y+1}dy
\le\Gamma(k+1,Y)
\]

로 bound된다. `Y=30`에서 full FD moment 대비 상대꼬리는

- `k=3`: `4.92e-10`
- `k=8`: `2.05e-6`
- `k=9`: `7.13e-6`
- `k=10`: `2.24e-5`

이다. 따라서 energy density tail이 작다는 사실만으로 collision kernel과 feedback tail을 닫을 수 없다.

### 4.3 Hurwitz 반례

\[
A_M=\begin{pmatrix}-5.75&M\\0&-5.75\end{pmatrix}
\]

은 모든 `M`에서 spectral abscissa가 `-5.75`지만, `M=300`일 때 `0<=t<=3`의 최대 `||exp(A_M t)||_2`가 약 `19.2`다. V3의 음의 고유값은 물리적 선형불안정성을 배제하지만, transient amplification이나 reduction error propagation을 닫지 않는다.

### 4.4 에너지 좌표 toy model

정확한 좌표변환은 고유값을 바꾸지 않는다. 열용량 scaling이 유리한 경우 Euclidean logarithmic norm은 크게 개선될 수 있지만, 다른 scaling에서는 악화된다. 따라서 총에너지 좌표의 장점은 stiffness의 삭제가 아니라 exchange cancellation 제거와 weighted conditioning 개선 가능성이다.

### 4.5 정확한 대칭축약의 한계

order-60 상태는 `3*60+2=182`개다. 정확한 mu–tau 축약과 cosmic-time postprocessing으로 `2*60+1=121`개가 된다. dense finite-difference column arithmetic으로 얻는 최대 gain은 약 `1.5x`에 불과하므로 blocker를 단독으로 닫지 못한다.

## 5. D-029와의 경계

D-029는 각 off-grid target energy에 대해 target-dependent 3-node support를 고르고 local maximum-relative-entropy deposition weight를 계산하는 방법이었다. fixed triple theorem은 sound했지만, support selector tie, exact-node one-hot branch, global continuity, uniform Jacobian, permutation covariance와 full collision ledger가 하나의 theorem으로 닫히지 않아 implementation 전에 폐기됐다.

ECEM-3C는 다음 점에서 다르다.

- collision 한 leg가 아니라 전역 species distribution을 축약한다.
- target-dependent support selector가 없고 fixed analytic basis를 사용한다.
- local deposition weight가 아니라 global realizable state manifold를 정의한다.
- full collision action을 먼저 평가하고 moment output을 취한다.
- total-energy constraint, micro defect, three-channel tail과 output certificate를 함께 요구한다.

하지만 원 D-029 네 개 envelope가 현재 작업공간에 없으므로 이 차이는 최종 novelty proof가 아니다. **Gate A0**에서 원본 operation graph를 대조해야 하고, future implementation이 adaptive support/active-set rescue를 도입하면 D-029의 재포장으로 간주해 후보를 kill해야 한다.

## 6. 제거된 경로

- Jacobian cap/reset 또는 integrator swap 단독 경로
- 에너지 좌표만으로 stiffness가 사라진다는 주장
- `y>30` energy tail만으로 T13을 닫는 경로
- 음의 eigenvalue만으로 contraction을 주장하는 경로
- 정확한 mu–tau/time 축약만으로 runtime gap을 닫는 경로
- published momentum-averaged percent accuracy를 project gate에 직접 이식하는 경로
- late free-streaming stop을 주 해결책으로 쓰는 경로
- homogeneous 1D momentum 문제에서 DLR을 주 reduction으로 쓰는 경로
- DSMC 경로

## 7. 다음 검증 순서

### Gate A0 — 역사적 novelty

D-029 원본 envelopes와 operation graph를 대조한다. fixed global basis, no selector, global inverse-map regularity와 permutation covariance가 필수다.

### Gate A — exactness/conservation

세 V3 creep checkpoint에서 energy-coordinate equivalence, algebraic `T_gamma` uniqueness와 discrete first-law residual을 검사한다.

### Gate B — manifold coverage

retained full trajectory 전체에 대해 realizability, moment error, collision-moment error, Fisher condition과 invariance defect를 측정한다.

### Gate C — entropy-metric stability

macro tangent mode를 제거한 weighted logarithmic norm 또는 Lyapunov inequality가 stalled window에서 실제로 음수인지 검사한다.

### Gate D — three-channel domain bound

각 reaction과 output에 대해 direct, missing collision source, propagated feedback를 별도로 bound한다.

### Gate E — prospectively sealed runtime discriminator

- stalled window 포함: `0.14<=N<=0.22`
- full-cost collision calls upper bound: `<=5500`
- 95-percentile call cost ceiling: `<=4.5 s`, 아니면 product bound를 강화
- `5500*4.5 s=24750 s=6.875 h`
- safety factor `2.5` 적용: `61875 s=17.19 h < 64800 s`

이 수치는 성능 예측의 결과가 아니라 future pass/kill threshold다.

### Gate F — fold-level science

manifold, tail, quadrature와 integration error를 adjoint로 fold statistic에 전파한다. point estimate가 아니라 certified lower bound가 RMSE/MAE와 `>=20%` improvement gate를 통과해야 한다.

## 8. 이번 루프에서 실행하지 않은 것

- complete candidate trajectory
- five-fold scientific evaluation
- source-level real collision invariance-defect probe
- external independent decision
- 원 RABBIT 저장소 수정 또는 gate movement

collision defect probe는 complete local source snapshot이 없고 clone이 DNS 단계에서 실패했으며, prospective collision execution contract도 봉인되지 않아 실행하지 않았다. 이는 scientific negative result가 아니라 missing evidence다.

## 9. 산출물 판정

- 연구 후보: `ECEM-3C`
- 현재 상태: `REOPEN_VALIDATION / HOLD`
- promoted hypothesis: 없음
- D-071 reopen earned: 아니오
- 다음 최소 action: D-029 Gate A0를 닫은 뒤 retained checkpoint의 static Gates A–D만 수행
