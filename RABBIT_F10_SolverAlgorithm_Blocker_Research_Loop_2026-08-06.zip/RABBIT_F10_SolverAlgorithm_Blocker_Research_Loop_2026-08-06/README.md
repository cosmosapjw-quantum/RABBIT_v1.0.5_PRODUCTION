# RABBIT F10 Solver/Algorithm Blocker Research Loop

This repository is a durable standalone research package produced with the phys–math coding harness. It investigates solver, algorithm and programming alternatives for the RABBIT F10 order-60/`y_max=30` independent-trajectory blocker.

## Result

- Formal survivor: **energy-constrained exponential Rosenbrock–Krylov (`EC-EXPRB-K`)**
- Secondary survivor: **energy-constrained derivative-free Picard implicit Euler (`EC-PICARD-IE`)**
- Killed candidates: direct JFNK and two-level MLPC-JFNK
- Claim ceiling: synthetic algorithm evidence only; physical prefix pending; D-071 remains FAIL

Start with [`START_HERE.md`](START_HERE.md).

## Reproduction

```bash
python -m pytest -q
python tools/validate_harness.py
python tools/verify_research_evidence.py
```

The original RABBIT repository was read as a seed but was not modified here.
