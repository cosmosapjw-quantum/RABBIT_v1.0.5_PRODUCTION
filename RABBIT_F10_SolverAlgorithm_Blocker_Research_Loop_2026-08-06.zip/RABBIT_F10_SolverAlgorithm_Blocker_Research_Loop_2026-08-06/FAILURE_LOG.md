# FAILURE_LOG.md

## F-001 — Direct JFNK cancellation failure

DATE: 2026-08-06

ATTEMPT: `EC-D-JFNK`, cancellation scale `1e10`.

RESULT: first fine implicit step fails with `GMRES_FAILED:info=80`; no endpoint.

ROOT_CAUSE_OR_HYPOTHESIS: finite-difference JVP cannot supply a sufficiently accurate linear residual under the cancellation oracle.

WHAT_IT_RULES_OUT: direct first-order black-box JFNK with the frozen perturbation/tolerance configuration.

RETRY_POLICY: no retry under the same contract. AD/complex-step or higher-order implicit families require a new method contract and must also solve the 9,666-call noiseless miss.

## F-002 — MLPC-JFNK failure

DATE: 2026-08-06

ATTEMPT: 48/24 coarse predictor and two-level preconditioner for 60/30 fine JFNK.

RESULT: cancellation lane fails at the first fine solve; noiseless lane uses 7,701 effective calls and misses accuracy.

ROOT_CAUSE_OR_HYPOTHESIS: coarse correction reduces some iteration work but does not remove fine directional-difference noise; first-order time error remains dominant.

WHAT_IT_RULES_OUT: the implemented two-level design as a blocker solution.

RETRY_POLICY: FAS/p-multigrid needs a genuinely different nonlinear smoother or exponential/IMEX fine propagator.

## F-003 — Relaxed JFNK false rescue

DATE: 2026-08-06

ATTEMPT: relaxed Newton/GMRES tolerances on cancellation oracle.

RESULT: reported completion with zero linear iterations; explicit predictor accepted.

ROOT_CAUSE_OR_HYPOTHESIS: convergence criterion exceeds the correction signal/noise floor.

WHAT_IT_RULES_OUT: tolerance relaxation as a scientifically meaningful repair.

RETRY_POLICY: forbidden under current claim.

## F-004 — Raw energy conservation miss

DATE: 2026-08-06

ATTEMPT: unprojected D-JFNK, EXPRB-K, MLPC-JFNK and Picard.

RESULT: energy residuals remain at `~1e-6`, above frozen `1e-10` gate.

ROOT_CAUSE_OR_HYPOTHESIS: time-discretization error in the raw coordinate, not collision physics.

WHAT_IT_RULES_OUT: pure solver swap without a physical total-energy coordinate/conservative formulation.

RETRY_POLICY: physical PR-SA02 is mandatory.

## F-005 — Initial standalone import failure

DATE: 2026-08-06

ATTEMPT: execute prototype without package path configuration.

RESULT: import failure.

ROOT_CAUSE_OR_HYPOTHESIS: editable-build isolation and missing `src` path in standalone scripts.

WHAT_IT_RULES_OUT: none scientifically.

RETRY_POLICY: fixed by `pyproject.toml` test path and explicit script-local `src` insertion; independently revalidated.
