# SCIENTIFIC_CONTRACT.md

## Scientific objective

Determine whether a solver/algorithm/programming replacement can plausibly remove the
`G-F10-INDEPENDENT-FLRW` order-60 / `y_max=30` trajectory-instrument blocker without
changing the frozen no-QKE physics, the endpoint observable, or the D-071 scientific
bands. This workspace is a research prototype and does **not** move the RABBIT gate.

## Governing definitions

- Fine state dimension: `n_f = 3*order_f + 2`; the RABBIT-matched class uses
  `order_f=60`, hence `n_f=182`.
- Coarse state dimension: `n_c = 3*order_c + 2`; the retained predictor class uses
  `order_c=48`, hence `n_c=146`.
- `F_f(t,y)` is the fine black-box RHS; one scalar-state evaluation counts as one
  **full-RHS-equivalent call**.
- `Jv` is a matrix-free directional derivative of `F_f` under a prospectively fixed
  perturbation rule; no persistent per-component ratchet is allowed.
- `P` and `R` are fixed prolongation/restriction maps between the 48/24 and 60/30
  spectral states. Fine nodes outside the coarse domain receive a predeclared analytic
  tail state, never polynomial extrapolation.
- The solver candidates are:
  1. direct Jacobian-free inexact Newton--Krylov implicit stepping (`D-JFNK`),
  2. exponential Rosenbrock--Krylov (`EXPRB-K`),
  3. multilevel prolongation-defect-correction JFNK (`MLPC-JFNK`).
- A safeguarded supplied-Jacobian BDF lane is a diagnostic control only and is not a
  D-071 reopening candidate.

## Conventions

- metric signature: `(-,+,+,+)` where spacetime language is used;
- independent variable: `N = ln a`;
- unit system: MeV natural units inside the RABBIT comparator; synthetic benchmark time
  is dimensionless and is never identified with a physical RABBIT output;
- spectral state: three flavour-pair blocks followed by the electromagnetic/energy
  scalar and a postprocessing clock scalar;
- norm: componentwise weighted RMS with `scale_i = atol_i + rtol*abs(y_i)`;
- full-RHS call accounting counts every perturbed column or JVP evaluation separately,
  even when a vectorized Python call batches them.

## Valid regime

- classical flavour-diagonal no-QKE FLRW comparator;
- zero lepton asymmetry and exact mu--tau symmetry only where the source comparator has it;
- `order_c=48, y_max_c=24`, `order_f=60, y_max_f=30` for the RABBIT-matched discriminator;
- synthetic benchmark dimensions `order in {24,48,60,96}`;
- finite, smooth states with occupations strictly in `(0,1)`;
- no claim for QKE, Bianchi backgrounds, production dispatch, or continuum convergence.

## Required invariants

- dimensions and state layout must be explicit;
- finite values only; NaN/Inf is a hard failure;
- occupation reconstruction remains strictly inside `(0,1)`;
- the manufactured total-energy identity is preserved to `1e-10` relative on the
  noiseless benchmark and `1e-7` on the cancellation oracle;
- fixed transfer maps are deterministic and reproduce constants to `1e-12`;
- all solver failures, rejected steps, linear failures, and line-search failures are
  surfaced rather than silently replaced.

## Known limits

| Limit | Expected result | Tolerance | Reference/test |
|---|---|---:|---|
| autonomous linear model | analytic matrix-exponential solution | `2e-9` reference | `tests/test_models.py` |
| zero nonlinearity | JVP equals analytic `Jv` | `5e-7` relative | `tests/test_jvp.py` |
| identity transfer grid | `R=P=I` | `1e-12` | `tests/test_grids.py` |
| exact manufactured path | RHS equals derivative | `2e-11` weighted RMS | `tests/test_models.py` |
| halved step | D-JFNK first-order trend | observed order `>=0.8` | numerical sweep |
| halved step | EXPRB-K second-order trend | observed order `>=1.6` | numerical sweep |

## Reference cases

- analytic toy: stable nonnormal triangular linear system with exact `expm` solution;
- trusted numerical reference: `solve_ivp(method='Radau', analytic jacobian,
  rtol=1e-11, atol=1e-13)` on the noiseless manufactured fine model;
- measured RABBIT anchors: state dimension 182, creep window near `N=0.163`, true
  spectral abscissa about `-5.75`, and the 64,800 s frozen wall budget;
- prior implementation: SciPy BDF finite-difference Jacobian with persistent
  per-component `jac_factor`.

## Numerical requirements

- candidate endpoint weighted RMS error: `<=2e-5` on the noiseless order-60 benchmark;
- cancellation-oracle endpoint weighted RMS error: `<=2e-4`;
- candidate full-RHS-equivalent calls: `<=5500` for the RABBIT-matched projected run;
- measured benchmark call-count scaling exponent from order 48 to 96: `<=1.35` for a
  surviving matrix-free candidate;
- 95th-percentile measured RABBIT call-cost assumption: `4.5 s`;
- frozen safety factor: `2.5`;
- projected wall bound: `calls * 4.5 s * 2.5 < 64,800 s`;
- deterministic rerun: endpoint and counters exactly equal on the same environment;
- memory ceiling in this workspace: `2 GiB` peak RSS.

## Failure semantics

The following are failures, never success: NaN/Inf, non-convergence, missing endpoint,
unreported fallback, tolerance relaxation, fitted post-output perturbation sizes,
clipped invalid occupations, using the analytic Jacobian in a candidate labelled
matrix-free, or counting a batched `n`-column finite-difference call as one RHS call.

## Change control

No RABBIT convention, scientific baseline, tolerance, approximation order, or output
semantics is changed here. Any future source integration requires a new prospectively
sealed contract and an owner-authorized RABBIT worktree.
