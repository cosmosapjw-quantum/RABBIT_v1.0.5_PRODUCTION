# Scientific Contract Amendment 01 — Conservative-coordinate candidate lanes

**Frozen before the formal sweep.** The exploratory solver runs exposed a design-level fact:
raw fixed-step methods preserve the manufactured total-energy identity only to their time
truncation error, while the pre-existing contract requires `1e-10`. The raw lanes remain
retained as negative controls; their results may not be overwritten.

The formal candidate set therefore adds `EC-` lanes that apply one predeclared scalar
constraint after each accepted step:

`E <- E - [E + w.u - (E0 + integral(trace_source))]`.

The correction changes neither spectral components nor the clock, uses no endpoint fit,
no analytic Jacobian, no tolerance relaxation, and has no conditional branch based on the
observed error. It is exact for the manufactured invariant by construction. On a future
RABBIT worktree, this lane maps to the total-comoving-energy coordinate and algebraic
plasma-temperature recovery; the synthetic exact trace integral is not itself claimed as
physical RABBIT evidence.

Formal candidate names:
- `EC-D-JFNK`
- `EC-EXPRB-K`
- `EC-MLPC-JFNK`

Unprojected `D-JFNK`, `EXPRB-K`, and `MLPC-JFNK` remain reportable negative/control lanes.
All original thresholds, call accounting, scaling, and D-071 boundaries remain unchanged.
