# EC-EXPRB-K physical prefix precontract v0

**Status:** draft for owner review; not an execution grant.

## Method identity

- physical state uses total-comoving-energy coordinate `W`
- nonautonomous time-augmented exponential Krylov action
- baseline Krylov dimension `m=10`
- no full analytic Jacobian and no persistent finite-difference factor
- every directional RHS is charged as a full RHS call

## Required prefix

- order 60, `y_max=30`
- original frozen no-QKE collision catalog and quadrature
- interval must include `0.14≤N≤0.22` and end no earlier than `N=0.25`
- exact start state and all source hashes recorded before output

## Candidate gates

1. finite strict-open occupations at every accepted state
2. total-energy residual inside the inherited physical band
3. no unresolved domain/tail rejection increase
4. no Arnoldi failure or hidden solver fallback
5. call projection for the full target `≤5500` with margin
6. projected wall `<64800 s` using measured p95 call cost and safety factor
7. reproducible endpoint/counters on same environment
8. static/trajectory comparison to frozen anchors inside inherited bands

## Kill semantics

Any cap breach, missing diagnostic, post-output parameter change, failed invariant, or incomplete interval is `KILL`. A KILL is retained and may not be reissued under the same contract.
