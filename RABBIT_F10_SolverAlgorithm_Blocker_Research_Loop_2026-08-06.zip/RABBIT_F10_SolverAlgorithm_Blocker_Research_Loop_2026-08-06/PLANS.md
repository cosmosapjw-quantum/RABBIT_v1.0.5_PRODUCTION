# PLANS.md

## Current task

TASK: Solver/algorithm/programming research loop for the F10 order-60 trajectory blocker.

OUTCOME: Completed standalone prototype, formal/post-formal candidate comparison, bounded discriminator, independent review and future RABBIT PR DAG; no gate movement.

IN_SCOPE: SciPy finite-difference diagnosis control, D-JFNK, EXPRB-K, MLPC-JFNK, derivative-free Picard, manufactured/cancellation benchmarks, numerical/reproducibility validation.

OUT_OF_SCOPE: Original RABBIT edits, QKE, Bianchi, scientific unblinding, full physical trajectory, production dispatch.

## Milestones

| ID | Milestone | Validation | Status |
|---|---|---|---|
| P-001 | Contracts, grids, models | unit tests | COMPLETE |
| P-002 | JVP and SciPy probe | analytic JVP + ratchet probe | COMPLETE |
| P-003 | Direct JFNK | convergence/failure tests | COMPLETE; candidate KILL |
| P-004 | EXPRB-K | convergence/Krylov/cancellation tests | COMPLETE; formal SURVIVOR |
| P-005 | MLPC-JFNK | fine residual/iteration tests | COMPLETE; candidate KILL |
| P-006 | Formal research sweep | frozen gates and v1/v2 adjudication | COMPLETE |
| P-007 | Derivative-free divergent branch | sealed Picard campaign | COMPLETE; post-formal SURVIVOR |
| P-008 | Independent validation | 38 tests, replay, review | COMPLETE |
| P-009 | Durable closeout | reports, figures, hashes, ZIP replay | IN PROGRESS |
| P-010 | Physical RABBIT integration | PR-SA00–SA08 | NOT STARTED; owner authorization required |
