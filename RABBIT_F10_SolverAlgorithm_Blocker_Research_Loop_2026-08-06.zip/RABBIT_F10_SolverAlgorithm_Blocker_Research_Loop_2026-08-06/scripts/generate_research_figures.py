#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
OUT.mkdir(parents=True, exist_ok=True)


def save(fig: plt.Figure, name: str) -> None:
    fig.tight_layout()
    fig.savefig(OUT / name, dpi=180, bbox_inches="tight")
    plt.close(fig)


def formal_data() -> dict:
    return json.loads((ROOT / "results/formal_v2/formal_solver_sweep.json").read_text())


def postformal_data() -> dict:
    return json.loads((ROOT / "results/postformal/postformal_research.json").read_text())


def candidate_rows(formal: dict, post: dict) -> list[dict]:
    rows = [dict(row) for row in formal["decisions"]]
    rows.append(dict(post["picard"]["decision"]))
    return rows


def plot_candidate_rhs_calls(rows: list[dict]) -> None:
    names = [r["name"] for r in rows]
    calls = [r["metrics"]["rhs_calls"] for r in rows]
    budget = rows[0]["thresholds"]["rhs_call_budget"]
    fig, ax = plt.subplots(figsize=(9.0, 5.5))
    ax.barh(names, calls)
    ax.axvline(budget, linestyle="--", label=f"frozen budget = {budget}")
    ax.set_xlabel("Full-RHS-equivalent calls")
    ax.set_title("Candidate call budget on the frozen synthetic discriminator")
    ax.legend()
    ax.grid(axis="x", alpha=0.25)
    save(fig, "candidate_rhs_calls.png")


def plot_candidate_errors(rows: list[dict]) -> None:
    names = [r["name"] for r in rows]
    x = np.arange(len(names), dtype=float)
    noiseless = [r["metrics"]["endpoint_wrms"] for r in rows]
    cancellation = [r["metrics"]["cancellation_endpoint_wrms"] for r in rows]
    threshold_n = rows[0]["thresholds"]["noiseless_endpoint_wrms"]
    threshold_c = rows[0]["thresholds"]["cancellation_endpoint_wrms"]
    finite_n = np.array([v if np.isfinite(v) else np.nan for v in noiseless])
    finite_c = np.array([v if np.isfinite(v) else np.nan for v in cancellation])
    fig, ax = plt.subplots(figsize=(10.5, 5.7))
    ax.semilogy(x, finite_n, marker="o", label="noiseless endpoint WRMS")
    ax.semilogy(x, finite_c, marker="s", label="cancellation endpoint WRMS")
    ax.axhline(threshold_n, linestyle="--", label=f"noiseless band = {threshold_n:g}")
    ax.axhline(threshold_c, linestyle=":", label=f"cancellation band = {threshold_c:g}")
    ax.set_xticks(x, names, rotation=35, ha="right")
    ax.set_ylabel("Absolute component WRMS")
    ax.set_title("Accuracy gates; missing points are failed integrations")
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.25)
    save(fig, "candidate_endpoint_errors.png")


def plot_exprb_step_convergence(post: dict) -> None:
    rows = post["exprb"]["step_convergence"]
    h = np.array([r["step_size"] for r in rows])
    err = np.array([r["endpoint_wrms"] for r in rows])
    reference = err[-1] * (h / h[-1]) ** 2
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    ax.loglog(h, err, marker="o", label="measured")
    ax.loglog(h, reference, linestyle="--", label="second-order reference")
    ax.set_xlabel("Fixed step h")
    ax.set_ylabel("Endpoint WRMS")
    ax.set_title("EC-EXPRB-K step-convergence ladder")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    save(fig, "exprb_step_convergence.png")


def plot_exprb_krylov_saturation(post: dict) -> None:
    rows = post["exprb"]["krylov_saturation"]
    m = np.array([r["krylov_dim"] for r in rows])
    err = np.array([r["endpoint_wrms"] for r in rows])
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    ax.semilogy(m, err, marker="o")
    ax.set_xlabel("Krylov dimension m")
    ax.set_ylabel("Endpoint WRMS")
    ax.set_title("EXPRB-K accuracy saturates by m≈4–6")
    ax.grid(True, which="both", alpha=0.25)
    save(fig, "exprb_krylov_saturation.png")


def plot_exprb_krylov_calls(post: dict) -> None:
    rows = post["exprb"]["krylov_saturation"]
    m = np.array([r["krylov_dim"] for r in rows])
    calls = np.array([r["rhs_calls"] for r in rows])
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    ax.plot(m, calls, marker="o")
    ax.set_xlabel("Krylov dimension m")
    ax.set_ylabel("Full-RHS-equivalent calls")
    ax.set_title("EXPRB-K call cost grows linearly with Krylov dimension")
    ax.grid(True, alpha=0.25)
    save(fig, "exprb_krylov_calls.png")


def plot_exprb_cancellation(post: dict) -> None:
    rows = post["exprb"]["cancellation_scale_ladder"]
    scale = np.array([max(r["cancellation_scale"], 1.0) for r in rows])
    err = np.array([r["endpoint_wrms"] for r in rows])
    threshold = 2.0e-4
    fig, ax = plt.subplots(figsize=(7.7, 5.2))
    ax.loglog(scale, err, marker="o")
    ax.axhline(threshold, linestyle="--", label=f"cancellation band = {threshold:g}")
    ax.set_xlabel("Cancellation baseline scale (0 plotted at 1)")
    ax.set_ylabel("Endpoint WRMS")
    ax.set_title("EC-EXPRB-K cancellation robustness and breakdown scale")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    save(fig, "exprb_cancellation_robustness.png")


def plot_exprb_resolution(post: dict) -> None:
    rows = post["exprb"]["resolution_sweep_m4"]
    size = np.array([r["state_size"] for r in rows])
    calls = np.array([r["rhs_calls"] for r in rows])
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    ax.plot(size, calls, marker="o")
    ax.set_xlabel("State dimension")
    ax.set_ylabel("Full-RHS-equivalent calls")
    ax.set_title("Fixed-m EXPRB-K call count is dimension-independent in the synthetic sweep")
    ax.grid(True, alpha=0.25)
    save(fig, "exprb_resolution_call_scaling.png")


def plot_ratchet(post: dict) -> None:
    rows = post["ratchet_scale_ladder"]
    scale = np.array([r["cancellation_scale"] for r in rows])
    factor = np.array([r["persistent_final"]["max_factor_over_sqrt_eps"] for r in rows])
    error = np.array([r["persistent_final"]["max_column_relative_error"] for r in rows])
    fig, ax = plt.subplots(figsize=(7.5, 5.2))
    ax.loglog(scale, factor, marker="o", label="max persistent factor / sqrt(eps)")
    ax.loglog(scale, error, marker="s", label="max Jacobian-column relative error")
    ax.set_xlabel("Cancellation baseline scale")
    ax.set_ylabel("Dimensionless magnitude")
    ax.set_title("Persistent SciPy finite-difference factor and column corruption")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    save(fig, "scipy_num_jac_ratchet.png")


def main() -> int:
    formal = formal_data()
    post = postformal_data()
    rows = candidate_rows(formal, post)
    plot_candidate_rhs_calls(rows)
    plot_candidate_errors(rows)
    plot_exprb_step_convergence(post)
    plot_exprb_krylov_saturation(post)
    plot_exprb_krylov_calls(post)
    plot_exprb_cancellation(post)
    plot_exprb_resolution(post)
    plot_ratchet(post)
    print(f"wrote {len(list(OUT.glob('*.png')))} figures to {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
