#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from scripts import run_solver_algorithm_loop as formal  # noqa: E402
from f10_solver_research.adjudication import CandidateMetrics, adjudicate_candidate  # noqa: E402
from f10_solver_research.contracts import CallCounter  # noqa: E402
from f10_solver_research.scipy_probe import run_num_jac_refresh_probe  # noqa: E402
from f10_solver_research.solvers.exprb import solve_exprb_krylov  # noqa: E402
from f10_solver_research.solvers.jfnk import solve_implicit_euler_jfnk  # noqa: E402
from f10_solver_research.solvers.picard import solve_implicit_euler_picard  # noqa: E402


PICARD_CONFIG = {
    "step_size": 4.0e-4,
    "fixed_point_tolerance": 1.0e-8,
    "max_iterations": 4,
}


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _run_picard(order: int, y_max: float, t_end: float, scale: float, conservative: bool):
    model = formal._build_model(order, y_max, scale)
    projector = model.project_energy_identity if conservative else None
    with formal._peak_rss_monitor() as memory:
        result = solve_implicit_euler_picard(
            model.rhs,
            (0.0, t_end),
            model.exact_state(0.0),
            step_size=PICARD_CONFIG["step_size"],
            fixed_point_tolerance=PICARD_CONFIG["fixed_point_tolerance"],
            max_iterations=PICARD_CONFIG["max_iterations"],
            state_projector=projector,
        )
    lane = (
        ("EC-PICARD-IE" if conservative else "RAW-PICARD-IE")
        + (":cancellation" if scale else ":noiseless")
        + f":o{order}"
    )
    return (
        formal._result_summary(
            lane=lane,
            model=model,
            result=result,
            t_end=t_end,
            peak_rss_bytes=memory["peak"],
        ),
        result.endpoint.copy(),
    )


def _picard_campaign(out: Path) -> dict[str, Any]:
    primary, endpoint = _run_picard(60, 30.0, 0.8, 0.0, True)
    repeat, endpoint_repeat = _run_picard(60, 30.0, 0.8, 0.0, True)
    cancellation, endpoint_cancellation = _run_picard(60, 30.0, 0.8, 1e10, True)
    low, _ = _run_picard(48, 24.0, 0.4, 0.0, True)
    high, _ = _run_picard(96, 48.0, 0.4, 0.0, True)
    raw, endpoint_raw = _run_picard(60, 30.0, 0.8, 0.0, False)
    raw_cancellation, endpoint_raw_c = _run_picard(60, 30.0, 0.8, 1e10, False)
    deterministic = bool(
        np.array_equal(endpoint, endpoint_repeat)
        and primary["rhs_calls"] == repeat["rhs_calls"]
        and primary["steps"] == repeat["steps"]
        and primary["stats_extra"]["fixed_point_iterations"]
        == repeat["stats_extra"]["fixed_point_iterations"]
    )
    exponent = formal._scaling_exponent(
        low["effective_rhs_calls"], high["effective_rhs_calls"]
    )
    metrics = CandidateMetrics(
        name="EC-PICARD-IE",
        success=bool(primary["success"] and cancellation["success"]),
        finite=bool(primary["finite"] and cancellation["finite"]),
        occupations_valid=bool(
            primary["occupations_valid"] and cancellation["occupations_valid"]
        ),
        matrix_free=True,
        control_only=False,
        endpoint_wrms=float(primary["endpoint_wrms"]),
        cancellation_endpoint_wrms=float(cancellation["endpoint_wrms"]),
        energy_residual=float(primary["energy_residual_max"]),
        cancellation_energy_residual=float(cancellation["energy_residual_max"]),
        rhs_calls=float(max(primary["rhs_calls"], cancellation["rhs_calls"])),
        scaling_exponent=float(exponent),
        deterministic=deterministic,
        peak_rss_bytes=int(
            max(
                primary["peak_rss_bytes"],
                repeat["peak_rss_bytes"],
                cancellation["peak_rss_bytes"],
                low["peak_rss_bytes"],
                high["peak_rss_bytes"],
            )
        ),
    )
    decision = adjudicate_candidate(metrics).to_dict()
    decision["claim_ceiling"] = "POSTFORMAL_SYNTHETIC_SURVIVOR_NOT_D071_REOPEN"
    decision["raw_energy_negative_control"] = {
        "noiseless": raw["energy_residual_max"],
        "cancellation": raw_cancellation["energy_residual_max"],
    }
    endpoint_dir = out / "endpoints"
    endpoint_dir.mkdir(parents=True, exist_ok=True)
    for name, values in {
        "EC-PICARD-IE-primary": endpoint,
        "EC-PICARD-IE-repeat": endpoint_repeat,
        "EC-PICARD-IE-cancellation": endpoint_cancellation,
        "RAW-PICARD-IE-primary": endpoint_raw,
        "RAW-PICARD-IE-cancellation": endpoint_raw_c,
    }.items():
        np.savez_compressed(endpoint_dir / f"{name}.npz", endpoint=values)
    return {
        "config": PICARD_CONFIG,
        "runs": [primary, repeat, cancellation, low, high, raw, raw_cancellation],
        "decision": decision,
    }


def _exprb_sweeps() -> dict[str, Any]:
    model = formal._build_model(60, 30.0, 0.0)
    initial = model.exact_state(0.0)
    step_rows: list[dict[str, Any]] = []
    previous_error: float | None = None
    for h in (0.1, 0.05, 0.025, 0.0125, 0.00625):
        result = solve_exprb_krylov(
            model.rhs_true,
            (0.0, 0.8),
            initial,
            step_size=h,
            krylov_dim=10,
            jvp_relative_step=1e-3,
            state_projector=model.project_energy_identity,
        )
        error = formal._wrms(result.endpoint - model.exact_state(0.8))
        row = {
            "step_size": h,
            "endpoint_wrms": error,
            "rhs_calls": result.stats.rhs_calls,
            "max_projected_ie_defect": max(result.stats.extra["projected_ie_defects"]),
            "observed_order_from_previous": (
                math.log(previous_error / error, 2.0)
                if previous_error is not None
                else None
            ),
        }
        step_rows.append(row)
        previous_error = error

    krylov_rows = []
    for dimension in (2, 3, 4, 5, 6, 8, 10, 12, 16, 24):
        result = solve_exprb_krylov(
            model.rhs_true,
            (0.0, 0.8),
            initial,
            step_size=0.025,
            krylov_dim=dimension,
            jvp_relative_step=1e-3,
            state_projector=model.project_energy_identity,
        )
        krylov_rows.append(
            {
                "krylov_dim": dimension,
                "endpoint_wrms": formal._wrms(
                    result.endpoint - model.exact_state(0.8)
                ),
                "rhs_calls": result.stats.rhs_calls,
                "breakdowns": result.stats.extra["arnoldi_breakdowns"],
            }
        )

    epsilon_rows = []
    for epsilon in (
        1e-7,
        3e-7,
        1e-6,
        3e-6,
        1e-5,
        3e-5,
        1e-4,
        3e-4,
        1e-3,
        3e-3,
        1e-2,
        3e-2,
    ):
        cancellation_model = formal._build_model(60, 30.0, 1e10)
        result = solve_exprb_krylov(
            cancellation_model.rhs,
            (0.0, 0.8),
            cancellation_model.exact_state(0.0),
            step_size=0.025,
            krylov_dim=10,
            jvp_relative_step=epsilon,
            state_projector=cancellation_model.project_energy_identity,
        )
        epsilon_rows.append(
            {
                "jvp_relative_step": epsilon,
                "success": result.success,
                "endpoint_wrms": formal._wrms(
                    result.endpoint - cancellation_model.exact_state(0.8)
                )
                if result.success
                else math.inf,
                "rhs_calls": result.stats.rhs_calls,
                "max_arnoldi_dimension": max(
                    result.stats.extra["arnoldi_dimensions"], default=0
                ),
            }
        )

    cancellation_rows = []
    for scale in (0.0, 1e6, 1e8, 1e9, 1e10, 3e10, 1e11, 3e11, 1e12, 3e12, 1e13):
        cancellation_model = formal._build_model(60, 30.0, scale)
        result = solve_exprb_krylov(
            cancellation_model.rhs,
            (0.0, 0.8),
            cancellation_model.exact_state(0.0),
            step_size=0.025,
            krylov_dim=10,
            jvp_relative_step=1e-3,
            state_projector=cancellation_model.project_energy_identity,
        )
        cancellation_rows.append(
            {
                "cancellation_scale": scale,
                "success": result.success,
                "endpoint_wrms": formal._wrms(
                    result.endpoint - cancellation_model.exact_state(0.8)
                )
                if result.success
                else math.inf,
                "rhs_calls": result.stats.rhs_calls,
            }
        )

    resolution_rows = []
    for order in (24, 48, 60, 72, 96):
        resolution_model = formal._build_model(order, order / 2.0, 0.0)
        with formal._peak_rss_monitor() as memory:
            result = solve_exprb_krylov(
                resolution_model.rhs_true,
                (0.0, 0.8),
                resolution_model.exact_state(0.0),
                step_size=0.025,
                krylov_dim=4,
                jvp_relative_step=1e-3,
                state_projector=resolution_model.project_energy_identity,
            )
        resolution_rows.append(
            {
                "order": order,
                "state_size": resolution_model.state_size,
                "endpoint_wrms": formal._wrms(
                    result.endpoint - resolution_model.exact_state(0.8)
                ),
                "rhs_calls": result.stats.rhs_calls,
                "wall_seconds": result.stats.wall_seconds,
                "peak_rss_bytes": memory["peak"],
            }
        )

    return {
        "step_convergence": step_rows,
        "krylov_saturation": krylov_rows,
        "jvp_step_robustness_at_scale_1e10": epsilon_rows,
        "cancellation_scale_ladder": cancellation_rows,
        "resolution_sweep_m4": resolution_rows,
    }


def _ratchet_scale_ladder() -> list[dict[str, Any]]:
    rows = []
    for scale in (1e6, 1e8, 1e10):
        model = formal._build_model(60, 30.0, scale)
        state = model.exact_state(0.163)
        threshold = np.full(model.state_size, 1e-9)
        per = CallCounter()
        rst = CallCounter()
        persistent = run_num_jac_refresh_probe(
            fun=per.wrap(model.rhs),
            analytic_jacobian=model.jacobian,
            t=0.163,
            y=state,
            threshold=threshold,
            refreshes=12,
            persistent_factor=True,
        )
        reset = run_num_jac_refresh_probe(
            fun=rst.wrap(model.rhs),
            analytic_jacobian=model.jacobian,
            t=0.163,
            y=state,
            threshold=threshold,
            refreshes=12,
            persistent_factor=False,
        )
        rows.append(
            {
                "cancellation_scale": scale,
                "persistent_final": asdict(persistent.records[-1]),
                "reset_final": asdict(reset.records[-1]),
                "persistent_rhs_calls": per.calls,
                "reset_rhs_calls": rst.calls,
            }
        )
    return rows


def _jfnk_noise_floor_screen() -> dict[str, Any]:
    model = formal._build_model(60, 30.0, 1e10)
    strict = solve_implicit_euler_jfnk(
        model.rhs,
        (0.0, 0.02),
        model.exact_state(0.0),
        step_size=5e-4,
        newton_rtol=2e-9,
        newton_atol=1e-12,
        gmres_rtol=1e-7,
        max_linear_iterations=80,
        jvp_relative_step=1e-3,
        state_projector=model.project_energy_identity,
    )
    relaxed = solve_implicit_euler_jfnk(
        model.rhs,
        (0.0, 0.02),
        model.exact_state(0.0),
        step_size=5e-4,
        newton_rtol=1e-6,
        newton_atol=1e-10,
        gmres_rtol=1e-3,
        max_linear_iterations=40,
        jvp_relative_step=1e-3,
        state_projector=model.project_energy_identity,
    )
    return {
        "strict": {
            "success": strict.success,
            "reason": strict.reason,
            "steps": strict.stats.steps,
            "rhs_calls": strict.stats.rhs_calls,
            "linear_iterations": strict.stats.linear_iterations,
        },
        "relaxed": {
            "success": relaxed.success,
            "reason": relaxed.reason,
            "steps": relaxed.stats.steps,
            "rhs_calls": relaxed.stats.rhs_calls,
            "linear_iterations": relaxed.stats.linear_iterations,
            "interpretation": (
                "zero linear iterations means the relaxed lane accepted the explicit "
                "predictor; this is not a repaired JFNK solve"
            ),
        },
    }


def _candidate_inventory() -> list[dict[str, str]]:
    return [
        {"family": "EC-EXPRB-K", "state": "FORMAL_SURVIVOR", "reason": "all frozen gates pass"},
        {"family": "EC-PICARD-IE", "state": "POSTFORMAL_SURVIVOR", "reason": "all frozen gates pass but margins are thin"},
        {"family": "EC-D-JFNK", "state": "KILL", "reason": "cancellation JVP prevents GMRES convergence; calls and error also miss"},
        {"family": "EC-MLPC-JFNK", "state": "KILL", "reason": "coarse preconditioner does not cure fine JVP noise; first-order cost misses"},
        {"family": "Supplied-Jacobian Radau/BDF", "state": "CONTROL_ONLY", "reason": "excellent synthetic performance but D-071 scope and independence not met"},
        {"family": "LSODA", "state": "CONTROL_ONLY", "reason": "excellent synthetic control; physical full-collision discriminator still absent"},
        {"family": "jac_factor reset/cap", "state": "CONTROL_ONLY", "reason": "instrument repair, explicitly insufficient under D-071"},
        {"family": "analytic full Jacobian", "state": "CONTROL_ONLY", "reason": "instrument tuning and expensive physical derivation"},
        {"family": "noise-aware relaxed JFNK", "state": "KILL", "reason": "relaxed test degenerates to explicit-predictor acceptance"},
        {"family": "Anderson-accelerated Picard", "state": "DEFER", "reason": "plain map converges in two calls; added state has no measured benefit"},
        {"family": "limited-memory Broyden", "state": "DEFER", "reason": "secant history may inherit cancellation noise; no need after derivative-free survivor"},
        {"family": "RKC/Chebyshev stabilized explicit", "state": "PROPOSED", "reason": "real-negative spectral block makes it plausible; not prototyped here"},
        {"family": "IMEX collision split", "state": "PROPOSED", "reason": "requires a prospectively fixed physical split and commutator error bound"},
        {"family": "Rosenbrock-Krylov with recycled basis", "state": "PROPOSED", "reason": "could reduce EXPRB calls below m=4 but needs a residual-based recycle gate"},
        {"family": "FAS/p-multigrid nonlinear solve", "state": "REWORK", "reason": "two-level prototype reduces iterations but first-order accuracy and fine JVP noise dominate"},
        {"family": "GPU/vectorized dense FD", "state": "KILL_AS_REOPEN_ROUTE", "reason": "changes wall per call, not the 8300x evaluation-count pathology"},
        {"family": "larger wall budget/hardware", "state": "KILL_AS_REOPEN_ROUTE", "reason": "explicitly excluded by D-071"},
    ]


def _write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    out = ROOT / "results" / "postformal"
    out.mkdir(parents=True, exist_ok=True)
    protocol = {
        "postformal_protocol_sha256": hashlib.sha256(
            (ROOT / "POSTFORMAL_PROTOCOL_01.md").read_bytes()
        ).hexdigest(),
        "formal_v2_sha256": hashlib.sha256(
            (ROOT / "results/formal_v2/formal_solver_sweep.json").read_bytes()
        ).hexdigest(),
        "picard_config": PICARD_CONFIG,
    }
    picard = _picard_campaign(out)
    exprb = _exprb_sweeps()
    ratchet = _ratchet_scale_ladder()
    jfnk_screen = _jfnk_noise_floor_screen()
    inventory = _candidate_inventory()
    payload = {
        "protocol": protocol,
        "picard": picard,
        "exprb": exprb,
        "ratchet_scale_ladder": ratchet,
        "jfnk_noise_floor_screen": jfnk_screen,
        "candidate_inventory": inventory,
    }
    _write_json(out / "postformal_research.json", payload)
    _write_json(out / "picard_decision.json", picard["decision"])
    _write_json(out / "candidate_inventory.json", inventory)
    for name, rows in exprb.items():
        _write_rows(out / f"exprb_{name}.csv", rows)
    _write_rows(out / "ratchet_scale_ladder.csv", ratchet)
    print(json.dumps({"picard": (picard["decision"]["name"], picard["decision"]["status"])}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
