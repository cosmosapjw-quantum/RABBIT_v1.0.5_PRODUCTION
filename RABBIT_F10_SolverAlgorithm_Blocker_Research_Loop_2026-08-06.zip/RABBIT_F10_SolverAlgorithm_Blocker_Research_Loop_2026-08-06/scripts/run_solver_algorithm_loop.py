#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from f10_solver_research.adjudication import (  # noqa: E402
    CandidateMetrics,
    adjudicate_candidate,
)
from f10_solver_research.contracts import CallCounter, SolverResult  # noqa: E402
from f10_solver_research.grids import Grid, build_transfer_pair  # noqa: E402
from f10_solver_research.models import ManufacturedKineticModel  # noqa: E402
from f10_solver_research.scipy_probe import run_num_jac_refresh_probe  # noqa: E402
from f10_solver_research.solvers.exprb import solve_exprb_krylov  # noqa: E402
from f10_solver_research.solvers.jfnk import solve_implicit_euler_jfnk  # noqa: E402
from f10_solver_research.solvers.multilevel import solve_mlpc_jfnk  # noqa: E402


FORMAL_CONFIG: dict[str, Any] = {
    "primary": {"order": 60, "y_max": 30.0, "t_end": 0.8},
    "scaling": {
        "t_end": 0.4,
        "low": {"order": 48, "y_max": 24.0},
        "high": {"order": 96, "y_max": 48.0},
    },
    "cancellation_scale": 1.0e10,
    "D-JFNK": {
        "step_size": 5.0e-4,
        "newton_rtol": 2.0e-9,
        "newton_atol": 1.0e-12,
        "gmres_rtol": 1.0e-7,
        "max_linear_iterations": 80,
        "noiseless_jvp_relative_step": 2.0e-6,
        "cancellation_jvp_relative_step": 1.0e-3,
    },
    "EXPRB-K": {
        "step_size": 0.025,
        "krylov_dim": 10,
        "jvp_relative_step": 1.0e-3,
    },
    "MLPC-JFNK": {
        "step_size": 7.5e-4,
        "newton_rtol": 2.0e-9,
        "newton_atol": 1.0e-12,
        "gmres_rtol": 1.0e-7,
        "max_linear_iterations": 80,
        "predictor_rtol": 1.0e-9,
        "predictor_atol": 1.0e-11,
        "noiseless_jvp_relative_step": 2.0e-6,
        "cancellation_jvp_relative_step": 1.0e-3,
        "coarse_ratio": 0.8,
    },
}


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _wrms(error: np.ndarray) -> float:
    values = np.asarray(error, dtype=np.float64)
    return float(np.linalg.norm(values) / np.sqrt(values.size))


def _current_rss_bytes() -> int:
    try:
        fields = Path("/proc/self/statm").read_text().split()
        return int(fields[1]) * int(os.sysconf("SC_PAGE_SIZE"))
    except (OSError, IndexError, ValueError):
        return 0


@contextmanager
def _peak_rss_monitor() -> Any:
    stop = threading.Event()
    record = {"peak": _current_rss_bytes()}

    def sample() -> None:
        while not stop.is_set():
            record["peak"] = max(record["peak"], _current_rss_bytes())
            stop.wait(0.002)

    thread = threading.Thread(target=sample, daemon=True)
    thread.start()
    try:
        yield record
    finally:
        stop.set()
        thread.join()
        record["peak"] = max(record["peak"], _current_rss_bytes())


def _max_energy_residual(model: ManufacturedKineticModel, result: SolverResult) -> float:
    return float(
        max(
            abs(model.energy_identity_residual(float(t), result.y[:, index]))
            for index, t in enumerate(result.t)
        )
    )


def _occupations_valid(model: ManufacturedKineticModel, result: SolverResult) -> bool:
    try:
        for index in range(result.y.shape[1]):
            occupation = model.occupations(result.y[:, index])
            if not (
                np.all(np.isfinite(occupation))
                and np.all(occupation > 0.0)
                and np.all(occupation < 1.0)
            ):
                return False
    except (ValueError, FloatingPointError):
        return False
    return True


def _result_summary(
    *,
    lane: str,
    model: ManufacturedKineticModel,
    result: SolverResult,
    t_end: float,
    peak_rss_bytes: int,
    effective_calls: float | None = None,
) -> dict[str, Any]:
    endpoint = result.endpoint
    exact = model.exact_state(t_end)
    calls = float(result.stats.rhs_calls if effective_calls is None else effective_calls)
    return {
        "lane": lane,
        "success": bool(result.success),
        "reason": result.reason,
        "order": model.grid.order,
        "y_max": model.grid.y_max,
        "state_size": model.state_size,
        "t_end": float(t_end),
        "endpoint_wrms": _wrms(endpoint - exact) if result.success else math.inf,
        "endpoint_max_abs": float(np.max(np.abs(endpoint - exact))) if result.success else math.inf,
        "energy_residual_max": _max_energy_residual(model, result) if result.success else math.inf,
        "finite": bool(np.all(np.isfinite(result.y))),
        "occupations_valid": _occupations_valid(model, result),
        "rhs_calls": int(result.stats.rhs_calls),
        "effective_rhs_calls": calls,
        "steps": int(result.stats.steps),
        "newton_iterations": int(result.stats.newton_iterations),
        "linear_iterations": int(result.stats.linear_iterations),
        "jvp_calls": int(result.stats.jacobian_vector_products),
        "line_search_backtracks": int(result.stats.line_search_backtracks),
        "solver_wall_seconds": float(result.stats.wall_seconds),
        "peak_rss_bytes": int(peak_rss_bytes),
        "endpoint_sha256": _sha256_bytes(np.asarray(endpoint, dtype=np.float64).tobytes()),
        "stats_extra": result.stats.extra,
    }


def _build_model(order: int, y_max: float, cancellation_scale: float) -> ManufacturedKineticModel:
    return ManufacturedKineticModel(
        Grid.gauss_legendre(int(order), float(y_max)),
        cancellation_scale=float(cancellation_scale),
    )


def _run_lane(
    method: str,
    *,
    order: int,
    y_max: float,
    t_end: float,
    cancellation_scale: float,
    conservative: bool,
) -> tuple[dict[str, Any], np.ndarray]:
    model = _build_model(order, y_max, cancellation_scale)
    initial = model.exact_state(0.0)
    projector = model.project_energy_identity if conservative else None
    with _peak_rss_monitor() as memory:
        if method == "D-JFNK":
            cfg = FORMAL_CONFIG[method]
            jvp_step = (
                cfg["cancellation_jvp_relative_step"]
                if cancellation_scale > 0.0
                else cfg["noiseless_jvp_relative_step"]
            )
            result = solve_implicit_euler_jfnk(
                model.rhs,
                (0.0, t_end),
                initial,
                step_size=cfg["step_size"],
                newton_rtol=cfg["newton_rtol"],
                newton_atol=cfg["newton_atol"],
                gmres_rtol=cfg["gmres_rtol"],
                max_linear_iterations=cfg["max_linear_iterations"],
                jvp_relative_step=jvp_step,
                state_projector=projector,
            )
            effective_calls = float(result.stats.rhs_calls)
        elif method == "EXPRB-K":
            cfg = FORMAL_CONFIG[method]
            result = solve_exprb_krylov(
                model.rhs,
                (0.0, t_end),
                initial,
                step_size=cfg["step_size"],
                krylov_dim=min(int(cfg["krylov_dim"]), model.state_size + 1),
                jvp_relative_step=cfg["jvp_relative_step"],
                state_projector=projector,
            )
            effective_calls = float(result.stats.rhs_calls)
        elif method == "MLPC-JFNK":
            cfg = FORMAL_CONFIG[method]
            if order == 60 and float(y_max) == 30.0:
                coarse_order, coarse_ymax = 48, 24.0
            else:
                coarse_order = max(8, int(round(cfg["coarse_ratio"] * order)))
                coarse_ymax = cfg["coarse_ratio"] * y_max
            coarse_model = _build_model(coarse_order, coarse_ymax, 0.0)
            transfer = build_transfer_pair(coarse_model.grid, model.grid)

            def fine_diagonal(t: float, state: np.ndarray, h: float) -> np.ndarray:
                return np.diag(
                    np.identity(model.state_size, dtype=np.float64)
                    - h * model.jacobian(t, state)
                )

            jvp_step = (
                cfg["cancellation_jvp_relative_step"]
                if cancellation_scale > 0.0
                else cfg["noiseless_jvp_relative_step"]
            )
            result = solve_mlpc_jfnk(
                fine_fun=model.rhs,
                coarse_model=coarse_model,
                transfer=transfer,
                t_span=(0.0, t_end),
                fine_initial=initial,
                step_size=cfg["step_size"],
                fine_residual_diagonal=fine_diagonal,
                predictor_rtol=cfg["predictor_rtol"],
                predictor_atol=cfg["predictor_atol"],
                newton_rtol=cfg["newton_rtol"],
                newton_atol=cfg["newton_atol"],
                gmres_rtol=cfg["gmres_rtol"],
                max_linear_iterations=cfg["max_linear_iterations"],
                jvp_relative_step=jvp_step,
                state_projector=projector,
            )
            effective_calls = max(
                float(result.stats.rhs_calls),
                float(result.stats.extra["effective_rhs_calls_state_ratio"]),
            )
        else:
            raise ValueError(f"unknown method {method!r}")
    prefix = "EC-" if conservative else "RAW-"
    noise = "cancellation" if cancellation_scale > 0.0 else "noiseless"
    lane = f"{prefix}{method}:{noise}:o{order}"
    summary = _result_summary(
        lane=lane,
        model=model,
        result=result,
        t_end=t_end,
        peak_rss_bytes=memory["peak"],
        effective_calls=effective_calls,
    )
    return summary, result.endpoint.copy()


def _run_scipy_control(method: str, *, order: int, y_max: float, t_end: float) -> dict[str, Any]:
    model = _build_model(order, y_max, 0.0)
    counter = CallCounter()
    rhs = counter.wrap(model.rhs_true)
    kwargs: dict[str, Any] = {
        "method": method,
        "rtol": 1.0e-8,
        "atol": 1.0e-10,
    }
    if method in {"BDF", "Radau"}:
        kwargs["jac"] = model.jacobian
    with _peak_rss_monitor() as memory:
        started = time.perf_counter()
        solution = solve_ivp(rhs, (0.0, t_end), model.exact_state(0.0), **kwargs)
        wall = time.perf_counter() - started
    endpoint = solution.y[:, -1]
    return {
        "lane": f"CONTROL-{method}",
        "success": bool(solution.success),
        "reason": str(solution.message),
        "endpoint_wrms": _wrms(endpoint - model.exact_state(t_end)),
        "energy_residual_max": abs(model.energy_identity_residual(t_end, endpoint)),
        "rhs_calls": int(counter.calls),
        "steps": int(max(0, solution.t.size - 1)),
        "njev": int(solution.njev),
        "nlu": int(solution.nlu),
        "wall_seconds": float(wall),
        "peak_rss_bytes": int(memory["peak"]),
        "endpoint_sha256": _sha256_bytes(endpoint.tobytes()),
    }


def _scaling_exponent(low_calls: float, high_calls: float) -> float:
    if low_calls <= 0.0 or high_calls <= 0.0:
        return math.inf
    return float(math.log(high_calls / low_calls) / math.log(2.0))


def _run_ratchet_probe() -> dict[str, Any]:
    model = _build_model(60, 30.0, FORMAL_CONFIG["cancellation_scale"])
    state = model.exact_state(0.163)
    threshold = np.full(model.state_size, 1.0e-9, dtype=np.float64)
    persistent_counter = CallCounter()
    reset_counter = CallCounter()
    persistent = run_num_jac_refresh_probe(
        fun=persistent_counter.wrap(model.rhs),
        analytic_jacobian=model.jacobian,
        t=0.163,
        y=state,
        threshold=threshold,
        refreshes=12,
        persistent_factor=True,
    )
    reset = run_num_jac_refresh_probe(
        fun=reset_counter.wrap(model.rhs),
        analytic_jacobian=model.jacobian,
        t=0.163,
        y=state,
        threshold=threshold,
        refreshes=12,
        persistent_factor=False,
    )
    return {
        "persistent": {
            "records": [asdict(item) for item in persistent.records],
            "rhs_calls": persistent_counter.calls,
        },
        "reset_each_refresh": {
            "records": [asdict(item) for item in reset.records],
            "rhs_calls": reset_counter.calls,
        },
    }


def _algorithmic_screens() -> dict[str, Any]:
    model = _build_model(60, 30.0, 0.0)
    state = model.exact_state(0.163)
    jacobian = model.jacobian(0.163, state)
    spectral_jacobian = jacobian[: model.spectral_size, : model.spectral_size]
    eigenvalues = np.linalg.eigvals(jacobian)
    spectral_eigenvalues = np.linalg.eigvals(spectral_jacobian)
    instability_tolerance = 1.0e-12
    screens: dict[str, Any] = {
        "jacobian": {
            "full_state_spectral_abscissa": float(np.max(np.real(eigenvalues))),
            "spectral_block_abscissa": float(np.max(np.real(spectral_eigenvalues))),
            "spectral_block_radius": float(np.max(np.abs(spectral_eigenvalues))),
            "n_positive_real_full_state_above_tolerance": int(
                np.count_nonzero(np.real(eigenvalues) > instability_tolerance)
            ),
            "n_positive_real_spectral_block_above_tolerance": int(
                np.count_nonzero(np.real(spectral_eigenvalues) > instability_tolerance)
            ),
            "instability_tolerance": instability_tolerance,
        },
        "picard": [],
        "diagonal_split": [],
    }
    for h in (0.025, 0.05, 0.1, 0.2):
        screens["picard"].append(
            {
                "h": h,
                "linearized_iteration_spectral_radius": float(
                    h * np.max(np.abs(eigenvalues))
                ),
                "locally_contracting_by_spectral_radius": bool(
                    h * np.max(np.abs(eigenvalues)) < 1.0
                ),
            }
        )
        residual_matrix = np.identity(model.state_size) - h * jacobian
        diagonal = np.diag(np.diag(residual_matrix))
        diagonal_preconditioned = np.linalg.solve(diagonal, residual_matrix)
        condition_raw = float(np.linalg.cond(residual_matrix))
        condition_diagonal = float(np.linalg.cond(diagonal_preconditioned))
        screens["diagonal_split"].append(
            {
                "h": h,
                "condition_raw": condition_raw,
                "condition_after_diagonal_left_preconditioning": condition_diagonal,
                "improvement_factor": condition_raw / condition_diagonal,
            }
        )
    return screens


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _write_summary_csv(path: Path, decisions: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = [
        "name",
        "status",
        "endpoint_wrms",
        "cancellation_endpoint_wrms",
        "energy_residual",
        "cancellation_energy_residual",
        "rhs_calls",
        "scaling_exponent",
        "projected_wall_seconds",
        "deterministic",
        "peak_rss_bytes",
        "failed_gates",
    ]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for decision in decisions:
            metrics = decision["metrics"]
            writer.writerow(
                {
                    "name": decision["name"],
                    "status": decision["status"],
                    "endpoint_wrms": metrics["endpoint_wrms"],
                    "cancellation_endpoint_wrms": metrics[
                        "cancellation_endpoint_wrms"
                    ],
                    "energy_residual": metrics["energy_residual"],
                    "cancellation_energy_residual": metrics[
                        "cancellation_energy_residual"
                    ],
                    "rhs_calls": metrics["rhs_calls"],
                    "scaling_exponent": metrics["scaling_exponent"],
                    "projected_wall_seconds": decision["projected_wall_seconds"],
                    "deterministic": metrics["deterministic"],
                    "peak_rss_bytes": metrics["peak_rss_bytes"],
                    "failed_gates": ";".join(
                        name for name, passed in decision["gates"].items() if not passed
                    ),
                }
            )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "results" / "formal")
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    endpoint_dir = out / "endpoints"
    endpoint_dir.mkdir(exist_ok=True)

    config_bytes = json.dumps(FORMAL_CONFIG, sort_keys=True).encode()
    protocol = {
        "config": FORMAL_CONFIG,
        "config_sha256": _sha256_bytes(config_bytes),
        "protocol_file_sha256": _sha256_bytes(
            (ROOT / "FORMAL_SWEEP_PROTOCOL.md").read_bytes()
        ),
        "contract_sha256": _sha256_bytes((ROOT / "SCIENTIFIC_CONTRACT.md").read_bytes()),
        "amendment_sha256": _sha256_bytes(
            (ROOT / "SCIENTIFIC_CONTRACT_AMENDMENT_01.md").read_bytes()
        ),
        "python": sys.version,
        "numpy": np.__version__,
    }
    _write_json(out / "protocol_lock.json", protocol)

    all_runs: list[dict[str, Any]] = []
    decisions: list[dict[str, Any]] = []
    primary = FORMAL_CONFIG["primary"]
    scaling = FORMAL_CONFIG["scaling"]

    for method in ("D-JFNK", "EXPRB-K", "MLPC-JFNK"):
        primary_run, primary_endpoint = _run_lane(
            method,
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
            cancellation_scale=0.0,
            conservative=True,
        )
        repeat_run, repeat_endpoint = _run_lane(
            method,
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
            cancellation_scale=0.0,
            conservative=True,
        )
        cancellation_run, cancellation_endpoint = _run_lane(
            method,
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
            cancellation_scale=FORMAL_CONFIG["cancellation_scale"],
            conservative=True,
        )
        low_run, _ = _run_lane(
            method,
            order=scaling["low"]["order"],
            y_max=scaling["low"]["y_max"],
            t_end=scaling["t_end"],
            cancellation_scale=0.0,
            conservative=True,
        )
        high_run, _ = _run_lane(
            method,
            order=scaling["high"]["order"],
            y_max=scaling["high"]["y_max"],
            t_end=scaling["t_end"],
            cancellation_scale=0.0,
            conservative=True,
        )
        raw_run, raw_endpoint = _run_lane(
            method,
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
            cancellation_scale=0.0,
            conservative=False,
        )
        raw_cancellation_run, raw_cancellation_endpoint = _run_lane(
            method,
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
            cancellation_scale=FORMAL_CONFIG["cancellation_scale"],
            conservative=False,
        )
        all_runs.extend(
            [
                primary_run,
                repeat_run,
                cancellation_run,
                low_run,
                high_run,
                raw_run,
                raw_cancellation_run,
            ]
        )
        deterministic = bool(
            np.array_equal(primary_endpoint, repeat_endpoint)
            and primary_run["rhs_calls"] == repeat_run["rhs_calls"]
            and primary_run["steps"] == repeat_run["steps"]
            and primary_run["linear_iterations"] == repeat_run["linear_iterations"]
            and primary_run["jvp_calls"] == repeat_run["jvp_calls"]
        )
        exponent = _scaling_exponent(
            low_run["effective_rhs_calls"], high_run["effective_rhs_calls"]
        )
        effective_calls = max(
            primary_run["effective_rhs_calls"],
            cancellation_run["effective_rhs_calls"],
        )
        metrics = CandidateMetrics(
            name=f"EC-{method}",
            success=bool(primary_run["success"] and cancellation_run["success"]),
            finite=bool(primary_run["finite"] and cancellation_run["finite"]),
            occupations_valid=bool(
                primary_run["occupations_valid"]
                and cancellation_run["occupations_valid"]
            ),
            matrix_free=True,
            control_only=False,
            endpoint_wrms=float(primary_run["endpoint_wrms"]),
            cancellation_endpoint_wrms=float(
                cancellation_run["endpoint_wrms"]
            ),
            energy_residual=float(primary_run["energy_residual_max"]),
            cancellation_energy_residual=float(
                cancellation_run["energy_residual_max"]
            ),
            rhs_calls=float(effective_calls),
            scaling_exponent=float(exponent),
            deterministic=deterministic,
            peak_rss_bytes=int(
                max(
                    primary_run["peak_rss_bytes"],
                    repeat_run["peak_rss_bytes"],
                    cancellation_run["peak_rss_bytes"],
                    low_run["peak_rss_bytes"],
                    high_run["peak_rss_bytes"],
                )
            ),
        )
        decision = adjudicate_candidate(metrics).to_dict()
        decision["run_refs"] = {
            "primary": primary_run["lane"],
            "repeat": repeat_run["lane"],
            "cancellation": cancellation_run["lane"],
            "scaling_low": low_run["lane"],
            "scaling_high": high_run["lane"],
            "raw": raw_run["lane"],
            "raw_cancellation": raw_cancellation_run["lane"],
        }
        decision["raw_energy_negative_control"] = {
            "noiseless": raw_run["energy_residual_max"],
            "cancellation": raw_cancellation_run["energy_residual_max"],
        }
        decisions.append(decision)
        for label, endpoint in {
            f"EC-{method}-primary": primary_endpoint,
            f"EC-{method}-repeat": repeat_endpoint,
            f"EC-{method}-cancellation": cancellation_endpoint,
            f"RAW-{method}-primary": raw_endpoint,
            f"RAW-{method}-cancellation": raw_cancellation_endpoint,
        }.items():
            np.savez_compressed(endpoint_dir / f"{label}.npz", endpoint=endpoint)

    controls = [
        _run_scipy_control(
            "Radau",
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
        ),
        _run_scipy_control(
            "BDF",
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
        ),
        _run_scipy_control(
            "LSODA",
            order=primary["order"],
            y_max=primary["y_max"],
            t_end=primary["t_end"],
        ),
    ]
    for control in controls:
        metrics = CandidateMetrics(
            name=control["lane"],
            success=bool(control["success"]),
            finite=True,
            occupations_valid=True,
            matrix_free=False,
            control_only=True,
            endpoint_wrms=float(control["endpoint_wrms"]),
            cancellation_endpoint_wrms=float(control["endpoint_wrms"]),
            energy_residual=float(control["energy_residual_max"]),
            cancellation_energy_residual=float(control["energy_residual_max"]),
            rhs_calls=float(control["rhs_calls"]),
            scaling_exponent=0.0,
            deterministic=True,
            peak_rss_bytes=int(control["peak_rss_bytes"]),
        )
        decisions.append(adjudicate_candidate(metrics).to_dict())

    ratchet = _run_ratchet_probe()
    screens = _algorithmic_screens()
    payload = {
        "protocol": protocol,
        "runs": all_runs,
        "controls": controls,
        "decisions": decisions,
        "ratchet_probe": ratchet,
        "algorithmic_screens": screens,
    }
    _write_json(out / "formal_solver_sweep.json", payload)
    _write_json(out / "ratchet_probe.json", ratchet)
    _write_json(out / "algorithmic_screens.json", screens)
    _write_summary_csv(out / "candidate_summary.csv", decisions)
    print(json.dumps({"decisions": [(d["name"], d["status"]) for d in decisions]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
