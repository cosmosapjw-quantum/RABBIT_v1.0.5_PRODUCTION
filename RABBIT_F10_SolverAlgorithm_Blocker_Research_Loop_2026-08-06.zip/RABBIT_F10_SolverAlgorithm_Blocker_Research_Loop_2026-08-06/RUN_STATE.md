# RUN_STATE.md

DATE: 2026-08-06

CURRENT_LAYER: durable closeout

TASK: Solver/algorithm/programming research loop for the F10 order-60 trajectory blocker.

CURRENT_RESULT:
- formal survivor: `EC-EXPRB-K`;
- secondary post-formal survivor: `EC-PICARD-IE`;
- killed: `EC-D-JFNK`, `EC-MLPC-JFNK`;
- controls retained but not reopening candidates.

CLAIM_CEILING: `SYNTHETIC_ALGORITHM_SURVIVOR / PHYSICAL_PREFIX_PENDING / NO_GATE_MOVEMENT`.

REPRODUCTION_OR_ACCEPTANCE:
- 38 tests pass;
- coding harness validation passes;
- protocol digests match;
- survivor endpoints/counters replay bitwise;
- EXPRB/Picard contain no hidden analytic Jacobian or SciPy time-integrator path.

BLOCKERS:
- no original RABBIT source edit in this workspace;
- no physical 60/30 creep-prefix;
- synthetic projector must be replaced by physical total-comoving-energy coordinate;
- physical RHS cost, JVP noise and Krylov dimension remain unmeasured.

NEXT_MINIMAL_ACTION: owner-authorized PR-SA00 source/evidence lock followed by PR-SA01–SA03 static integration preparation.
