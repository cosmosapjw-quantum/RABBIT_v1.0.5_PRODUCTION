# Post-formal Protocol 01 — EC-PICARD-IE derivative-free candidate

**Frozen before the candidate implementation and retained run.**

The formal screen showed that JFNK fails on the `1e10` cancellation oracle because an
accurate linear residual cannot be obtained from noisy finite-difference JVPs. The measured
spectral-block radius is about 7.9, so for the small accuracy-limited step the implicit-Euler
fixed-point map is strongly contractive without any derivative.

Candidate: `EC-PICARD-IE`

- primary: order 60 / y_max 30, N in [0,0.8];
- scaling: 48/24 and 96/48, N in [0,0.4];
- cancellation scale: 1e10;
- fixed step h=4e-4;
- projected fixed-point map `Phi(z)=P_E[y_n+h F(t_{n+1},z)]`;
- absolute component WRMS fixed-point tolerance 1e-8;
- maximum 4 Picard evaluations per step;
- accept the last *evaluated* iterate when `||Phi(z)-z||_WRMS <= 1e-8`, so its RHS is
  reusable as the next explicit predictor and every call remains accounted;
- no JVP, Jacobian, Krylov solve, Anderson fit, fallback, or tolerance adaptation;
- the same frozen adjudicator and numerical bands as the formal sweep.

A failure is preserved. No parameter may be changed after the first retained output.
