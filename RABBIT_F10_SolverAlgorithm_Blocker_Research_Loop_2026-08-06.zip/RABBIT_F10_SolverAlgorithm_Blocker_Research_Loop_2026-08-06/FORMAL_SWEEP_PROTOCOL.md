# Formal Solver/Algorithm Sweep Protocol

**Freeze state:** committed before the formal runner writes any result file.

## Holdout geometry

- Primary interval: dimensionless `N in [0, 0.8]` (not used in the exploratory tuning runs).
- RABBIT-matched primary grid: `order=60`, `y_max=30`, state dimension 182.
- Scaling grids: `(48,24)` and `(96,48)` on `N in [0,0.4]`.
- Cancellation oracle: deterministic cancellation baseline `1e10`.
- Endpoint metric: absolute component WRMS, equivalently `scale_i=1` for every
  dimensionless manufactured component.
- Energy metric: maximum absolute manufactured identity residual over retained states.
- Positivity: every retained occupation must remain finite and strictly in `(0,1)`.

## Frozen candidate configurations

### EC-D-JFNK

- implicit Euler, `h=5e-4`;
- `newton_rtol=2e-9`, `newton_atol=1e-12`;
- `gmres_rtol=1e-7`, `max_linear_iterations=80`;
- fixed forward JVP relative step `1e-3` on the cancellation lane and `2e-6`
  on the noiseless lane;
- conservative scalar projection after every accepted step.

### EC-EXPRB-K

- nonautonomous time-augmented exponential Rosenbrock--Krylov;
- `h=0.025`, Krylov dimension `m=10`;
- fixed forward augmented JVP relative step `1e-3`;
- conservative scalar projection after every accepted step.

### EC-MLPC-JFNK

- exact fine implicit-Euler residual, `h=7.5e-4`;
- coarse/fine ratio `0.8`; primary map is exactly 48/24 -> 60/30;
- Radau coarse predictor with analytic coarse Jacobian, `rtol=1e-9`, `atol=1e-11`;
- coarse residual solve plus fine diagonal complement smoother;
- `newton_rtol=2e-9`, `newton_atol=1e-12`, `gmres_rtol=1e-7`;
- fixed forward fine JVP relative step `1e-3` on cancellation and `2e-6`
  on noiseless;
- conservative scalar projection after every accepted step.

## Negative and diagnostic controls

- Unprojected versions of all three candidates preserve their raw energy defects.
- `SUPPLIED-JAC-BDF` and `LSODA` are diagnostic controls and cannot be D-071
  reopening survivors regardless of speed or accuracy.
- The direct SciPy `num_jac` lifetime probe retains the exact persistent-factor
  mechanism and a reset-each-refresh counterfactual.
- Picard and diagonal-only split screens are local linear discriminators, not candidate
  integrations.

## Determinism and accounting

- Each EC primary lane is run twice in the same process environment. Endpoint bytes and
  integer counters must match exactly.
- Every black-box full fine RHS/JVP is one full-RHS-equivalent call.
- MLPC also reports coarse calls and a state-ratio effective count; adjudication uses the
  larger of fine calls and the state-ratio effective count.
- No failed lane is retried with altered parameters.
