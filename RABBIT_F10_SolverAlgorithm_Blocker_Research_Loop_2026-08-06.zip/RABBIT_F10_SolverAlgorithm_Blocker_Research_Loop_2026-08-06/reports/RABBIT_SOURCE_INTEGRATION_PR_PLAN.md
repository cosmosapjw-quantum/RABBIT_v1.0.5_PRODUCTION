# RABBIT source integration PR plan

## Global constraints

- Work on a new owner-authorized worktree from an exact upstream commit.
- Do not edit the frozen D-069/D-071 instruments or retained evidence.
- No QKE, Bianchi, public dispatch, or production claim.
- Every run contract is committed before first output.
- Preserve all raw failures and call counters.
- Formal baseline begins with `m=10`; `m=4` is a separate optimization contract.

## DAG

```text
SA00
 └─ SA01
     └─ SA02
         └─ SA03
             ├─ SA04 ─ SA05 ─┬─ KILL
             │               └─ SA06 ─ SA07 ─ SA08
             └─ PB01 ─ PB02
SA06 ─ OPT01
```

## PR-SA00 — Source, environment and evidence lock

**Purpose:** establish SSOT before code changes.

**Inputs**
- upstream commit and branch
- `_independent_noqke.py` SHA-256
- V3 report/available raw checkpoint digests
- Python/NumPy/SciPy/BLAS versions

**Outputs**
- `SOLVER_RESEARCH_INPUT_LOCK.json`
- source tree manifest and SHA256SUMS
- explicit no-edit list

**PASS**
- every required source and artifact resolves by digest
- baseline unit/release tests pass

**FAIL**
- missing/ambiguous source or transcript-only evidence

## PR-SA01 — Pure RHS and full-RHS-equivalent accounting interface

**Purpose:** separate physical evaluation from SciPy integration without changing physics.

**Interface**

```python
class IndependentTrajectoryRhs(Protocol):
    def evaluate(self, N: float, state: np.ndarray) -> RhsEvaluation: ...

@dataclass(frozen=True)
class RhsEvaluation:
    derivative: np.ndarray
    collision_action: np.ndarray
    q_em: float
    hubble: float
    domain_rejections: int
    max_roundoff: float
```

**Requirements**
- bitwise same derivative as frozen RHS on disclosed states
- each evaluation increments a durable counter
- no hidden cache changes physics

**Tests**
- initial state, three V3 creep states, late state
- sign mutants remain killed

## PR-SA02 — Total-comoving-energy coordinate and algebraic `T_gamma`

**Purpose:** replace synthetic projection by physical energy structure.

Define

\[
W=e^{4N}(\rho_\nu+\rho_{\rm EM}),
\qquad
W'=e^{4N}(\rho_{\rm EM}-3P_{\rm EM})+e^{4N}R_E.
\]

Recover `T_gamma` from

\[
\rho_{\rm EM}(T_\gamma)=e^{-4N}W-\rho_\nu[f].
\]

**Required specs**
- monotone bracket and uniqueness check
- explicit discrete residual `R_E`; no silent projection
- dimensions: `[W]=MeV^4`, `[dW/dN]=MeV^4`
- exact comparison to old coordinate on 48/24 completed trajectory

**PASS**
- coordinate round trip and derivative equivalence within predeclared bands
- total-energy ledger closes without endpoint fitting

## PR-SA03 — Static physical JVP/noise discriminator

**Purpose:** determine whether fresh directional differences are usable on actual collision states.

**States**
- initial 60/30
- at least three creep states spanning `N≈0.1628–0.1632`
- one late decoupled state

**Measurements**
- `F(y+epsilon v)-F(y)` signal/cancellation ratio
- Arnoldi orthogonality and breakdown
- consistency across `epsilon` values fixed before output
- invariant/occupation/domain-rejection changes under perturbation
- optional comparison to pinned-column or AD-JVP observation only

**Kill rule**
- no predeclared epsilon interval produces stable directional action for required modes

## PR-SA04 — EC-EXPRB-K research backend

**Purpose:** implement the formal survivor without public dispatch.

**Baseline parameters**
- time-augmented operator
- Krylov `m=10`
- double modified Gram-Schmidt
- reduced `phi_1` action
- physical total-energy coordinate
- fixed step/prefix schedule declared in SA05 contract

**Diagnostics**
- RHS/JVP calls per step
- Arnoldi dimension/breakdown
- orthogonality residual
- projected implicit-Euler defect proxy
- occupation and energy ledger

**Forbidden**
- analytic full Jacobian
- persistent `jac_factor`
- post-output `m`, epsilon or step fitting

## PR-SA05 — Sealed 60/30 creep-prefix discriminator

**Coverage**
- start at physical initial state
- reach at least `N=0.25`
- contain entire historical stall interval `0.14≤N≤0.22`

**Hard caps**
- predeclared full-RHS calls and wall
- no extension after inconvenient output

**PASS requires all**
- accepted progress through stall interval
- end-to-end call projection `≤5500` with margin
- projected wall `<64800 s` with margin
- first-law/occupation/domain/tail ledgers pass
- no fallback

**KILL**
- any missing predicate, cap breach, Krylov/JVP instability or changed config

## PR-SA06 — Holdout ladder

- 48/24 completed reference
- 60/30 primary
- 72/36 and/or 96/48 representation holdout
- fixed independent directional-step holdout
- Krylov `m=10` baseline and separately sealed `m=4` observation
- second environment/BLAS replay where available

No holdout is allowed to refit the primary.

## PR-SA07 — Full 60/30 trajectory

Run only after SA05 and SA06 PASS.

Retain:
- complete endpoint state
- all scientific predicates from D-069 where applicable
- full call/wall ledger
- checkpoints sufficient for independent recomputation
- crash-safe periodic checkpointing

## PR-SA08 — Independent replay and D-071 adjudication

An adjudicator not involved in implementation:

- loads contract thresholds by digest
- recomputes endpoint and ledger predicates
- verifies chronology
- decides PASS/FAIL without editing code or thresholds

Only this PR may propose gate movement.

## PR-PB01/PB02 — Picard fallback

PB01 first proves or bounds contraction on actual creep states in a declared weighted norm. PB02 runs a prefix only if PB01 passes. The 4-iteration cap and call budget remain immutable.

## PR-OPT01 — `m=4` or recycled Krylov optimization

This is not part of the formal baseline. It requires:

- new pre-output contract
- residual/defect-based basis adequacy predicate
- fallback to `m=10` counted and predeclared, or no fallback
- unchanged physical outputs and ledgers
