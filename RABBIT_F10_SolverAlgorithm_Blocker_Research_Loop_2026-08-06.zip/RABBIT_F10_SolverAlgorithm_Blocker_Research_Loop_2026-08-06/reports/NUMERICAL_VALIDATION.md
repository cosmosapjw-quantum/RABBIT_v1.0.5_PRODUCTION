# Numerical validation report

## Scope

This report validates only the standalone manufactured/cancellation benchmark. It does not validate the physical RABBIT collision trajectory.

## Test ladder

| Check | Result |
|---|---|
| unit/regression suite | PASS |
| exact manufactured RHS | PASS |
| analytic linear reference | PASS |
| fixed-rule JVP vs analytic `Jv` | PASS in noiseless regime |
| SciPy persistent-factor reproduction | PASS |
| endpoint/counter deterministic replay | PASS |
| protocol digest locks | PASS |
| JSON/CSV/NPZ integrity | PASS |
| occupation strict-open domain | PASS for retained candidate states |
| energy-constrained invariant | machine precision |

## Formal decisions

| Candidate | Decision | Principal failure/pass mode |
|---|---|---|
| EC-D-JFNK | KILL | cancellation GMRES failure; 9,666 calls; slight accuracy miss |
| EC-EXPRB-K | SURVIVE | all frozen gates pass; 352 calls |
| EC-MLPC-JFNK | KILL | fine JVP noise; 7,701 effective calls; accuracy miss |
| controls | scope KILL | diagnostic only |

## EXPRB convergence

The measured error ratios under step halving give observed orders 1.994, 2.016, 2.048 and 2.109. The formal point `h=0.025` lies in the observed second-order regime.

## Krylov convergence

At fixed `h=0.025`, endpoint WRMS changes from `9.0873e-6` at `m=2` to `9.07685e-6` at `m=4`, and is numerically saturated by `m=6`. The formal candidate remains `m=10`; an `m=4` promotion requires a separate prospective contract.

## Cancellation robustness

With fixed directional step `1e-3`, the formal EXPRB candidate remains under `2e-4` through synthetic cancellation scale `3e12`; it fails at `1e13`. This is a numerical stress ladder, not a calibrated physical gain/loss ratio.

## Resolution/cost scaling

For `m=4`, fixed `h`, and state dimensions 74–290, the full-RHS call count is exactly 160. The algorithmic call exponent is therefore 0 on this benchmark. Physical per-call cost remains unmeasured.

## Conservation negative control

Raw unprojected energy residuals:

- EXPRB noiseless: `1.1677e-6`
- EXPRB cancellation: `6.7938e-6`
- Picard noiseless: `2.3127e-6`
- Picard cancellation: `2.4137e-6`

Therefore the energy-constrained coordinate is load-bearing, not cosmetic.
