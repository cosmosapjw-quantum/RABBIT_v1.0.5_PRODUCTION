# Scientific validation and claim boundary

## Conventions

- spacetime signature when referenced: `(-,+,+,+)`
- RABBIT independent variable: `N=ln a`
- RABBIT units: MeV natural units
- standalone benchmark: dimensionless time/state
- target physics: classical flavour-diagonal no-QKE flat FLRW comparator

## What is preserved by design

- three spectral flavour-pair blocks
- strict occupation domain `(0,1)`
- fixed state dimensions matching order 48/60/96 classes
- stable nonnormal creep-shaped spectral operator
- exact manufactured total-energy identity
- black-box full-RHS accounting
- deterministic cancellation oracle

## What is not modeled faithfully

- actual 2→2 collision quadrature and domain rejection geometry
- physical electron/positron EOS inversion
- real collision gain/loss dynamic range
- physical tail truncation error
- real endpoint `N_eff`
- actual 4.5 s RHS-cost distribution under each candidate
- production checkpoint/restart behavior

## Central scientific conclusion

The benchmark supports the proposition that replacing persistent dense finite-difference BDF by an energy-constrained exponential Krylov method can reduce the *algorithmic* full-RHS count by more than an order of magnitude while remaining robust to a severe deterministic cancellation oracle.

It does not support the proposition that the physical 60/30 RABBIT trajectory is already solved.

## Required physical falsifiers

A physical prefix must kill the candidate if any of the following occurs:

1. actual Krylov dimension repeatedly exceeds the sealed cap;
2. directional JVP signal/noise fails the sealed bound;
3. total-energy/T-gamma algebraic recovery loses uniqueness or positivity;
4. occupation exits `(0,1)` without clipping;
5. call projection exceeds 5,500 or projected wall exceeds 64,800 s;
6. 48/24 reference blocks or static 60/30 anchors leave frozen bands;
7. tail/domain-rejection ledger is not enclosed;
8. any parameter is changed after first output.

## Claim ceiling

`SYNTHETIC_ALGORITHM_SURVIVOR`; `PHYSICAL_PREFIX_PENDING`; `NO_GATE_MOVEMENT`.
