# Independent diff and implementation review

## Reviewed surface

- `src/f10_solver_research/`
- solver implementations under `solvers/`
- formal/post-formal runners
- protocols and adjudicator
- tests and retained evidence

## Findings

### IDR-01 — Matrix-free boundary: PASS

`exprb.py` and `picard.py` contain no analytic-Jacobian call, SciPy `num_jac`, or `solve_ivp` path. EXPRB uses only fresh directional RHS differences; Picard uses none.

### IDR-02 — Call accounting: PASS

Every scalar RHS and every perturbed JVP RHS increments `CallCounter`. Vectorized finite-difference columns in the SciPy probe are charged by batch width, not by Python invocation count.

### IDR-03 — Determinism: PASS

Formal EXPRB primary/cancellation and post-formal Picard endpoints replay bitwise. Step/call counters also match.

### IDR-04 — Protocol chronology: PASS

Formal and post-formal protocol SHA-256 values match retained evidence. v1 and mechanically corrected v2 are both preserved, with no status changes.

### IDR-05 — Conservation implementation: CONCERN, explicit claim limit

The synthetic projector knows the manufactured trace integral. It is valid for testing the solver architecture but cannot be copied into RABBIT. Physical integration must use the derived total-comoving-energy evolution and algebraic plasma-temperature recovery.

### IDR-06 — MLPC matrix-free label: PASS WITH NOTE

MLPC does not assemble a full fine Jacobian but uses an analytic fine residual diagonal and analytic coarse Jacobian as a preconditioner. This was prospectively declared. It failed the formal gates, so it is not a survivor claim.

### IDR-07 — Control interpretation: PASS WITH NOTE

Radau/BDF controls receive an analytic manufactured Jacobian. LSODA is an off-the-shelf control and did not enter stiff mode in the formal benchmark. None is promoted to a D-071 candidate.

### IDR-08 — Formal EXPRB method label: CONCERN, nonblocking

The prototype is best described operationally as a time-augmented exponential Rosenbrock-Euler/Krylov action, with observed second-order behavior on this manufactured problem. A production paper should not claim a general order theorem beyond the implemented method and tested regime without a full B-series/order-condition derivation.

### IDR-09 — Physical applicability: UNVERIFIED

No original RABBIT source or raw V3 state/Jacobian artifact was available in this workspace. The integration plan therefore starts with static and prefix discriminators rather than a full trajectory.

## Verdict

`PASS_FOR_RESEARCH_PACKAGE`; `NOT_READY_FOR_PRODUCTION_MERGE`; `PHYSICAL_PREFIX_REQUIRED`.
