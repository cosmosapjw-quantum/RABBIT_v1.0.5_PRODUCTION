#!/usr/bin/env python3
from __future__ import annotations

import ast
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from scripts import run_solver_algorithm_loop as formal  # noqa: E402
from f10_solver_research.solvers.exprb import solve_exprb_krylov  # noqa: E402
from f10_solver_research.solvers.picard import solve_implicit_euler_picard  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_files() -> list[str]:
    messages: list[str] = []
    for path in ROOT.rglob("*.json"):
        if "/.git/" not in str(path):
            json.loads(path.read_text())
    messages.append("all JSON files parse")
    for path in ROOT.rglob("*.csv"):
        with path.open(newline="") as handle:
            list(csv.DictReader(handle))
    messages.append("all CSV files parse")
    for path in ROOT.rglob("*.npz"):
        with np.load(path) as payload:
            if not payload.files:
                raise AssertionError(f"empty npz: {path}")
            for key in payload.files:
                if not np.all(np.isfinite(payload[key])):
                    raise AssertionError(f"nonfinite npz array: {path}:{key}")
    messages.append("all NPZ arrays are finite and nonempty")
    return messages


def check_protocol_locks() -> list[str]:
    formal_lock = json.loads((ROOT / "results/formal_v2/protocol_lock.json").read_text())
    if formal_lock["protocol_file_sha256"] != sha256(ROOT / "FORMAL_SWEEP_PROTOCOL.md"):
        raise AssertionError("formal protocol digest mismatch")
    if formal_lock["contract_sha256"] != sha256(ROOT / "SCIENTIFIC_CONTRACT.md"):
        raise AssertionError("scientific contract digest mismatch")
    if formal_lock["amendment_sha256"] != sha256(ROOT / "SCIENTIFIC_CONTRACT_AMENDMENT_01.md"):
        raise AssertionError("contract amendment digest mismatch")
    post = json.loads((ROOT / "results/postformal/postformal_research.json").read_text())
    if post["protocol"]["postformal_protocol_sha256"] != sha256(ROOT / "POSTFORMAL_PROTOCOL_01.md"):
        raise AssertionError("postformal protocol digest mismatch")
    if post["protocol"]["formal_v2_sha256"] != sha256(ROOT / "results/formal_v2/formal_solver_sweep.json"):
        raise AssertionError("formal-v2 dependency digest mismatch")
    return ["formal and postformal protocol locks match current bytes"]


def imported_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text())
    modules: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            modules.add(node.module or "")
    return modules


def check_matrix_free_boundaries() -> list[str]:
    exprb = ROOT / "src/f10_solver_research/solvers/exprb.py"
    picard = ROOT / "src/f10_solver_research/solvers/picard.py"
    for path in (exprb, picard):
        text = path.read_text()
        if ".jacobian(" in text or "num_jac" in text or "solve_ivp" in text:
            raise AssertionError(f"hidden Jacobian/solve_ivp dependency in {path.name}")
    exprb_modules = imported_modules(exprb)
    picard_modules = imported_modules(picard)
    if "scipy.linalg" not in exprb_modules:
        raise AssertionError("EXPRB reduced exponential action missing")
    if any(name.startswith("scipy.integrate") for name in exprb_modules | picard_modules):
        raise AssertionError("survivor imports SciPy time integrator")
    return ["EXPRB-K and Picard survivor code contains no analytic Jacobian, num_jac, or solve_ivp path"]


def retained_endpoint(path: Path) -> np.ndarray:
    with np.load(path) as payload:
        return np.asarray(payload["endpoint"], dtype=np.float64)


def check_exprb_replay() -> list[str]:
    model = formal._build_model(60, 30.0, 0.0)
    result = solve_exprb_krylov(
        model.rhs,
        (0.0, 0.8),
        model.exact_state(0.0),
        step_size=0.025,
        krylov_dim=10,
        jvp_relative_step=1e-3,
        state_projector=model.project_energy_identity,
    )
    expected = retained_endpoint(ROOT / "results/formal_v2/endpoints/EC-EXPRB-K-primary.npz")
    if not np.array_equal(result.endpoint, expected):
        raise AssertionError("EC-EXPRB-K primary replay is not bitwise equal")
    formal_json = json.loads((ROOT / "results/formal_v2/formal_solver_sweep.json").read_text())
    row = next(item for item in formal_json["runs"] if item["lane"] == "EC-EXPRB-K:noiseless:o60")
    if result.stats.rhs_calls != row["rhs_calls"] or result.stats.steps != row["steps"]:
        raise AssertionError("EC-EXPRB-K replay counters differ")
    cancellation = formal._build_model(60, 30.0, 1e10)
    result_c = solve_exprb_krylov(
        cancellation.rhs,
        (0.0, 0.8),
        cancellation.exact_state(0.0),
        step_size=0.025,
        krylov_dim=10,
        jvp_relative_step=1e-3,
        state_projector=cancellation.project_energy_identity,
    )
    expected_c = retained_endpoint(ROOT / "results/formal_v2/endpoints/EC-EXPRB-K-cancellation.npz")
    if not np.array_equal(result_c.endpoint, expected_c):
        raise AssertionError("EC-EXPRB-K cancellation replay is not bitwise equal")
    return ["EC-EXPRB-K primary and cancellation endpoints/counters replay bitwise"]


def check_picard_replay() -> list[str]:
    model = formal._build_model(60, 30.0, 0.0)
    result = solve_implicit_euler_picard(
        model.rhs,
        (0.0, 0.8),
        model.exact_state(0.0),
        step_size=4e-4,
        fixed_point_tolerance=1e-8,
        max_iterations=4,
        state_projector=model.project_energy_identity,
    )
    expected = retained_endpoint(ROOT / "results/postformal/endpoints/EC-PICARD-IE-primary.npz")
    if not np.array_equal(result.endpoint, expected):
        raise AssertionError("EC-PICARD-IE replay is not bitwise equal")
    if result.stats.rhs_calls != 4001 or result.stats.steps != 2000:
        raise AssertionError("EC-PICARD-IE replay counters differ")
    if result.stats.jacobian_vector_products != 0 or result.stats.linear_iterations != 0:
        raise AssertionError("EC-PICARD-IE unexpectedly used derivatives or linear solves")
    return ["EC-PICARD-IE endpoint/counters replay bitwise with zero JVP/linear iterations"]


def check_decisions() -> list[str]:
    formal_json = json.loads((ROOT / "results/formal_v2/formal_solver_sweep.json").read_text())
    observed = {row["name"]: row["status"] for row in formal_json["decisions"]}
    expected = {
        "EC-D-JFNK": "KILL",
        "EC-EXPRB-K": "SURVIVE",
        "EC-MLPC-JFNK": "KILL",
        "CONTROL-Radau": "KILL",
        "CONTROL-BDF": "KILL",
        "CONTROL-LSODA": "KILL",
    }
    if observed != expected:
        raise AssertionError(f"formal decision drift: {observed}")
    post = json.loads((ROOT / "results/postformal/picard_decision.json").read_text())
    if post["status"] != "SURVIVE" or post["claim_ceiling"] != "POSTFORMAL_SYNTHETIC_SURVIVOR_NOT_D071_REOPEN":
        raise AssertionError("Picard decision or claim ceiling drift")
    return ["formal and postformal decision statuses match the sealed adjudications"]


def main() -> int:
    messages: list[str] = []
    for check in (
        check_files,
        check_protocol_locks,
        check_matrix_free_boundaries,
        check_decisions,
        check_exprb_replay,
        check_picard_replay,
    ):
        messages.extend(check())
    print("RESEARCH_EVIDENCE_VERIFICATION: PASS")
    for message in messages:
        print(f"- {message}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
