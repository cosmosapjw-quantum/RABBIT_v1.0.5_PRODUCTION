# Start Here — RABBIT F10 solver/algorithm research package

## Read first

1. `RABBIT_F10_SOLVER_ALGORITHM_RESEARCH_SUMMARY_KO.md`
2. `RABBIT_F10_SOLVER_ALGORITHM_RESEARCH_REPORT.md`
3. `SCIENTIFIC_CONTRACT.md`
4. `FORMAL_SWEEP_PROTOCOL.md`
5. `reports/RABBIT_SOURCE_INTEGRATION_PR_PLAN.md`

## Reproduce the package

```bash
python -m pytest -q
python tools/validate_harness.py
python tools/verify_research_evidence.py
python scripts/generate_research_figures.py
```

Expected software result: `38 passed` and both validators PASS.

## Current status

- `EC-EXPRB-K`: formal synthetic survivor
- `EC-PICARD-IE`: secondary post-formal synthetic survivor
- physical RABBIT prefix: not run
- D-071: remains FAIL

No original RABBIT source or gate was modified by this package.
