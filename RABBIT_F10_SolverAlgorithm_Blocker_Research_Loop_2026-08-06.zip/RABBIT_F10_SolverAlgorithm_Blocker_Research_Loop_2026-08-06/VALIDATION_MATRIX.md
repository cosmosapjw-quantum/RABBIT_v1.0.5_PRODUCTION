# VALIDATION_MATRIX.md

| Requirement | Test/check | Level | Expected | Status | Evidence |
|---|---|---|---|---|---|
| import 가능 | package/tests smoke import | software | pass | PASS | `pytest -q`: 38 passed |
| 핵심 기능 | grids, manufactured model, JVP, JFNK, EXPRB, MLPC, Picard | software | pass | PASS | `tests/` |
| 기존 동작 | characterization and formal v1→v2 status comparison | software | unchanged | PASS | all candidate statuses unchanged |
| 단위 일관성 | dimensionless benchmark + explicit RABBIT mapping | scientific | explicit/exact | PASS | `SCIENTIFIC_CONTRACT.md`, scientific report |
| 알려진 극한 | linear `expm`, exact path, identity transfer | scientific | within tolerance | PASS | 38-test suite |
| 보존법칙 | energy-constrained lanes + raw negative controls | scientific | `1e-10/1e-7` | PASS | formal/post-formal JSON |
| 수렴성 | EXPRB step-halving ladder | numerical | order `>=1.6` | PASS | measured 1.994–2.109 |
| 안정성 | cancellation, Krylov, resolution, ratchet ladders | numerical | bounded region identified | PASS | `results/postformal/` |
| 재현성 | same-host endpoint/counter replay | operational | bitwise | PASS | `tools/verify_research_evidence.py` |
| 성능 | full-RHS call/wall discriminator | operational | `<5500`, `<64800 s` | PASS for EC-EXPRB-K and EC-PICARD-IE synthetic lanes | 352/3,960 s; 4,001/45,011.25 s |
| memory | monitored peak RSS | operational | `<2 GiB` | PASS | ≤~165 MB for survivors |
| protocol chronology | digest locks | governance | exact | PASS | formal/post-formal SHA-256 checks |
| independent diff review | hidden Jacobian/fallback/claim audit | review | no material undisclosed defect | PASS WITH CONCERNS | `reports/INDEPENDENT_DIFF_REVIEW.md` |
| physical RABBIT prefix | original collision RHS | scientific | required before reopen | NOT_RUN | future PR-SA05 |
| D-071 gate movement | independent adjudication | governance | only after physical evidence | NOT_APPLICABLE | gate remains FAIL |

Status vocabulary: `PASS / PASS WITH CONCERNS / CONCERN / FAIL / NOT_RUN / NOT_APPLICABLE`.
