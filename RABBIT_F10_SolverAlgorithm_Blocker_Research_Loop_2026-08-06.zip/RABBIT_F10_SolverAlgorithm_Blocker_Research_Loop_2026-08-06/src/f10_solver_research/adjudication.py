from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal


@dataclass(frozen=True)
class GateThresholds:
    noiseless_endpoint_wrms: float = 2.0e-5
    cancellation_endpoint_wrms: float = 2.0e-4
    noiseless_energy_residual: float = 1.0e-10
    cancellation_energy_residual: float = 1.0e-7
    rhs_call_budget: int = 5500
    scaling_exponent_max: float = 1.35
    call_cost_seconds_p95: float = 4.5
    safety_factor: float = 2.5
    wall_budget_seconds: float = 64800.0
    peak_rss_bytes_max: int = 2 * 1024**3


@dataclass(frozen=True)
class CandidateMetrics:
    name: str
    success: bool
    finite: bool
    occupations_valid: bool
    matrix_free: bool
    control_only: bool
    endpoint_wrms: float
    cancellation_endpoint_wrms: float
    energy_residual: float
    cancellation_energy_residual: float
    rhs_calls: float
    scaling_exponent: float
    deterministic: bool
    peak_rss_bytes: int


@dataclass(frozen=True)
class CandidateDecision:
    name: str
    status: Literal["SURVIVE", "REWORK", "KILL"]
    gates: dict[str, bool]
    reasons: list[str]
    projected_wall_seconds: float
    metrics: CandidateMetrics
    thresholds: GateThresholds

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "status": self.status,
            "gates": dict(self.gates),
            "reasons": list(self.reasons),
            "projected_wall_seconds": self.projected_wall_seconds,
            "metrics": asdict(self.metrics),
            "thresholds": asdict(self.thresholds),
        }


def projected_wall_seconds(
    rhs_calls: float, thresholds: GateThresholds = GateThresholds()
) -> float:
    return (
        float(rhs_calls)
        * float(thresholds.call_cost_seconds_p95)
        * float(thresholds.safety_factor)
    )


def adjudicate_candidate(
    metrics: CandidateMetrics,
    thresholds: GateThresholds = GateThresholds(),
) -> CandidateDecision:
    wall = projected_wall_seconds(metrics.rhs_calls, thresholds)
    gates: dict[str, bool] = {
        "scope": bool(metrics.matrix_free and not metrics.control_only),
        "completion": bool(metrics.success),
        "finite": bool(metrics.finite),
        "occupations": bool(metrics.occupations_valid),
        "noiseless_accuracy": bool(
            metrics.endpoint_wrms <= thresholds.noiseless_endpoint_wrms
        ),
        "cancellation_accuracy": bool(
            metrics.cancellation_endpoint_wrms
            <= thresholds.cancellation_endpoint_wrms
        ),
        "noiseless_energy": bool(
            metrics.energy_residual <= thresholds.noiseless_energy_residual
        ),
        "cancellation_energy": bool(
            metrics.cancellation_energy_residual
            <= thresholds.cancellation_energy_residual
        ),
        "call_budget": bool(metrics.rhs_calls <= thresholds.rhs_call_budget),
        "scaling": bool(
            metrics.scaling_exponent <= thresholds.scaling_exponent_max
        ),
        "projected_wall": bool(wall < thresholds.wall_budget_seconds),
        "determinism": bool(metrics.deterministic),
        "memory": bool(metrics.peak_rss_bytes < thresholds.peak_rss_bytes_max),
    }

    reason_text = {
        "scope": "candidate is a diagnostic control or relies on a supplied Jacobian",
        "completion": "solver did not reach the requested endpoint",
        "finite": "nonfinite state or metric was produced",
        "occupations": "occupation reconstruction left the strict-open domain",
        "noiseless_accuracy": "noiseless endpoint error exceeds the frozen band",
        "cancellation_accuracy": "cancellation-oracle endpoint error exceeds the frozen band",
        "noiseless_energy": "noiseless energy identity exceeds the frozen band",
        "cancellation_energy": "cancellation-oracle energy identity exceeds the frozen band",
        "call_budget": "full-RHS-equivalent call count exceeds 5500",
        "scaling": "order-48 to order-96 call scaling exceeds the frozen exponent",
        "projected_wall": "projected wall time exceeds the 64,800 s budget",
        "determinism": "same-environment rerun was not bitwise deterministic",
        "memory": "peak RSS exceeds 2 GiB",
    }
    reasons = [
        f"{gate}:{reason_text[gate]}" for gate, passed in gates.items() if not passed
    ]

    fatal = {
        "scope",
        "completion",
        "finite",
        "occupations",
        "determinism",
    }
    status: Literal["SURVIVE", "REWORK", "KILL"]
    if all(gates.values()):
        status = "SURVIVE"
    elif any(not gates[name] for name in fatal):
        status = "KILL"
    else:
        ratios = [
            metrics.endpoint_wrms / thresholds.noiseless_endpoint_wrms,
            metrics.cancellation_endpoint_wrms
            / thresholds.cancellation_endpoint_wrms,
            metrics.energy_residual / thresholds.noiseless_energy_residual,
            metrics.cancellation_energy_residual
            / thresholds.cancellation_energy_residual,
            float(metrics.rhs_calls) / thresholds.rhs_call_budget,
            metrics.scaling_exponent / thresholds.scaling_exponent_max,
            wall / thresholds.wall_budget_seconds,
            float(metrics.peak_rss_bytes) / thresholds.peak_rss_bytes_max,
        ]
        status = "KILL" if max(ratios) > 10.0 else "REWORK"

    return CandidateDecision(
        name=metrics.name,
        status=status,
        gates=gates,
        reasons=reasons,
        projected_wall_seconds=wall,
        metrics=metrics,
        thresholds=thresholds,
    )
