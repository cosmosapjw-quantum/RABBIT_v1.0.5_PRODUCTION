from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.linalg import expm
from scipy.special import expit

from .grids import Grid

Array = np.ndarray


@dataclass(frozen=True)
class LinearNonnormalModel:
    size: int
    decay: float = 5.75
    nonnormal_strength: float = 12.0
    matrix: Array = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if int(self.size) < 2:
            raise ValueError("size must be at least two")
        diagonal = -(
            float(self.decay) + 0.15 * np.arange(int(self.size), dtype=np.float64)
        )
        matrix = np.diag(diagonal)
        i, j = np.indices((int(self.size), int(self.size)))
        upper = j > i
        matrix[upper] += (
            float(self.nonnormal_strength)
            * np.exp(-(j[upper] - i[upper]) / 3.0)
            / np.sqrt(float(self.size))
        )
        object.__setattr__(self, "matrix", matrix)

    def rhs(self, t: float, y: Array) -> Array:
        del t
        return self.matrix @ np.asarray(y, dtype=np.float64)

    def jacobian(self, t: float, y: Array) -> Array:
        del t, y
        return self.matrix.copy()

    def exact(self, t: float, y0: Array) -> Array:
        return expm(float(t) * self.matrix) @ np.asarray(y0, dtype=np.float64)


@dataclass
class ManufacturedKineticModel:
    grid: Grid
    cancellation_scale: float = 0.0
    nonnormal_strength: float = 7.5
    nonlinear_strength: float = 0.035
    species: int = 3

    def __post_init__(self) -> None:
        if self.species != 3:
            raise ValueError("the research benchmark fixes three spectral blocks")
        self.spectral_size = self.species * self.grid.order
        self.state_size = self.spectral_size + 2
        q = np.tile(self.grid.nodes, self.species)
        species_index = np.repeat(np.arange(self.species), self.grid.order)
        decay = 5.75 + 0.035 * q + 0.18 * species_index
        base = -np.diag(decay)
        i, j = np.indices((self.spectral_size, self.spectral_size))
        upper = j > i
        base[upper] += (
            self.nonnormal_strength
            * np.exp(-(j[upper] - i[upper]) / 11.0)
            / np.sqrt(float(self.spectral_size))
        )
        self._base_operator = np.asarray(base, dtype=np.float64)
        species_sign = np.take(np.array([1.0, -0.45, -0.45]), species_index)
        self._energy_coupling = (
            0.045 * species_sign * np.exp(-q / max(0.5 * self.grid.y_max, 1.0))
        )
        energy_weights_one = self.grid.weights * self.grid.nodes**3
        energy_weights_one /= np.sum(energy_weights_one)
        self._energy_weights = np.tile(energy_weights_one / self.species, self.species)
        self._q_tiled = q
        self._species_index = species_index
        self._initial_total_energy = 0.19

    def _epoch_factor(self, t: float) -> float:
        return 1.0 + 0.18 * np.exp(-3.0 * float(t))

    def spectral_operator(self, t: float) -> Array:
        return self._epoch_factor(t) * self._base_operator

    def _shape(self) -> Array:
        amplitudes = np.take(np.array([0.013, 0.0062, 0.0062]), self._species_index)
        return amplitudes * np.exp(-self._q_tiled / 7.0) * (
            1.0 + 0.12 * np.cos(0.7 * self._q_tiled)
        )

    def _time_factor(self, t: float) -> float:
        return 1.0 - np.exp(-0.82 * float(t))

    def _time_factor_derivative(self, t: float) -> float:
        return 0.82 * np.exp(-0.82 * float(t))

    def exact_spectral(self, t: float) -> Array:
        return self._shape() * self._time_factor(t)

    def exact_spectral_derivative(self, t: float) -> Array:
        return self._shape() * self._time_factor_derivative(t)

    def trace_source(self, t: float) -> float:
        return 0.021 * np.exp(-float(t))

    def trace_integral(self, t: float) -> float:
        return 0.021 * (1.0 - np.exp(-float(t)))

    def exact_energy(self, t: float) -> float:
        return float(
            self._initial_total_energy
            + self.trace_integral(t)
            - self._energy_weights @ self.exact_spectral(t)
        )

    def exact_state(self, t: float) -> Array:
        return np.concatenate(
            (
                self.exact_spectral(t),
                [self.exact_energy(t), np.expm1(float(t))],
            )
        )

    def exact_derivative(self, t: float) -> Array:
        du = self.exact_spectral_derivative(t)
        de = self.trace_source(t) - float(self._energy_weights @ du)
        return np.concatenate((du, [de, np.exp(float(t))]))

    def _forcing(self, t: float) -> Array:
        u = self.exact_spectral(t)
        energy = self.exact_energy(t)
        return (
            self.exact_spectral_derivative(t)
            - self.spectral_operator(t) @ u
            - self._energy_coupling * energy
            - self.nonlinear_strength * np.tanh(u)
        )

    def rhs_true(self, t: float, y: Array) -> Array:
        values = np.asarray(y, dtype=np.float64)
        if values.ndim == 1:
            if values.shape != (self.state_size,):
                raise ValueError("state has wrong shape")
            u = values[: self.spectral_size]
            energy = float(values[self.spectral_size])
            du = (
                self.spectral_operator(t) @ u
                + self._energy_coupling * energy
                + self.nonlinear_strength * np.tanh(u)
                + self._forcing(t)
            )
            de = self.trace_source(t) - float(self._energy_weights @ du)
            return np.concatenate((du, [de, np.exp(float(t))]))
        if values.ndim == 2:
            if values.shape[0] != self.state_size:
                raise ValueError("vectorized state has wrong shape")
            u = values[: self.spectral_size]
            energy = values[self.spectral_size]
            du = (
                self.spectral_operator(t) @ u
                + self._energy_coupling[:, None] * energy[None, :]
                + self.nonlinear_strength * np.tanh(u)
                + self._forcing(t)[:, None]
            )
            de = self.trace_source(t) - self._energy_weights @ du
            clock = np.full(values.shape[1], np.exp(float(t)), dtype=np.float64)
            return np.vstack((du, de[None, :], clock[None, :]))
        raise ValueError("state must be one- or two-dimensional")

    def rhs_cancellation(self, t: float, y: Array) -> Array:
        true = self.rhs_true(t, y)
        if self.cancellation_scale <= 0.0:
            return true
        values = np.asarray(y, dtype=np.float64)
        if values.ndim == 1:
            index = np.arange(self.state_size, dtype=np.float64)
            base = self.cancellation_scale * (
                1.0 + 0.01 * np.sin(index + 0.37 * float(t))
            )
            result = (base + 0.5 * true) - (base - 0.5 * true)
            result[-1] = true[-1]
            return result
        index = np.arange(self.state_size, dtype=np.float64)[:, None]
        base = self.cancellation_scale * (
            1.0 + 0.01 * np.sin(index + 0.37 * float(t))
        )
        result = (base + 0.5 * true) - (base - 0.5 * true)
        result[-1] = true[-1]
        return result

    def rhs(self, t: float, y: Array) -> Array:
        if self.cancellation_scale > 0.0:
            return self.rhs_cancellation(t, y)
        return self.rhs_true(t, y)

    def jacobian(self, t: float, y: Array) -> Array:
        values = np.asarray(y, dtype=np.float64)
        if values.shape != (self.state_size,):
            raise ValueError("state has wrong shape")
        u = values[: self.spectral_size]
        spectral = self.spectral_operator(t).copy()
        spectral.flat[:: self.spectral_size + 1] += (
            self.nonlinear_strength / np.cosh(u) ** 2
        )
        jac = np.zeros((self.state_size, self.state_size), dtype=np.float64)
        jac[: self.spectral_size, : self.spectral_size] = spectral
        jac[: self.spectral_size, self.spectral_size] = self._energy_coupling
        jac[self.spectral_size, : self.spectral_size] = -self._energy_weights @ spectral
        jac[self.spectral_size, self.spectral_size] = -float(
            self._energy_weights @ self._energy_coupling
        )
        return jac

    def occupations(self, y: Array) -> Array:
        values = np.asarray(y, dtype=np.float64)
        if values.shape != (self.state_size,):
            raise ValueError("state has wrong shape")
        u = values[: self.spectral_size].reshape(self.species, self.grid.order)
        logits = -self.grid.nodes[None, :] + u
        occupation = expit(logits)
        if not np.all(np.isfinite(occupation)):
            raise FloatingPointError("nonfinite occupation")
        return occupation

    def project_energy_identity(self, t: float, y: Array) -> Array:
        """Project only the energy scalar onto the manufactured invariant."""

        values = np.asarray(y, dtype=np.float64)
        if values.shape != (self.state_size,) or not np.all(np.isfinite(values)):
            raise ValueError("state has wrong shape or nonfinite data")
        projected = values.copy()
        projected[self.spectral_size] -= self.energy_identity_residual(t, values)
        return projected

    def energy_identity_residual(self, t: float, y: Array) -> float:
        values = np.asarray(y, dtype=np.float64)
        if values.shape != (self.state_size,):
            raise ValueError("state has wrong shape")
        total = float(
            values[self.spectral_size]
            + self._energy_weights @ values[: self.spectral_size]
        )
        expected = self._initial_total_energy + self.trace_integral(t)
        return total - expected

    @property
    def energy_weights(self) -> Array:
        return self._energy_weights.copy()

    @property
    def energy_coupling(self) -> Array:
        return self._energy_coupling.copy()
