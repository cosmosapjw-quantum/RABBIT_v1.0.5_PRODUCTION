from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Literal

import numpy as np

Array = np.ndarray


@dataclass(frozen=True)
class ArnoldiResult:
    basis: Array
    hessenberg: Array
    beta: float
    dimension: int
    breakdown: bool


def finite_difference_jvp(
    fun: Callable[[float, Array], Array],
    t: float,
    y: Array,
    fy: Array,
    direction: Array,
    *,
    relative_step: float = np.sqrt(np.finfo(np.float64).eps),
    scheme: Literal["forward", "central"] = "forward",
) -> tuple[Array, float]:
    """Evaluate ``J(y) v`` with a fixed, nonpersistent directional step rule."""

    state = np.asarray(y, dtype=np.float64)
    base = np.asarray(fy, dtype=np.float64)
    vector = np.asarray(direction, dtype=np.float64)
    if state.ndim != 1 or base.shape != state.shape or vector.shape != state.shape:
        raise ValueError("y, fy, and direction must be equal-length vectors")
    if not all(np.all(np.isfinite(item)) for item in (state, base, vector)):
        raise ValueError("JVP inputs must be finite")
    vector_norm = float(np.linalg.norm(vector))
    if vector_norm == 0.0:
        return np.zeros_like(state), 0.0
    if not np.isfinite(relative_step) or relative_step <= 0.0:
        raise ValueError("relative_step must be finite and positive")
    step = float(relative_step) * max(1.0, float(np.linalg.norm(state))) / vector_norm
    if scheme == "forward":
        shifted = np.asarray(fun(float(t), state + step * vector), dtype=np.float64)
        result = (shifted - base) / step
    elif scheme == "central":
        plus = np.asarray(fun(float(t), state + step * vector), dtype=np.float64)
        minus = np.asarray(fun(float(t), state - step * vector), dtype=np.float64)
        result = (plus - minus) / (2.0 * step)
    else:
        raise ValueError(f"unknown JVP scheme {scheme!r}")
    if result.shape != state.shape or not np.all(np.isfinite(result)):
        raise FloatingPointError("JVP returned nonfinite or wrong-shaped data")
    return result, step


def arnoldi(
    operator: Callable[[Array], Array],
    start: Array,
    *,
    max_dim: int,
    tolerance: float = 1e-12,
) -> ArnoldiResult:
    """Modified Gram--Schmidt Arnoldi with one reorthogonalization pass."""

    vector = np.asarray(start, dtype=np.float64)
    if vector.ndim != 1 or not np.all(np.isfinite(vector)):
        raise ValueError("Arnoldi start vector must be finite and one-dimensional")
    if int(max_dim) < 1 or int(max_dim) > vector.size:
        raise ValueError("max_dim must lie in [1, len(start)]")
    beta = float(np.linalg.norm(vector))
    if beta == 0.0:
        return ArnoldiResult(
            basis=np.zeros((vector.size, 0), dtype=np.float64),
            hessenberg=np.zeros((1, 0), dtype=np.float64),
            beta=0.0,
            dimension=0,
            breakdown=True,
        )

    basis = np.zeros((vector.size, int(max_dim) + 1), dtype=np.float64)
    hessenberg = np.zeros((int(max_dim) + 1, int(max_dim)), dtype=np.float64)
    basis[:, 0] = vector / beta
    dimension = 0
    breakdown = False

    for column in range(int(max_dim)):
        work = np.asarray(operator(basis[:, column]), dtype=np.float64)
        if work.shape != vector.shape or not np.all(np.isfinite(work)):
            raise FloatingPointError("Arnoldi operator returned invalid data")
        # Two MGS passes reduce loss of orthogonality for nonnormal operators.
        for _ in range(2):
            coefficients = basis[:, : column + 1].T @ work
            hessenberg[: column + 1, column] += coefficients
            work -= basis[:, : column + 1] @ coefficients
        next_norm = float(np.linalg.norm(work))
        hessenberg[column + 1, column] = next_norm
        dimension = column + 1
        scale = max(1.0, float(np.linalg.norm(hessenberg[: column + 1, column])))
        if next_norm <= float(tolerance) * scale:
            breakdown = True
            break
        if column + 1 < int(max_dim):
            basis[:, column + 1] = work / next_norm

    return ArnoldiResult(
        basis=basis[:, :dimension],
        hessenberg=hessenberg[: dimension + 1, :dimension],
        beta=beta,
        dimension=dimension,
        breakdown=breakdown,
    )
