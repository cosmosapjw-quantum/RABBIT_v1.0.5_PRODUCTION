"""Research-only solver prototypes for the F10 blocker study."""
