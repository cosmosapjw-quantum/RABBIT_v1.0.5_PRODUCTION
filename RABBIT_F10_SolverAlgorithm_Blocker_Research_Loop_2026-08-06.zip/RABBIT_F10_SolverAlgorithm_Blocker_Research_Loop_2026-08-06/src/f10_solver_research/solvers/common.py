from __future__ import annotations

import math

import numpy as np


def fixed_step_schedule(t_start: float, t_end: float, step_size: float) -> np.ndarray:
    """Return positive fixed steps with one exact terminal endpoint.

    The number of nominal steps is computed from the interval ratio rather than
    by repeatedly comparing an accumulated binary float with ``t_end``.  This
    prevents a spurious machine-epsilon terminal step when the mathematical
    interval is an integer multiple of the requested step size.
    """

    t0, t1, h = float(t_start), float(t_end), float(step_size)
    if not (np.isfinite(t0) and np.isfinite(t1) and t1 > t0):
        raise ValueError("time interval must be finite and increasing")
    if not np.isfinite(h) or h <= 0.0:
        raise ValueError("step_size must be finite and positive")
    interval = t1 - t0
    ratio = interval / h
    nearest = int(round(ratio))
    ratio_tolerance = 64.0 * np.finfo(np.float64).eps * max(1.0, abs(ratio))
    if nearest >= 1 and abs(ratio - nearest) <= ratio_tolerance:
        count = nearest
    else:
        count = int(math.floor(ratio)) + 1
    steps = np.full(count, h, dtype=np.float64)
    if count == 1:
        steps[0] = interval
    else:
        steps[-1] = interval - h * (count - 1)
    # Compensate NumPy's actual summation order so replayed endpoint arithmetic
    # lands exactly on the declared interval in this environment.
    for _ in range(3):
        steps[-1] += interval - float(np.sum(steps, dtype=np.float64))
    if not np.all(np.isfinite(steps)) or np.any(steps <= 0.0):
        raise FloatingPointError("fixed-step schedule contains an invalid step")
    return steps
