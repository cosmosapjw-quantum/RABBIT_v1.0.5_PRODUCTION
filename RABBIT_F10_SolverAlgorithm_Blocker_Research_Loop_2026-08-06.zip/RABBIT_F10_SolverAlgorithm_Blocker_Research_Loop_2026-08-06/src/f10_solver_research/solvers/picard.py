from __future__ import annotations

from time import perf_counter
from typing import Callable

import numpy as np

from ..contracts import Array, CallCounter, Rhs, SolverResult, SolverStats
from .common import fixed_step_schedule


def _wrms(values: Array) -> float:
    vector = np.asarray(values, dtype=np.float64)
    return float(np.linalg.norm(vector) / np.sqrt(vector.size))


def solve_implicit_euler_picard(
    fun: Rhs,
    t_span: tuple[float, float],
    y0: Array,
    *,
    step_size: float,
    fixed_point_tolerance: float = 1e-8,
    max_iterations: int = 4,
    state_projector: Callable[[float, Array], Array] | None = None,
) -> SolverResult:
    """Derivative-free conservative implicit-Euler fixed-point solver.

    The accepted state is the last iterate whose RHS was actually evaluated.
    Thus the corresponding RHS is reusable as the next predictor without an
    uncounted or redundant call.  Convergence is tested on the projected map
    ``Phi(z) = P[y_n + h f(t_{n+1}, z)]`` when a projector is supplied.
    """

    started = perf_counter()
    t0, t_end = map(float, t_span)
    initial = np.asarray(y0, dtype=np.float64)
    if initial.ndim != 1 or not np.all(np.isfinite(initial)):
        raise ValueError("y0 must be a finite vector")
    if not (np.isfinite(t0) and np.isfinite(t_end) and t_end > t0):
        raise ValueError("t_span must be finite and increasing")
    if not np.isfinite(step_size) or step_size <= 0.0:
        raise ValueError("step_size must be finite and positive")
    if not np.isfinite(fixed_point_tolerance) or fixed_point_tolerance <= 0.0:
        raise ValueError("fixed_point_tolerance must be finite and positive")
    if int(max_iterations) < 1:
        raise ValueError("max_iterations must be positive")

    counter = CallCounter()
    counted_fun = counter.wrap(fun)
    stats = SolverStats(
        extra={
            "fixed_point_iterations": 0,
            "fixed_point_iterations_per_step": [],
            "fixed_point_residuals": [],
            "projection_applications": 0,
            "projection_correction_norms": [],
        }
    )
    times = [t0]
    states = [initial.copy()]
    history: list[dict[str, float | int | str]] = []
    current_t = t0
    current = initial.copy()
    current_rhs = np.asarray(counted_fun(current_t, current), dtype=np.float64)
    if current_rhs.shape != current.shape or not np.all(np.isfinite(current_rhs)):
        stats.rhs_calls = counter.calls
        stats.wall_seconds = perf_counter() - started
        return SolverResult(
            False,
            "INVALID_INITIAL_RHS",
            np.asarray(times),
            np.column_stack(states),
            stats,
            history,
        )

    def project(t: float, candidate: Array) -> Array:
        values = np.asarray(candidate, dtype=np.float64)
        if state_projector is None:
            return values
        projected = np.asarray(state_projector(t, values), dtype=np.float64)
        if projected.shape != values.shape or not np.all(np.isfinite(projected)):
            raise FloatingPointError("state projector returned invalid data")
        stats.extra["projection_applications"] += 1
        stats.extra["projection_correction_norms"].append(
            float(np.linalg.norm(projected - values))
        )
        return projected

    schedule = fixed_step_schedule(t0, t_end, step_size)
    for step_index, scheduled_h in enumerate(schedule):
        h = float(scheduled_h)
        next_t = t_end if step_index == len(schedule) - 1 else current_t + h
        try:
            iterate = project(next_t, current + h * current_rhs)
        except FloatingPointError:
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(
                False,
                "INVALID_STATE_PROJECTOR",
                np.asarray(times),
                np.column_stack(states),
                stats,
                history,
            )

        accepted = False
        accepted_rhs: Array | None = None
        last_residual = np.inf
        iterations_this_step = 0
        for iteration in range(int(max_iterations)):
            evaluated_rhs = np.asarray(counted_fun(next_t, iterate), dtype=np.float64)
            stats.extra["fixed_point_iterations"] += 1
            iterations_this_step += 1
            if evaluated_rhs.shape != current.shape or not np.all(np.isfinite(evaluated_rhs)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - started
                return SolverResult(
                    False,
                    "INVALID_PICARD_RHS",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            try:
                mapped = project(next_t, current + h * evaluated_rhs)
            except FloatingPointError:
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - started
                return SolverResult(
                    False,
                    "INVALID_STATE_PROJECTOR",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            last_residual = _wrms(mapped - iterate)
            history.append(
                {
                    "event": "picard_iteration",
                    "step": stats.steps + 1,
                    "iteration": iteration + 1,
                    "t": next_t,
                    "h": h,
                    "fixed_point_residual": last_residual,
                }
            )
            if last_residual <= fixed_point_tolerance:
                accepted = True
                accepted_rhs = evaluated_rhs
                break
            iterate = mapped

        stats.extra["fixed_point_iterations_per_step"].append(iterations_this_step)
        stats.extra["fixed_point_residuals"].append(float(last_residual))
        if not accepted or accepted_rhs is None:
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(
                False,
                "PICARD_FAILED:iteration_limit",
                np.asarray(times),
                np.column_stack(states),
                stats,
                history,
            )

        current_t = next_t
        current = iterate.copy()
        current_rhs = accepted_rhs.copy()
        stats.steps += 1
        times.append(current_t)
        states.append(current.copy())
        history.append(
            {
                "event": "accepted_step",
                "step": stats.steps,
                "t": current_t,
                "h": h,
                "fixed_point_iterations": iterations_this_step,
                "fixed_point_residual": last_residual,
            }
        )

    stats.rhs_calls = counter.calls
    stats.wall_seconds = perf_counter() - started
    stats.extra["rhs_batch_widths"] = list(counter.batch_widths)
    return SolverResult(
        True,
        "COMPLETED",
        np.asarray(times, dtype=np.float64),
        np.column_stack(states),
        stats,
        history,
    )
