from __future__ import annotations

from time import perf_counter
from typing import Callable

import numpy as np
from scipy.linalg import expm

from ..contracts import Array, CallCounter, Rhs, SolverResult, SolverStats
from ..jvp import arnoldi
from .common import fixed_step_schedule


def _phi1_e1(matrix: Array) -> Array:
    dimension = matrix.shape[0]
    augmented = np.zeros((dimension + 1, dimension + 1), dtype=np.float64)
    augmented[:dimension, :dimension] = matrix
    augmented[0, dimension] = 1.0
    return expm(augmented)[:dimension, dimension]


def solve_exprb_krylov(
    fun: Rhs,
    t_span: tuple[float, float],
    y0: Array,
    *,
    step_size: float,
    krylov_dim: int = 20,
    jvp_relative_step: float = 1e-6,
    arnoldi_tolerance: float = 1e-12,
    state_projector: Callable[[float, Array], Array] | None = None,
) -> SolverResult:
    """Fixed-step nonautonomous exponential Rosenbrock--Krylov prototype.

    Time is appended as an auxiliary state with derivative one, so each Arnoldi
    basis approximates the action of the augmented Jacobian on ``[f(t,y), 1]``.
    The only derivative information comes from a fresh directional difference;
    no persistent finite-difference lifetime is carried across calls or steps.
    """

    started = perf_counter()
    t0, t_end = map(float, t_span)
    initial = np.asarray(y0, dtype=np.float64)
    if initial.ndim != 1 or not np.all(np.isfinite(initial)):
        raise ValueError("y0 must be a finite vector")
    if not (np.isfinite(t0) and np.isfinite(t_end) and t_end > t0):
        raise ValueError("t_span must be finite and increasing")
    if not np.isfinite(step_size) or step_size <= 0.0:
        raise ValueError("step_size must be finite and positive")
    augmented_size = initial.size + 1
    if int(krylov_dim) < 1 or int(krylov_dim) > augmented_size:
        raise ValueError("krylov_dim must lie in [1, state_size + 1]")
    if min(jvp_relative_step, arnoldi_tolerance) <= 0.0:
        raise ValueError("difference and Arnoldi tolerances must be positive")

    counter = CallCounter()
    counted_fun = counter.wrap(fun)
    stats = SolverStats(
        extra={
            "arnoldi_dimensions": [],
            "arnoldi_breakdowns": 0,
            "projected_ie_defects": [],
            "time_component_defects": [],
            "projection_applications": 0,
            "projection_correction_norms": [],
        }
    )
    times = [t0]
    states = [initial.copy()]
    history: list[dict[str, float | int | str | bool]] = []
    current_t = t0
    current = initial.copy()
    step_schedule = fixed_step_schedule(t0, t_end, step_size)

    for step_index, scheduled_h in enumerate(step_schedule):
        h = float(scheduled_h)
        next_t = t_end if step_index == len(step_schedule) - 1 else current_t + h

        base_rhs = np.asarray(counted_fun(current_t, current), dtype=np.float64)
        if base_rhs.shape != current.shape or not np.all(np.isfinite(base_rhs)):
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(False, "INVALID_RHS", np.asarray(times), np.column_stack(states), stats, history)

        augmented_state = np.concatenate((current, [current_t]))
        start_vector = np.concatenate((base_rhs, [1.0]))

        def augmented_operator(vector: Array) -> Array:
            direction = np.asarray(vector, dtype=np.float64)
            norm = float(np.linalg.norm(direction))
            if norm == 0.0:
                return np.zeros_like(direction)
            epsilon = (
                float(jvp_relative_step)
                * max(1.0, float(np.linalg.norm(augmented_state)))
                / norm
            )
            shifted_t = current_t + epsilon * float(direction[-1])
            shifted_y = current + epsilon * direction[:-1]
            shifted_rhs = np.asarray(counted_fun(shifted_t, shifted_y), dtype=np.float64)
            if shifted_rhs.shape != current.shape or not np.all(np.isfinite(shifted_rhs)):
                raise FloatingPointError("invalid RHS in augmented JVP")
            stats.jacobian_vector_products += 1
            return np.concatenate(((shifted_rhs - base_rhs) / epsilon, [0.0]))

        try:
            decomposition = arnoldi(
                augmented_operator,
                start_vector,
                max_dim=int(krylov_dim),
                tolerance=float(arnoldi_tolerance),
            )
        except (FloatingPointError, ValueError) as error:
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(
                False,
                f"ARNOLDI_FAILED:{type(error).__name__}",
                np.asarray(times),
                np.column_stack(states),
                stats,
                history,
            )

        stats.extra["arnoldi_dimensions"].append(int(decomposition.dimension))
        if decomposition.breakdown:
            stats.extra["arnoldi_breakdowns"] += 1

        if decomposition.dimension == 0:
            update_augmented = np.zeros(augmented_size, dtype=np.float64)
            update_augmented[-1] = h
            projected_defect = 0.0
        else:
            m = decomposition.dimension
            basis = decomposition.basis[:, :m]
            reduced = decomposition.hessenberg[:m, :m]
            phi_action = _phi1_e1(h * reduced)
            update_augmented = h * decomposition.beta * (basis @ phi_action)
            try:
                implicit_action = np.linalg.solve(
                    np.identity(m, dtype=np.float64) - h * reduced,
                    np.eye(m, dtype=np.float64)[:, 0],
                )
            except np.linalg.LinAlgError:
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - started
                return SolverResult(
                    False,
                    "PROJECTED_IE_SINGULAR",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            implicit_update = h * decomposition.beta * (basis @ implicit_action)
            projected_defect = float(
                np.linalg.norm(update_augmented[:-1] - implicit_update[:-1])
                / np.sqrt(current.size)
            )

        if not np.all(np.isfinite(update_augmented)):
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(False, "NONFINITE_UPDATE", np.asarray(times), np.column_stack(states), stats, history)

        time_defect = float(update_augmented[-1] - h)
        unprojected = current + update_augmented[:-1]
        current_t = next_t
        if state_projector is None:
            current = unprojected
        else:
            current = np.asarray(state_projector(current_t, unprojected), dtype=np.float64)
            if current.shape != unprojected.shape or not np.all(np.isfinite(current)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - started
                return SolverResult(False, "INVALID_STATE_PROJECTOR", np.asarray(times), np.column_stack(states), stats, history)
            stats.extra["projection_applications"] += 1
            stats.extra["projection_correction_norms"].append(
                float(np.linalg.norm(current - unprojected))
            )
        if not np.all(np.isfinite(current)):
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - started
            return SolverResult(False, "NONFINITE_STATE", np.asarray(times), np.column_stack(states), stats, history)

        stats.steps += 1
        stats.extra["projected_ie_defects"].append(projected_defect)
        stats.extra["time_component_defects"].append(time_defect)
        times.append(current_t)
        states.append(current.copy())
        history.append(
            {
                "event": "accepted_step",
                "step": stats.steps,
                "t": current_t,
                "h": h,
                "arnoldi_dimension": decomposition.dimension,
                "arnoldi_breakdown": decomposition.breakdown,
                "projected_ie_defect": projected_defect,
                "time_component_defect": time_defect,
            }
        )

    stats.rhs_calls = counter.calls
    stats.wall_seconds = perf_counter() - started
    stats.extra["rhs_batch_widths"] = list(counter.batch_widths)
    return SolverResult(
        True,
        "COMPLETED",
        np.asarray(times, dtype=np.float64),
        np.column_stack(states),
        stats,
        history,
    )
