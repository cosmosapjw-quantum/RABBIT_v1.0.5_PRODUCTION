from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Callable, Protocol

import numpy as np
from scipy.sparse.linalg import LinearOperator, gmres

from ..contracts import Array, CallCounter, Rhs, SolverResult, SolverStats
from ..jvp import finite_difference_jvp
from .common import fixed_step_schedule


class PreconditionerFactory(Protocol):
    def __call__(
        self, t: float, state: Array, step_size: float
    ) -> Callable[[Array], Array]: ...


@dataclass(frozen=True)
class _ResidualEvaluation:
    value: Array
    rhs: Array
    norm: float


def _weighted_norm(residual: Array, state: Array, *, atol: float, rtol: float) -> float:
    scale = float(atol) + float(rtol) * np.maximum(1.0, np.abs(state))
    return float(np.linalg.norm(residual / scale) / np.sqrt(residual.size))


def solve_implicit_euler_jfnk(
    fun: Rhs,
    t_span: tuple[float, float],
    y0: Array,
    *,
    step_size: float,
    newton_rtol: float = 1e-8,
    newton_atol: float = 1e-10,
    max_newton_iterations: int = 8,
    gmres_rtol: float = 1e-7,
    max_linear_iterations: int = 80,
    jvp_relative_step: float = 1e-7,
    line_search_min: float = 2.0**-10,
    preconditioner_factory: PreconditionerFactory | None = None,
    step_predictor: Callable[[float, Array, float, Array], Array] | None = None,
    state_projector: Callable[[float, Array], Array] | None = None,
) -> SolverResult:
    """Fixed-step implicit Euler solved by globalized matrix-free JFNK.

    The candidate sees only the black-box RHS.  A supplied preconditioner may
    use declared auxiliary structure, but the nonlinear residual is always the
    exact fine residual ``z - y_n - h f(t_{n+1}, z)``.
    """

    start_wall = perf_counter()
    t0, t_end = map(float, t_span)
    state0 = np.asarray(y0, dtype=np.float64)
    if state0.ndim != 1 or not np.all(np.isfinite(state0)):
        raise ValueError("y0 must be a finite vector")
    if not (np.isfinite(t0) and np.isfinite(t_end) and t_end > t0):
        raise ValueError("t_span must be finite and increasing")
    if not np.isfinite(step_size) or step_size <= 0.0:
        raise ValueError("step_size must be finite and positive")
    if min(newton_rtol, newton_atol, gmres_rtol, jvp_relative_step) <= 0.0:
        raise ValueError("solver tolerances must be positive")
    if int(max_newton_iterations) < 1 or int(max_linear_iterations) < 1:
        raise ValueError("iteration limits must be positive")
    if not (0.0 < line_search_min <= 1.0):
        raise ValueError("line_search_min must lie in (0, 1]")

    counter = CallCounter()
    counted_fun = counter.wrap(fun)
    stats = SolverStats(
        extra={
            "preconditioner_applications": 0,
            "projection_applications": 0,
            "projection_correction_norms": [],
        }
    )
    times: list[float] = [t0]
    states: list[Array] = [state0.copy()]
    history: list[dict[str, float | int | str]] = []

    current_t = t0
    current = state0.copy()
    current_rhs = np.asarray(counted_fun(current_t, current), dtype=np.float64)
    if current_rhs.shape != current.shape or not np.all(np.isfinite(current_rhs)):
        stats.rhs_calls = counter.calls
        stats.wall_seconds = perf_counter() - start_wall
        return SolverResult(False, "INVALID_INITIAL_RHS", np.asarray(times), np.column_stack(states), stats, history)

    step_schedule = fixed_step_schedule(t0, t_end, step_size)
    for step_index, scheduled_h in enumerate(step_schedule):
        h = float(scheduled_h)
        next_t = t_end if step_index == len(step_schedule) - 1 else current_t + h
        if step_predictor is None:
            predictor = current + h * current_rhs
        else:
            predictor = np.asarray(
                step_predictor(next_t, current.copy(), h, current_rhs.copy()),
                dtype=np.float64,
            )
            if predictor.shape != current.shape or not np.all(np.isfinite(predictor)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    "INVALID_STEP_PREDICTOR",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
        iterate = predictor.copy()
        step_success = False
        accepted_rhs: Array | None = None

        def evaluate(candidate: Array) -> _ResidualEvaluation:
            rhs_value = np.asarray(counted_fun(next_t, candidate), dtype=np.float64)
            if rhs_value.shape != candidate.shape or not np.all(np.isfinite(rhs_value)):
                raise FloatingPointError("nonfinite RHS during Newton iteration")
            residual = candidate - current - h * rhs_value
            return _ResidualEvaluation(
                value=residual,
                rhs=rhs_value,
                norm=_weighted_norm(
                    residual, candidate, atol=newton_atol, rtol=newton_rtol
                ),
            )

        try:
            evaluation = evaluate(iterate)
        except FloatingPointError:
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - start_wall
            return SolverResult(False, "NONFINITE_NEWTON_RHS", np.asarray(times), np.column_stack(states), stats, history)

        for newton_index in range(int(max_newton_iterations)):
            stats.newton_iterations += 1
            if evaluation.norm <= 1.0:
                step_success = True
                accepted_rhs = evaluation.rhs
                break

            def matrix_vector(vector: Array) -> Array:
                jv, _ = finite_difference_jvp(
                    counted_fun,
                    next_t,
                    iterate,
                    evaluation.rhs,
                    vector,
                    relative_step=jvp_relative_step,
                    scheme="forward",
                )
                stats.jacobian_vector_products += 1
                return np.asarray(vector, dtype=np.float64) - h * jv

            dimension = current.size
            operator = LinearOperator(
                (dimension, dimension), matvec=matrix_vector, dtype=np.float64
            )
            preconditioner_operator: LinearOperator | None = None
            if preconditioner_factory is not None:
                apply_preconditioner = preconditioner_factory(next_t, iterate.copy(), h)

                def precondition(vector: Array) -> Array:
                    stats.extra["preconditioner_applications"] += 1
                    value = np.asarray(apply_preconditioner(np.asarray(vector, dtype=np.float64)), dtype=np.float64)
                    if value.shape != current.shape or not np.all(np.isfinite(value)):
                        raise FloatingPointError("preconditioner returned invalid data")
                    return value

                preconditioner_operator = LinearOperator(
                    (dimension, dimension), matvec=precondition, dtype=np.float64
                )

            linear_iterations = 0

            def linear_callback(_value: object) -> None:
                nonlocal linear_iterations
                linear_iterations += 1

            try:
                correction, info = gmres(
                    operator,
                    -evaluation.value,
                    rtol=max(float(gmres_rtol), 20.0 * np.finfo(np.float64).eps / float(jvp_relative_step)),
                    atol=0.0,
                    restart=min(40, dimension),
                    maxiter=int(max_linear_iterations),
                    M=preconditioner_operator,
                    callback=linear_callback,
                    callback_type="legacy",
                )
            except (FloatingPointError, ValueError, np.linalg.LinAlgError) as error:
                stats.linear_iterations += linear_iterations
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    f"GMRES_FAILED_EXCEPTION:{type(error).__name__}",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            stats.linear_iterations += linear_iterations
            if info != 0 or not np.all(np.isfinite(correction)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    f"GMRES_FAILED:info={int(info)}",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )

            damping = 1.0
            accepted_trial: _ResidualEvaluation | None = None
            while damping >= line_search_min:
                trial = iterate + damping * correction
                try:
                    trial_evaluation = evaluate(trial)
                except FloatingPointError:
                    trial_evaluation = None
                if trial_evaluation is not None and (
                    trial_evaluation.norm <= 1.0
                    or trial_evaluation.norm
                    <= (1.0 - 1.0e-4 * damping) * evaluation.norm
                ):
                    accepted_trial = trial_evaluation
                    iterate = trial
                    break
                damping *= 0.5
                stats.line_search_backtracks += 1

            if accepted_trial is None:
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    "LINE_SEARCH_FAILED",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            evaluation = accepted_trial
            history.append(
                {
                    "event": "newton",
                    "step": stats.steps + 1,
                    "iteration": newton_index + 1,
                    "t": next_t,
                    "h": h,
                    "residual_norm": evaluation.norm,
                    "damping": damping,
                    "linear_iterations": linear_iterations,
                }
            )

        if not step_success and evaluation.norm <= 1.0:
            step_success = True
            accepted_rhs = evaluation.rhs
        if not step_success:
            stats.rhs_calls = counter.calls
            stats.wall_seconds = perf_counter() - start_wall
            return SolverResult(
                False,
                "NEWTON_FAILED:iteration_limit",
                np.asarray(times),
                np.column_stack(states),
                stats,
                history,
            )

        current_t = next_t
        unprojected = iterate.copy()
        if state_projector is None:
            current = unprojected
            current_rhs = np.asarray(accepted_rhs, dtype=np.float64)
        else:
            current = np.asarray(state_projector(current_t, unprojected), dtype=np.float64)
            if current.shape != unprojected.shape or not np.all(np.isfinite(current)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    "INVALID_STATE_PROJECTOR",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
            correction_norm = float(np.linalg.norm(current - unprojected))
            stats.extra["projection_applications"] += 1
            stats.extra["projection_correction_norms"].append(correction_norm)
            current_rhs = np.asarray(counted_fun(current_t, current), dtype=np.float64)
            if current_rhs.shape != current.shape or not np.all(np.isfinite(current_rhs)):
                stats.rhs_calls = counter.calls
                stats.wall_seconds = perf_counter() - start_wall
                return SolverResult(
                    False,
                    "INVALID_PROJECTED_RHS",
                    np.asarray(times),
                    np.column_stack(states),
                    stats,
                    history,
                )
        stats.steps += 1
        times.append(current_t)
        states.append(current.copy())
        history.append(
            {
                "event": "accepted_step",
                "step": stats.steps,
                "t": current_t,
                "h": h,
                "residual_norm": evaluation.norm,
            }
        )

    stats.rhs_calls = counter.calls
    stats.wall_seconds = perf_counter() - start_wall
    stats.extra["rhs_batch_widths"] = list(counter.batch_widths)
    return SolverResult(
        True,
        "COMPLETED",
        np.asarray(times, dtype=np.float64),
        np.column_stack(states),
        stats,
        history,
    )
