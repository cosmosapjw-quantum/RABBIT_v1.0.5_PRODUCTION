from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy.integrate import solve_ivp

from ..contracts import Array, Rhs, SolverResult
from ..grids import TransferPair
from ..models import ManufacturedKineticModel
from .jfnk import solve_implicit_euler_jfnk


@dataclass
class CoarseTrajectoryPredictor:
    """Dense coarse trajectory prolonged into the fine state space."""

    transfer: TransferPair
    t_start: float
    t_end: float
    _solution: Callable[[float], Array] = field(repr=False)
    nfev: int = 0
    njev: int = 0
    nlu: int = 0

    @classmethod
    def build(
        cls,
        *,
        coarse_model: ManufacturedKineticModel,
        transfer: TransferPair,
        t_span: tuple[float, float],
        fine_initial: Array,
        rtol: float = 1e-9,
        atol: float = 1e-11,
    ) -> "CoarseTrajectoryPredictor":
        t0, t1 = map(float, t_span)
        if coarse_model.state_size != transfer.coarse_state_size:
            raise ValueError("coarse model and transfer state sizes disagree")
        initial = transfer.restrict_state(np.asarray(fine_initial, dtype=np.float64))
        solution = solve_ivp(
            coarse_model.rhs_true,
            (t0, t1),
            initial,
            method="Radau",
            jac=coarse_model.jacobian,
            rtol=float(rtol),
            atol=float(atol),
            dense_output=True,
        )
        if not solution.success or solution.sol is None:
            raise RuntimeError(f"coarse predictor failed: {solution.message}")
        return cls(
            transfer=transfer,
            t_start=t0,
            t_end=t1,
            _solution=solution.sol,
            nfev=int(solution.nfev),
            njev=int(solution.njev),
            nlu=int(solution.nlu),
        )

    def predict(self, t: float) -> Array:
        query = float(t)
        tolerance = 16.0 * np.finfo(np.float64).eps * max(1.0, abs(self.t_end))
        if query < self.t_start - tolerance or query > self.t_end + tolerance:
            raise ValueError("prediction time lies outside the coarse trajectory")
        coarse_state = np.asarray(self._solution(query), dtype=np.float64)
        if coarse_state.shape != (self.transfer.coarse_state_size,):
            raise RuntimeError("coarse dense output has the wrong shape")
        return self.transfer.prolong_state(coarse_state)


@dataclass
class TwoLevelPreconditioner:
    """Coarse correction plus diagonal smoothing on the fine complement."""

    transfer: TransferPair
    coarse_residual_matrix: Array
    fine_residual_diagonal: Array
    applications: int = 0

    def __post_init__(self) -> None:
        coarse = np.asarray(self.coarse_residual_matrix, dtype=np.float64)
        diagonal = np.asarray(self.fine_residual_diagonal, dtype=np.float64)
        if coarse.shape != (
            self.transfer.coarse_state_size,
            self.transfer.coarse_state_size,
        ):
            raise ValueError("coarse residual matrix has the wrong shape")
        if diagonal.shape != (self.transfer.fine_state_size,):
            raise ValueError("fine residual diagonal has the wrong shape")
        if not np.all(np.isfinite(coarse)) or not np.all(np.isfinite(diagonal)):
            raise ValueError("preconditioner data must be finite")
        if np.any(np.abs(diagonal) <= 100.0 * np.finfo(np.float64).tiny):
            raise ValueError("fine residual diagonal contains a zero pivot")
        self.coarse_residual_matrix = coarse
        self.fine_residual_diagonal = diagonal

    def apply(self, residual: Array) -> Array:
        vector = np.asarray(residual, dtype=np.float64)
        if vector.shape != (self.transfer.fine_state_size,):
            raise ValueError("preconditioner residual has the wrong shape")
        coarse_rhs = self.transfer.restrict_state(vector)
        try:
            coarse_correction = np.linalg.solve(
                self.coarse_residual_matrix, coarse_rhs
            )
        except np.linalg.LinAlgError as error:
            raise FloatingPointError("singular coarse residual operator") from error
        projected_rhs = self.transfer.prolong_state(coarse_rhs)
        low_correction = self.transfer.prolong_state(coarse_correction)
        high_correction = (
            vector - projected_rhs
        ) / self.fine_residual_diagonal
        result = low_correction + high_correction
        if not np.all(np.isfinite(result)):
            raise FloatingPointError("two-level preconditioner returned nonfinite data")
        self.applications += 1
        return result


def solve_mlpc_jfnk(
    *,
    fine_fun: Rhs,
    coarse_model: ManufacturedKineticModel,
    transfer: TransferPair,
    t_span: tuple[float, float],
    fine_initial: Array,
    step_size: float,
    fine_residual_diagonal: Callable[[float, Array, float], Array],
    predictor_rtol: float = 1e-9,
    predictor_atol: float = 1e-11,
    **jfnk_options: float | int,
) -> SolverResult:
    """Solve the exact fine implicit residual with a coarse nonlinear predictor.

    The coarse trajectory is used only for the initial Newton guess and the
    coarse block of a two-level preconditioner.  Convergence is still tested on
    the untouched fine residual inside :func:`solve_implicit_euler_jfnk`.
    """

    initial = np.asarray(fine_initial, dtype=np.float64)
    if initial.shape != (transfer.fine_state_size,):
        raise ValueError("fine_initial has the wrong shape")
    predictor = CoarseTrajectoryPredictor.build(
        coarse_model=coarse_model,
        transfer=transfer,
        t_span=t_span,
        fine_initial=initial,
        rtol=predictor_rtol,
        atol=predictor_atol,
    )
    built: list[TwoLevelPreconditioner] = []

    def step_predictor(
        next_t: float, current: Array, h: float, current_rhs: Array
    ) -> Array:
        del current, h, current_rhs
        return predictor.predict(next_t)

    def factory(t: float, fine_state: Array, h: float) -> Callable[[Array], Array]:
        coarse_state = transfer.restrict_state(fine_state)
        coarse_jacobian = coarse_model.jacobian(t, coarse_state)
        coarse_residual = (
            np.identity(transfer.coarse_state_size, dtype=np.float64)
            - h * coarse_jacobian
        )
        diagonal = np.asarray(
            fine_residual_diagonal(t, fine_state, h), dtype=np.float64
        )
        preconditioner = TwoLevelPreconditioner(
            transfer=transfer,
            coarse_residual_matrix=coarse_residual,
            fine_residual_diagonal=diagonal,
        )
        built.append(preconditioner)
        return preconditioner.apply

    result = solve_implicit_euler_jfnk(
        fine_fun,
        t_span,
        initial,
        step_size=step_size,
        preconditioner_factory=factory,
        step_predictor=step_predictor,
        **jfnk_options,
    )
    result.stats.extra.update(
        {
            "coarse_predictor_nfev": predictor.nfev,
            "coarse_predictor_njev": predictor.njev,
            "coarse_predictor_nlu": predictor.nlu,
            "two_level_builds": len(built),
            "two_level_applications": int(sum(item.applications for item in built)),
            "effective_rhs_calls_state_ratio": float(
                result.stats.rhs_calls
                + predictor.nfev
                * transfer.coarse_state_size
                / transfer.fine_state_size
            ),
        }
    )
    return result
