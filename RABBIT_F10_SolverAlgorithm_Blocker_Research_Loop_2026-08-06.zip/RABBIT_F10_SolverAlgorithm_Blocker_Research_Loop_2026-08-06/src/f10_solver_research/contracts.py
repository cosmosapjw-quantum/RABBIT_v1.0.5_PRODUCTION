from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, Callable

import numpy as np

Array = np.ndarray
Rhs = Callable[[float, Array], Array]


@dataclass
class CallCounter:
    """Count scalar-state RHS equivalents, including vectorized columns."""

    calls: int = 0
    wall_seconds: list[float] = field(default_factory=list)
    batch_widths: list[int] = field(default_factory=list)

    def wrap(self, fun: Rhs) -> Rhs:
        def counted(t: float, y: Array) -> Array:
            values = np.asarray(y)
            if values.ndim == 1:
                width = 1
            elif values.ndim == 2:
                width = int(values.shape[1])
            else:
                raise ValueError("RHS state must be one- or two-dimensional")
            started = perf_counter()
            result = fun(float(t), values)
            elapsed = perf_counter() - started
            self.calls += width
            self.wall_seconds.append(float(elapsed))
            self.batch_widths.append(width)
            return np.asarray(result)

        return counted

    def reset(self) -> None:
        self.calls = 0
        self.wall_seconds.clear()
        self.batch_widths.clear()


@dataclass
class SolverStats:
    rhs_calls: int = 0
    steps: int = 0
    rejected_steps: int = 0
    newton_iterations: int = 0
    linear_iterations: int = 0
    jacobian_vector_products: int = 0
    line_search_backtracks: int = 0
    wall_seconds: float = 0.0
    peak_rss_bytes: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class SolverResult:
    success: bool
    reason: str
    t: Array
    y: Array
    stats: SolverStats
    history: list[dict[str, Any]] = field(default_factory=list)

    @property
    def endpoint(self) -> Array:
        if self.y.ndim != 2 or self.y.shape[1] == 0:
            raise ValueError("solver result has no endpoint")
        return self.y[:, -1]
