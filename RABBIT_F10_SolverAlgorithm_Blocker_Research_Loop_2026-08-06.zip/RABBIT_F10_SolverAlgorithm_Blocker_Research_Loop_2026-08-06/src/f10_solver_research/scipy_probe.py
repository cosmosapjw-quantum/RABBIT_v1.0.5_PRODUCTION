from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.integrate._ivp.common import num_jac

Array = np.ndarray


@dataclass(frozen=True)
class NumJacRecord:
    refresh: int
    max_factor_over_sqrt_eps: float
    median_factor_over_sqrt_eps: float
    min_factor_over_sqrt_eps: float
    max_column_relative_error: float
    median_column_relative_error: float
    columns_over_one_percent: int


@dataclass(frozen=True)
class NumJacProbeResult:
    records: tuple[NumJacRecord, ...]
    final_factor: Array


def _column_relative_errors(approx: Array, exact: Array) -> Array:
    numerator = np.linalg.norm(approx - exact, axis=0)
    denominator = np.maximum(np.linalg.norm(exact, axis=0), np.finfo(float).tiny)
    return numerator / denominator


def run_num_jac_refresh_probe(
    *,
    fun: Callable[[float, Array], Array],
    analytic_jacobian: Callable[[float, Array], Array],
    t: float,
    y: Array,
    threshold: Array,
    refreshes: int,
    persistent_factor: bool = True,
) -> NumJacProbeResult:
    """Replay SciPy's exact persistent-factor numerical-Jacobian lifecycle."""

    state = np.asarray(y, dtype=np.float64)
    atol = np.asarray(threshold, dtype=np.float64)
    if state.ndim != 1 or atol.shape != state.shape:
        raise ValueError("state and threshold must be equal-length vectors")
    if int(refreshes) < 1:
        raise ValueError("refreshes must be positive")
    f = np.asarray(fun(float(t), state), dtype=np.float64)
    exact = np.asarray(analytic_jacobian(float(t), state), dtype=np.float64)
    if f.shape != state.shape or exact.shape != (state.size, state.size):
        raise ValueError("oracle returned invalid shape")

    factor: Array | None = None
    records: list[NumJacRecord] = []
    root_eps = np.sqrt(np.finfo(np.float64).eps)
    for refresh in range(int(refreshes)):
        input_factor = factor if persistent_factor else None
        approximate, new_factor = num_jac(
            fun,
            float(t),
            state,
            f,
            atol,
            input_factor,
            sparsity=None,
        )
        factor = np.asarray(new_factor, dtype=np.float64).copy()
        errors = _column_relative_errors(np.asarray(approximate), exact)
        scaled = factor / root_eps
        records.append(
            NumJacRecord(
                refresh=refresh,
                max_factor_over_sqrt_eps=float(np.max(scaled)),
                median_factor_over_sqrt_eps=float(np.median(scaled)),
                min_factor_over_sqrt_eps=float(np.min(scaled)),
                max_column_relative_error=float(np.max(errors)),
                median_column_relative_error=float(np.median(errors)),
                columns_over_one_percent=int(np.count_nonzero(errors > 0.01)),
            )
        )
    assert factor is not None
    return NumJacProbeResult(records=tuple(records), final_factor=factor)
