from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

Array = np.ndarray


@dataclass(frozen=True)
class Grid:
    order: int
    y_max: float
    nodes: Array
    weights: Array
    unit_nodes: Array
    unit_weights: Array

    @classmethod
    def gauss_legendre(cls, order: int, y_max: float) -> "Grid":
        if int(order) < 2:
            raise ValueError("order must be at least two")
        if not np.isfinite(y_max) or float(y_max) <= 0.0:
            raise ValueError("y_max must be finite and positive")
        x, w = leggauss(int(order))
        nodes = 0.5 * float(y_max) * (x + 1.0)
        weights = 0.5 * float(y_max) * w
        return cls(
            order=int(order),
            y_max=float(y_max),
            nodes=np.asarray(nodes, dtype=np.float64),
            weights=np.asarray(weights, dtype=np.float64),
            unit_nodes=np.asarray(x, dtype=np.float64),
            unit_weights=np.asarray(w, dtype=np.float64),
        )


def _interpolation_matrix(source: Grid, target_nodes: Array, *, zero_outside: bool) -> Array:
    query = np.asarray(target_nodes, dtype=np.float64)
    if query.ndim != 1 or not np.all(np.isfinite(query)):
        raise ValueError("target_nodes must be a finite vector")
    if (
        query.shape == source.nodes.shape
        and np.array_equal(query, source.nodes)
    ):
        return np.identity(source.order, dtype=np.float64)

    inside = (query >= 0.0) & (query <= source.y_max)
    if not zero_outside and not np.all(inside):
        raise ValueError("interpolation query lies outside source support")

    matrix = np.zeros((query.size, source.order), dtype=np.float64)
    if not np.any(inside):
        return matrix

    x_query = 2.0 * query[inside] / source.y_max - 1.0
    v_source = legvander(source.unit_nodes, source.order - 1)
    v_query = legvander(x_query, source.order - 1)
    modes = np.arange(source.order, dtype=np.float64)
    coefficient_map = (
        (modes + 0.5)[:, None]
        * v_source.T
        * source.unit_weights[None, :]
    )
    matrix[inside] = v_query @ coefficient_map
    return matrix


@dataclass(frozen=True)
class TransferPair:
    coarse: Grid
    fine: Grid
    species: int
    scalar_count: int
    prolongation: Array
    restriction: Array

    @property
    def coarse_state_size(self) -> int:
        return self.species * self.coarse.order + self.scalar_count

    @property
    def fine_state_size(self) -> int:
        return self.species * self.fine.order + self.scalar_count

    def prolong_spectral(self, values: Array) -> Array:
        arr = np.asarray(values, dtype=np.float64)
        if arr.shape != (self.coarse.order,):
            raise ValueError("coarse spectral vector has wrong shape")
        return self.prolongation @ arr

    def restrict_spectral(self, values: Array) -> Array:
        arr = np.asarray(values, dtype=np.float64)
        if arr.shape != (self.fine.order,):
            raise ValueError("fine spectral vector has wrong shape")
        return self.restriction @ arr

    def prolong_state(self, state: Array) -> Array:
        arr = np.asarray(state, dtype=np.float64)
        if arr.shape != (self.coarse_state_size,):
            raise ValueError("coarse state has wrong shape")
        output = np.empty(self.fine_state_size, dtype=np.float64)
        for species_index in range(self.species):
            c0 = species_index * self.coarse.order
            f0 = species_index * self.fine.order
            output[f0 : f0 + self.fine.order] = self.prolongation @ arr[
                c0 : c0 + self.coarse.order
            ]
        if self.scalar_count:
            output[-self.scalar_count :] = arr[-self.scalar_count :]
        return output

    def restrict_state(self, state: Array) -> Array:
        arr = np.asarray(state, dtype=np.float64)
        if arr.shape != (self.fine_state_size,):
            raise ValueError("fine state has wrong shape")
        output = np.empty(self.coarse_state_size, dtype=np.float64)
        for species_index in range(self.species):
            c0 = species_index * self.coarse.order
            f0 = species_index * self.fine.order
            output[c0 : c0 + self.coarse.order] = self.restriction @ arr[
                f0 : f0 + self.fine.order
            ]
        if self.scalar_count:
            output[-self.scalar_count :] = arr[-self.scalar_count :]
        return output


def build_transfer_pair(
    coarse: Grid,
    fine: Grid,
    *,
    species: int = 3,
    scalar_count: int = 2,
) -> TransferPair:
    if int(species) < 1 or int(scalar_count) < 0:
        raise ValueError("invalid state layout")
    if coarse.order == fine.order and coarse.y_max == fine.y_max:
        prolongation = np.identity(coarse.order, dtype=np.float64)
        restriction = np.identity(coarse.order, dtype=np.float64)
    else:
        prolongation = _interpolation_matrix(
            coarse, fine.nodes, zero_outside=True
        )
        restriction = _interpolation_matrix(
            fine, coarse.nodes, zero_outside=False
        )
    return TransferPair(
        coarse=coarse,
        fine=fine,
        species=int(species),
        scalar_count=int(scalar_count),
        prolongation=prolongation,
        restriction=restriction,
    )
