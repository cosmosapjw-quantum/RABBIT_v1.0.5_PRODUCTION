# DECISION_LOG.md

## D-001 — Formal candidate disposition

DATE: 2026-08-06

DECISION: `hold / reopen-validation`

OBJECT: solver/algorithm replacement for F10 order-60/30 independent trajectory blocker.

EVIDENCE:
- `results/formal_v2/formal_solver_sweep.json`
- `results/postformal/postformal_research.json`
- `reports/NUMERICAL_VALIDATION.md`

RATIONALE:
- EC-EXPRB-K passes every prospectively frozen synthetic gate with 352 calls and large wall margin.
- EC-PICARD-IE passes the same gates under a separately frozen protocol but with thin margin.
- no physical RABBIT prefix has been run, and the synthetic energy projector cannot be copied directly.

ALTERNATIVES:
- direct JFNK and two-level JFNK: killed;
- supplied-Jacobian/LSODA controls: scope-disqualified;
- reset/cap/hardware: not a D-071 reopening method.

RISKS:
- physical JVP cancellation and nonnormality may require larger Krylov spaces;
- physical total-energy coordinate may expose discrete first-law residuals;
- measured p95 RHS cost may differ under the new backend.

NEXT_ACTION: execute PR-SA00–SA05; kill candidate if sealed physical prefix fails.

## D-002 — Primary versus fallback

DATE: 2026-08-06

DECISION: `EC-EXPRB-K primary; EC-PICARD-IE fallback only`.

EVIDENCE:
- EXPRB: 352 calls, projected wall 3,960 s, accuracy headroom ~2.2×.
- Picard: 4,001 calls, projected wall 45,011.25 s, accuracy headroom ~1.10×.

RATIONALE: EXPRB has materially larger call/wall margin and directly treats nonnormal stable operator action. Picard requires a true-operator contraction certificate.
