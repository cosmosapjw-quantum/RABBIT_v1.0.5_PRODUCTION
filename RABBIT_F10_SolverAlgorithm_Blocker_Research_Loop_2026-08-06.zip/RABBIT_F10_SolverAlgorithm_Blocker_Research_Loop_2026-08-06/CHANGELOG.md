# Changelog

## 3.1.0 — 2026-07-12

- Prompt-centric workflow를 repo harness 중심 구조로 전환.
- `AGENTS.md`, scientific contract, validation matrix, plans/state/logs 추가.
- reproduction/acceptance → localization → bounded design → implementation → software/scientific/numerical validation → independent review → promote/revert 루프 정식화.
- repo-scoped Codex skills, 초기화·검증 도구 추가.

## Solver research package — 2026-08-06

- Added manufactured/cancellation benchmark matching the 182-state blocker class.
- Reproduced SciPy persistent finite-difference factor degradation.
- Implemented and tested D-JFNK, EXPRB-K, MLPC-JFNK and derivative-free Picard candidates.
- Froze and executed formal and post-formal campaigns.
- Retained EC-EXPRB-K as formal survivor and EC-PICARD-IE as secondary survivor.
- Added numerical/scientific validation, independent review, figures and RABBIT source PR DAG.
