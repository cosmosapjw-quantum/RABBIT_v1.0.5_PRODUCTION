# F10 Solver/Algorithm Research Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use test-driven development and execute
> each task in this isolated research branch. No RABBIT production file is in scope.

**Goal:** Build and validate a reproducible solver-level research prototype that compares
matrix-free, exponential-Krylov, and multilevel defect-correction routes against the
measured F10 trajectory blocker.

**Architecture:** A manufactured `3*order+2` kinetic model supplies an analytic reference,
a cancellation-heavy black-box lane, and fixed coarse/fine transfer maps. Three independent
solver candidates consume one common interface and emit identical counters and histories.
A research runner applies frozen gates and writes durable evidence.

**Tech Stack:** Python 3.13, NumPy 2.3, SciPy 1.17, pytest, matplotlib, standard library.

## Global Constraints

- No new runtime dependency.
- No original RABBIT source edit or external write.
- Fixed scientific and numerical gates come from `SCIENTIFIC_CONTRACT.md`.
- Batched finite-difference columns count as separate full-RHS-equivalent calls.
- Candidate solvers may call only the black-box RHS and declared preconditioner interface.
- Analytic Jacobians are restricted to reference/control/preconditioner-construction lanes.

---

### Task 1: Core contracts, grids, counters, and manufactured models

**Files:**
- Create `src/f10_solver_research/contracts.py`
- Create `src/f10_solver_research/grids.py`
- Create `src/f10_solver_research/models.py`
- Create `tests/test_grids.py`
- Create `tests/test_models.py`

**Produces:** `Grid`, `TransferPair`, `CallCounter`, `SolverResult`,
`ManufacturedKineticModel`, and `LinearNonnormalModel`.

- [ ] Write failing tests for identity transfer, constant reproduction, state layout,
  manufactured-path exactness, energy identity, strict occupations, and analytic linear
  solution.
- [ ] Run the focused tests and record the expected missing-module failure.
- [ ] Implement the minimal contracts, transfer construction, and models.
- [ ] Run focused tests to green and commit.

### Task 2: Fixed-rule JVP and SciPy finite-difference ratchet probe

**Files:**
- Create `src/f10_solver_research/jvp.py`
- Create `src/f10_solver_research/scipy_probe.py`
- Create `tests/test_jvp.py`
- Create `tests/test_scipy_probe.py`

**Produces:** `finite_difference_jvp`, `arnoldi`, and `run_num_jac_refresh_probe`.

- [ ] Write failing tests for analytic JVP agreement, Arnoldi projection, call accounting,
  and factor-history preservation.
- [ ] Verify the tests fail because the interfaces do not exist.
- [ ] Implement fixed, nonpersistent perturbation rules and the direct SciPy `num_jac`
  probe.
- [ ] Run tests to green and commit.

### Task 3: Direct JFNK implicit solver

**Files:**
- Create `src/f10_solver_research/solvers/jfnk.py`
- Create `tests/test_jfnk.py`

**Produces:** `solve_implicit_euler_jfnk` with fixed-step integration, globalized Newton,
GMRES, typed failures, and detailed counters.

- [ ] Write failing tests for linear convergence, first-order trend, preconditioner use,
  and surfaced GMRES/Newton failure.
- [ ] Verify red.
- [ ] Implement minimal solver and diagonal preconditioner hook.
- [ ] Run tests to green and commit.

### Task 4: Exponential Rosenbrock--Krylov solver

**Files:**
- Create `src/f10_solver_research/solvers/exprb.py`
- Create `tests/test_exprb.py`

**Produces:** `solve_exprb_krylov`, one Arnoldi basis per step, projected `phi_1` action,
embedded projected implicit-Euler defect, and histories.

- [ ] Write failing tests for exact linear action at full Krylov dimension, nonlinear
  convergence trend, Arnoldi breakdown handling, and call accounting.
- [ ] Verify red.
- [ ] Implement the minimal fixed-step solver.
- [ ] Run tests to green and commit.

### Task 5: Multilevel prolongation-defect-correction JFNK

**Files:**
- Create `src/f10_solver_research/solvers/multilevel.py`
- Create `tests/test_multilevel.py`

**Produces:** `CoarseTrajectoryPredictor`, `TwoLevelPreconditioner`, and
`solve_mlpc_jfnk`.

- [ ] Write failing tests for predictor mapping, exact fine-residual enforcement,
  complement smoothing, and iteration reduction against direct JFNK on the two-level
  model.
- [ ] Verify red.
- [ ] Implement predictor, two-level preconditioner, and solver composition.
- [ ] Run tests to green and commit.

### Task 6: Research runner and frozen adjudication

**Files:**
- Create `scripts/run_solver_algorithm_loop.py`
- Create `src/f10_solver_research/adjudication.py`
- Create `tests/test_adjudication.py`

**Produces:** JSON/CSV result files and per-lane `SURVIVE/REWORK/KILL` decisions.

- [ ] Write failing tests for gate arithmetic, deterministic decision ordering, and the
  prohibition on treating supplied-Jacobian BDF as a reopening survivor.
- [ ] Verify red.
- [ ] Implement the runner and adjudicator.
- [ ] Run the full research sweep and commit raw results.

### Task 7: Numerical, scientific, and reproducibility validation

**Files:**
- Create `reports/NUMERICAL_VALIDATION.md`
- Create `reports/SCIENTIFIC_VALIDATION.md`
- Create `reports/INDEPENDENT_DIFF_REVIEW.md`
- Update `VALIDATION_MATRIX.md`, `RUN_STATE.md`, `PLANS.md`, `DECISION_LOG.md`,
  `FAILURE_LOG.md`

- [ ] Run syntax/import and full pytest.
- [ ] Run resolution, step, cancellation, Krylov-dimension, and deterministic sweeps.
- [ ] Independently review the diff for scientific overclaim, hidden oracle use,
  undercounted calls, and missing failures.
- [ ] Repair blocking findings, rerun validations, and commit.

### Task 8: Closeout and durable package

**Files:**
- Create `RABBIT_F10_SOLVER_ALGORITHM_RESEARCH_REPORT.md`
- Create `RABBIT_F10_SOLVER_ALGORITHM_RESEARCH_SUMMARY_KO.md`
- Create `reports/RABBIT_SOURCE_INTEGRATION_PR_PLAN.md`
- Create `REPRODUCIBILITY_MANIFEST.json`, `SHA256SUMS`, and `VALIDATION_LOG.txt`

- [ ] State the selected candidate, negative results, D-071 boundary, and next minimal
  RABBIT-side discriminator.
- [ ] Validate the harness, replay all tests, regenerate results from a clean directory,
  verify hashes, and build a ZIP.
- [ ] Record `PROMOTE/HOLD/REWORK/REVERT`; research prototypes cannot be `PROMOTE` to
  RABBIT in this workspace.
