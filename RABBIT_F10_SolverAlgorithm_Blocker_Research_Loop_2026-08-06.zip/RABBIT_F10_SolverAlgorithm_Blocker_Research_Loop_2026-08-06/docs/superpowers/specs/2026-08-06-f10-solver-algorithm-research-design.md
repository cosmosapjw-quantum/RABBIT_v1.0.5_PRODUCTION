# F10 Solver/Algorithm Blocker Research Design

**Status:** approved by the user's direct execution request; research-only workspace.

## Problem statement

The order-60 / `y_max=30` independent trajectory does not reach a scientific predicate
within the frozen 18-hour wall budget. Current evidence localizes a SciPy BDF mechanism:
a persistent finite-difference perturbation factor ratchets across Jacobian refreshes,
corrupts columns at creep states, and accompanies Newton/order-reset cycles. A supplied or
pinned Jacobian is a useful control but is classified by D-071 as instrument tuning, not a
materially new reopening method.

The solver-side research question is therefore twofold:

1. Can a controlled repair reproduce the expected mechanical improvement and thereby
   validate the diagnosis?
2. Can a substantively different matrix-free or multilevel integration architecture solve
   the same fine equations with a bounded number of expensive RHS calls?

## Architecture

The workspace contains three layers.

### 1. Evidence-calibrated benchmark layer

A manufactured dense kinetic surrogate has `3*order+2` states, a stable nonnormal early-
window operator, Fermi-logit occupation reconstruction, and an exact combined-energy
identity. It has both a noiseless RHS and a mathematically equivalent cancellation-heavy
oracle that exposes finite-difference sensitivity. It is not presented as physical RABBIT
output; its role is to discriminate algorithms under the measured failure geometry.

A second static probe repeatedly invokes SciPy's own `num_jac` with its returned factor,
records the factor trajectory, and compares columns with the analytic Jacobian. This tests
the exact software mechanism separately from time integration.

### 2. Candidate solver layer

- **D-JFNK:** implicit Euler residual solved by globalized inexact Newton and GMRES using
  fixed-rule black-box JVPs and a diagonal physics preconditioner. This isolates the value
  of matrix-free nonlinear solving.
- **EXPRB-K:** exponential Rosenbrock--Euler with one Arnoldi space per step. It computes
  `phi_1(hJ)f` and an implicit-Euler projected companion estimate from the same Krylov
  basis. It removes nonlinear Newton iterations and is the most distinct solver family.
- **MLPC-JFNK:** uses the completed 48/24 trajectory as a fixed fine-state predictor and
  a two-level preconditioner for the exact 60/30 implicit residual. The coarse solve acts
  on `R r`; the unresolved complement receives a fixed diagonal tail smoother. The final
  accepted state is still required to satisfy the fine residual.

The supplied-Jacobian BDF lane is retained only as a causal control.

### 3. Validation and decision layer

All methods run on the same analytic linear problem and manufactured fine problem. The
loop records error, conservation, positivity, full-RHS-equivalent calls, Krylov/Newton
counts, wall time, peak memory, deterministic reruns, and order scaling. Candidate status
is `SURVIVE`, `REWORK`, or `KILL`; no candidate is promoted to RABBIT.

## Data flow

1. Build coarse and fine Gauss--Legendre grids.
2. Construct fixed transfer operators; fine tail nodes outside 24 receive zero
   perturbation around the analytic equilibrium tail.
3. Generate a coarse dense-output predictor with an analytic-Jacobian reference solve.
4. Run the four controls/candidates with independent counters.
5. Compare every endpoint to a high-accuracy fine Radau reference.
6. Apply predeclared numerical and projected-wall gates.
7. Emit JSON/CSV reports, figures, logs, hashes, and a source-integration PR plan.

## Error handling

Every solver returns a typed result carrying `success`, `reason`, endpoint, counters, and
history. GMRES failure, Newton failure, line-search exhaustion, Arnoldi breakdown,
nonfinite states, or positivity failure terminates that lane. No method switches to an
analytic Jacobian or a different solver after failure.

## Testing

Tests are written before implementation and cover grid maps, manufactured exactness,
energy identity, JVP accuracy, Newton globalization, Arnoldi action, solver convergence,
failure surfacing, counter semantics, and deterministic output. Numerical sweeps are kept
outside unit tests and recorded as research evidence.

## Scope boundary

No original RABBIT source or gate registry is edited. The final package may recommend a
future RABBIT PR, but the recommendation must identify which D-071 conjuncts remain
unsatisfied and must not call a synthetic benchmark a scientific validation.
