# RABBIT F10 solver/algorithm research — 핵심 요약

## 결론

현재 order-60/`y_max=30` blocker를 대상으로 solver·algorithm·programming 연구 루프를 실행한 결과, formal synthetic discriminator에서 **`EC-EXPRB-K`가 유일한 정식 생존 후보**로 남았다. 별도 post-formal protocol에서 derivative-free **`EC-PICARD-IE`도 생존**했지만 margin이 얇아 fallback으로 분류했다.

- `EC-EXPRB-K`: error `9.08e-6`, cancellation error `9.16e-6`, 352 full-RHS calls, projected wall 1.10 h, formal `SURVIVE`
- `EC-PICARD-IE`: error `1.817e-5`, 4,001 calls, projected wall 12.50 h, post-formal `SURVIVE`
- `EC-D-JFNK`: cancellation GMRES failure + 9,666 calls, `KILL`
- `EC-MLPC-JFNK`: fine JVP noise + 7,701 effective calls, `KILL`

단, 생존한 것은 EXPRB-K 단독이 아니라 **total-energy-constrained EC-EXPRB-K**다. 보존좌표를 빼면 raw EXPRB의 energy error가 `1e-6`대로 남아 frozen energy gate를 통과하지 못한다.

## 왜 EXPRB-K인가

EXPRB-K는 매 step마다 persistent dense finite-difference Jacobian을 만들거나 Newton residual을 고정밀로 풀지 않는다. time-augmented Jacobian action을 fresh directional differences로 계산하고, 작은 Krylov space에서 `phi_1(hJ)F`를 평가한다. formal `m=10`에서 step당 11 RHS calls, 32 steps로 총 352 calls다.

post-formal sweep에서는 `m=4`부터 endpoint error가 사실상 포화되어 160 calls까지 줄일 가능성이 보였다. 그러나 이는 formal 결과 이후 발견이므로 별도 contract 없이 정식 claim에 포함하지 않았다.

## Picard 후보

`h=4e-4`의 projected implicit-Euler Picard map은 synthetic operator에서 매 step 두 번의 RHS 평가로 수렴했다. Jacobian, JVP, GMRES는 0회다. 다만 projected wall margin이 1.44×뿐이고 실제 RABBIT operator의 nonnormal contraction이 미측정이므로 secondary fallback이다.

## 중요한 음성 결과

- SciPy `jac_factor` reset은 ratchet을 막지만 harsh cancellation에서 Jacobian columns를 정확하게 만들지 못한다.
- JFNK tolerance를 완화한 “성공”은 linear iteration 0으로 explicit predictor를 수용한 것이므로 genuine repair가 아니다.
- 48/24 coarse nonlinear preconditioner는 fine directional-difference noise를 제거하지 못했다.
- GPU/vectorization/hardware만으로는 D-071의 약 8,300× evaluation-count miss를 닫는 reopening route가 되지 않는다.

## 다음 단계

실제 RABBIT source에서는 다음 순서를 지켜야 한다.

1. pure RHS/call-accounting interface 분리
2. total comoving energy state와 algebraic `T_gamma` recovery 구현
3. actual creep states에서 JVP noise/static invariant 검사
4. `m=10` EC-EXPRB-K research backend 구현
5. 60/30 creep-prefix를 먼저 봉인·실행
6. prefix가 5,500-call/18-hour bound를 margin과 함께 통과할 때만 full trajectory
7. independent replay와 D-071 adjudication

현재 status는 `REOPEN_VALIDATION`이며 **D-071은 여전히 FAIL**이다.
